(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // examples/plugins/seo-suite/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    default: () => server_default
  });

  // node_modules/@sinclair/typebox/build/esm/type/guard/value.mjs
  var exports_value = {};
  __export(exports_value, {
    IsUndefined: () => IsUndefined,
    IsUint8Array: () => IsUint8Array,
    IsSymbol: () => IsSymbol,
    IsString: () => IsString,
    IsRegExp: () => IsRegExp,
    IsObject: () => IsObject,
    IsNumber: () => IsNumber,
    IsNull: () => IsNull,
    IsIterator: () => IsIterator,
    IsFunction: () => IsFunction,
    IsDate: () => IsDate,
    IsBoolean: () => IsBoolean,
    IsBigInt: () => IsBigInt,
    IsAsyncIterator: () => IsAsyncIterator,
    IsArray: () => IsArray,
    HasPropertyKey: () => HasPropertyKey
  });
  function HasPropertyKey(value, key) {
    return key in value;
  }
  function IsAsyncIterator(value) {
    return IsObject(value) && !IsArray(value) && !IsUint8Array(value) && Symbol.asyncIterator in value;
  }
  function IsArray(value) {
    return Array.isArray(value);
  }
  function IsBigInt(value) {
    return typeof value === "bigint";
  }
  function IsBoolean(value) {
    return typeof value === "boolean";
  }
  function IsDate(value) {
    return value instanceof globalThis.Date;
  }
  function IsFunction(value) {
    return typeof value === "function";
  }
  function IsIterator(value) {
    return IsObject(value) && !IsArray(value) && !IsUint8Array(value) && Symbol.iterator in value;
  }
  function IsNull(value) {
    return value === null;
  }
  function IsNumber(value) {
    return typeof value === "number";
  }
  function IsObject(value) {
    return typeof value === "object" && value !== null;
  }
  function IsRegExp(value) {
    return value instanceof globalThis.RegExp;
  }
  function IsString(value) {
    return typeof value === "string";
  }
  function IsSymbol(value) {
    return typeof value === "symbol";
  }
  function IsUint8Array(value) {
    return value instanceof globalThis.Uint8Array;
  }
  function IsUndefined(value) {
    return value === undefined;
  }

  // node_modules/@sinclair/typebox/build/esm/type/clone/value.mjs
  function ArrayType(value) {
    return value.map((value2) => Visit(value2));
  }
  function DateType(value) {
    return new Date(value.getTime());
  }
  function Uint8ArrayType(value) {
    return new Uint8Array(value);
  }
  function RegExpType(value) {
    return new RegExp(value.source, value.flags);
  }
  function ObjectType(value) {
    const result = {};
    for (const key of Object.getOwnPropertyNames(value)) {
      result[key] = Visit(value[key]);
    }
    for (const key of Object.getOwnPropertySymbols(value)) {
      result[key] = Visit(value[key]);
    }
    return result;
  }
  function Visit(value) {
    return IsArray(value) ? ArrayType(value) : IsDate(value) ? DateType(value) : IsUint8Array(value) ? Uint8ArrayType(value) : IsRegExp(value) ? RegExpType(value) : IsObject(value) ? ObjectType(value) : value;
  }
  function Clone(value) {
    return Visit(value);
  }

  // node_modules/@sinclair/typebox/build/esm/type/clone/type.mjs
  function CloneType(schema, options) {
    return options === undefined ? Clone(schema) : Clone({ ...options, ...schema });
  }

  // node_modules/@sinclair/typebox/build/esm/value/guard/guard.mjs
  function IsAsyncIterator2(value) {
    return IsObject2(value) && globalThis.Symbol.asyncIterator in value;
  }
  function IsIterator2(value) {
    return IsObject2(value) && globalThis.Symbol.iterator in value;
  }
  function IsStandardObject(value) {
    return IsObject2(value) && (globalThis.Object.getPrototypeOf(value) === Object.prototype || globalThis.Object.getPrototypeOf(value) === null);
  }
  function IsPromise(value) {
    return value instanceof globalThis.Promise;
  }
  function IsDate2(value) {
    return value instanceof Date && globalThis.Number.isFinite(value.getTime());
  }
  function IsMap(value) {
    return value instanceof globalThis.Map;
  }
  function IsSet(value) {
    return value instanceof globalThis.Set;
  }
  function IsTypedArray(value) {
    return globalThis.ArrayBuffer.isView(value);
  }
  function IsUint8Array2(value) {
    return value instanceof globalThis.Uint8Array;
  }
  function HasPropertyKey2(value, key) {
    return key in value;
  }
  function IsObject2(value) {
    return value !== null && typeof value === "object";
  }
  function IsArray2(value) {
    return globalThis.Array.isArray(value) && !globalThis.ArrayBuffer.isView(value);
  }
  function IsUndefined2(value) {
    return value === undefined;
  }
  function IsNull2(value) {
    return value === null;
  }
  function IsBoolean2(value) {
    return typeof value === "boolean";
  }
  function IsNumber2(value) {
    return typeof value === "number";
  }
  function IsInteger(value) {
    return globalThis.Number.isInteger(value);
  }
  function IsBigInt2(value) {
    return typeof value === "bigint";
  }
  function IsString2(value) {
    return typeof value === "string";
  }
  function IsFunction2(value) {
    return typeof value === "function";
  }
  function IsSymbol2(value) {
    return typeof value === "symbol";
  }
  function IsValueType(value) {
    return IsBigInt2(value) || IsBoolean2(value) || IsNull2(value) || IsNumber2(value) || IsString2(value) || IsSymbol2(value) || IsUndefined2(value);
  }

  // node_modules/@sinclair/typebox/build/esm/system/policy.mjs
  var TypeSystemPolicy;
  (function(TypeSystemPolicy2) {
    TypeSystemPolicy2.InstanceMode = "default";
    TypeSystemPolicy2.ExactOptionalPropertyTypes = false;
    TypeSystemPolicy2.AllowArrayObject = false;
    TypeSystemPolicy2.AllowNaN = false;
    TypeSystemPolicy2.AllowNullVoid = false;
    function IsExactOptionalProperty(value, key) {
      return TypeSystemPolicy2.ExactOptionalPropertyTypes ? key in value : value[key] !== undefined;
    }
    TypeSystemPolicy2.IsExactOptionalProperty = IsExactOptionalProperty;
    function IsObjectLike(value) {
      const isObject = IsObject2(value);
      return TypeSystemPolicy2.AllowArrayObject ? isObject : isObject && !IsArray2(value);
    }
    TypeSystemPolicy2.IsObjectLike = IsObjectLike;
    function IsRecordLike(value) {
      return IsObjectLike(value) && !(value instanceof Date) && !(value instanceof Uint8Array);
    }
    TypeSystemPolicy2.IsRecordLike = IsRecordLike;
    function IsNumberLike(value) {
      return TypeSystemPolicy2.AllowNaN ? IsNumber2(value) : Number.isFinite(value);
    }
    TypeSystemPolicy2.IsNumberLike = IsNumberLike;
    function IsVoidLike(value) {
      const isUndefined = IsUndefined2(value);
      return TypeSystemPolicy2.AllowNullVoid ? isUndefined || value === null : isUndefined;
    }
    TypeSystemPolicy2.IsVoidLike = IsVoidLike;
  })(TypeSystemPolicy || (TypeSystemPolicy = {}));

  // node_modules/@sinclair/typebox/build/esm/type/create/immutable.mjs
  function ImmutableArray(value) {
    return globalThis.Object.freeze(value).map((value2) => Immutable(value2));
  }
  function ImmutableDate(value) {
    return value;
  }
  function ImmutableUint8Array(value) {
    return value;
  }
  function ImmutableRegExp(value) {
    return value;
  }
  function ImmutableObject(value) {
    const result = {};
    for (const key of Object.getOwnPropertyNames(value)) {
      result[key] = Immutable(value[key]);
    }
    for (const key of Object.getOwnPropertySymbols(value)) {
      result[key] = Immutable(value[key]);
    }
    return globalThis.Object.freeze(result);
  }
  function Immutable(value) {
    return IsArray(value) ? ImmutableArray(value) : IsDate(value) ? ImmutableDate(value) : IsUint8Array(value) ? ImmutableUint8Array(value) : IsRegExp(value) ? ImmutableRegExp(value) : IsObject(value) ? ImmutableObject(value) : value;
  }

  // node_modules/@sinclair/typebox/build/esm/type/create/type.mjs
  function CreateType(schema, options) {
    const result = options !== undefined ? { ...options, ...schema } : schema;
    switch (TypeSystemPolicy.InstanceMode) {
      case "freeze":
        return Immutable(result);
      case "clone":
        return Clone(result);
      default:
        return result;
    }
  }

  // node_modules/@sinclair/typebox/build/esm/type/error/error.mjs
  class TypeBoxError extends Error {
    constructor(message) {
      super(message);
    }
  }

  // node_modules/@sinclair/typebox/build/esm/type/symbols/symbols.mjs
  var TransformKind = Symbol.for("TypeBox.Transform");
  var ReadonlyKind = Symbol.for("TypeBox.Readonly");
  var OptionalKind = Symbol.for("TypeBox.Optional");
  var Hint = Symbol.for("TypeBox.Hint");
  var Kind = Symbol.for("TypeBox.Kind");

  // node_modules/@sinclair/typebox/build/esm/type/guard/kind.mjs
  function IsReadonly(value) {
    return IsObject(value) && value[ReadonlyKind] === "Readonly";
  }
  function IsOptional(value) {
    return IsObject(value) && value[OptionalKind] === "Optional";
  }
  function IsAny(value) {
    return IsKindOf(value, "Any");
  }
  function IsArgument(value) {
    return IsKindOf(value, "Argument");
  }
  function IsArray3(value) {
    return IsKindOf(value, "Array");
  }
  function IsAsyncIterator3(value) {
    return IsKindOf(value, "AsyncIterator");
  }
  function IsBigInt3(value) {
    return IsKindOf(value, "BigInt");
  }
  function IsBoolean3(value) {
    return IsKindOf(value, "Boolean");
  }
  function IsComputed(value) {
    return IsKindOf(value, "Computed");
  }
  function IsConstructor(value) {
    return IsKindOf(value, "Constructor");
  }
  function IsDate3(value) {
    return IsKindOf(value, "Date");
  }
  function IsFunction3(value) {
    return IsKindOf(value, "Function");
  }
  function IsInteger2(value) {
    return IsKindOf(value, "Integer");
  }
  function IsIntersect(value) {
    return IsKindOf(value, "Intersect");
  }
  function IsIterator3(value) {
    return IsKindOf(value, "Iterator");
  }
  function IsKindOf(value, kind) {
    return IsObject(value) && Kind in value && value[Kind] === kind;
  }
  function IsLiteralValue(value) {
    return IsBoolean(value) || IsNumber(value) || IsString(value);
  }
  function IsLiteral(value) {
    return IsKindOf(value, "Literal");
  }
  function IsMappedKey(value) {
    return IsKindOf(value, "MappedKey");
  }
  function IsMappedResult(value) {
    return IsKindOf(value, "MappedResult");
  }
  function IsNever(value) {
    return IsKindOf(value, "Never");
  }
  function IsNot(value) {
    return IsKindOf(value, "Not");
  }
  function IsNull3(value) {
    return IsKindOf(value, "Null");
  }
  function IsNumber3(value) {
    return IsKindOf(value, "Number");
  }
  function IsObject3(value) {
    return IsKindOf(value, "Object");
  }
  function IsPromise2(value) {
    return IsKindOf(value, "Promise");
  }
  function IsRecord(value) {
    return IsKindOf(value, "Record");
  }
  function IsRef(value) {
    return IsKindOf(value, "Ref");
  }
  function IsRegExp2(value) {
    return IsKindOf(value, "RegExp");
  }
  function IsString3(value) {
    return IsKindOf(value, "String");
  }
  function IsSymbol3(value) {
    return IsKindOf(value, "Symbol");
  }
  function IsTemplateLiteral(value) {
    return IsKindOf(value, "TemplateLiteral");
  }
  function IsThis(value) {
    return IsKindOf(value, "This");
  }
  function IsTransform(value) {
    return IsObject(value) && TransformKind in value;
  }
  function IsTuple(value) {
    return IsKindOf(value, "Tuple");
  }
  function IsUndefined3(value) {
    return IsKindOf(value, "Undefined");
  }
  function IsUnion(value) {
    return IsKindOf(value, "Union");
  }
  function IsUint8Array3(value) {
    return IsKindOf(value, "Uint8Array");
  }
  function IsUnknown(value) {
    return IsKindOf(value, "Unknown");
  }
  function IsUnsafe(value) {
    return IsKindOf(value, "Unsafe");
  }
  function IsVoid(value) {
    return IsKindOf(value, "Void");
  }
  function IsKind(value) {
    return IsObject(value) && Kind in value && IsString(value[Kind]);
  }
  function IsSchema(value) {
    return IsAny(value) || IsArgument(value) || IsArray3(value) || IsBoolean3(value) || IsBigInt3(value) || IsAsyncIterator3(value) || IsComputed(value) || IsConstructor(value) || IsDate3(value) || IsFunction3(value) || IsInteger2(value) || IsIntersect(value) || IsIterator3(value) || IsLiteral(value) || IsMappedKey(value) || IsMappedResult(value) || IsNever(value) || IsNot(value) || IsNull3(value) || IsNumber3(value) || IsObject3(value) || IsPromise2(value) || IsRecord(value) || IsRef(value) || IsRegExp2(value) || IsString3(value) || IsSymbol3(value) || IsTemplateLiteral(value) || IsThis(value) || IsTuple(value) || IsUndefined3(value) || IsUnion(value) || IsUint8Array3(value) || IsUnknown(value) || IsUnsafe(value) || IsVoid(value) || IsKind(value);
  }
  // node_modules/@sinclair/typebox/build/esm/type/guard/type.mjs
  var exports_type = {};
  __export(exports_type, {
    TypeGuardUnknownTypeError: () => TypeGuardUnknownTypeError,
    IsVoid: () => IsVoid2,
    IsUnsafe: () => IsUnsafe2,
    IsUnknown: () => IsUnknown2,
    IsUnionLiteral: () => IsUnionLiteral,
    IsUnion: () => IsUnion2,
    IsUndefined: () => IsUndefined4,
    IsUint8Array: () => IsUint8Array4,
    IsTuple: () => IsTuple2,
    IsTransform: () => IsTransform2,
    IsThis: () => IsThis2,
    IsTemplateLiteral: () => IsTemplateLiteral2,
    IsSymbol: () => IsSymbol4,
    IsString: () => IsString4,
    IsSchema: () => IsSchema2,
    IsRegExp: () => IsRegExp3,
    IsRef: () => IsRef2,
    IsRecursive: () => IsRecursive,
    IsRecord: () => IsRecord2,
    IsReadonly: () => IsReadonly2,
    IsProperties: () => IsProperties,
    IsPromise: () => IsPromise3,
    IsOptional: () => IsOptional2,
    IsObject: () => IsObject4,
    IsNumber: () => IsNumber4,
    IsNull: () => IsNull4,
    IsNot: () => IsNot2,
    IsNever: () => IsNever2,
    IsMappedResult: () => IsMappedResult2,
    IsMappedKey: () => IsMappedKey2,
    IsLiteralValue: () => IsLiteralValue2,
    IsLiteralString: () => IsLiteralString,
    IsLiteralNumber: () => IsLiteralNumber,
    IsLiteralBoolean: () => IsLiteralBoolean,
    IsLiteral: () => IsLiteral2,
    IsKindOf: () => IsKindOf2,
    IsKind: () => IsKind2,
    IsIterator: () => IsIterator4,
    IsIntersect: () => IsIntersect2,
    IsInteger: () => IsInteger3,
    IsImport: () => IsImport,
    IsFunction: () => IsFunction4,
    IsDate: () => IsDate4,
    IsConstructor: () => IsConstructor2,
    IsComputed: () => IsComputed2,
    IsBoolean: () => IsBoolean4,
    IsBigInt: () => IsBigInt4,
    IsAsyncIterator: () => IsAsyncIterator4,
    IsArray: () => IsArray4,
    IsArgument: () => IsArgument2,
    IsAny: () => IsAny2
  });
  class TypeGuardUnknownTypeError extends TypeBoxError {
  }
  var KnownTypes = [
    "Argument",
    "Any",
    "Array",
    "AsyncIterator",
    "BigInt",
    "Boolean",
    "Computed",
    "Constructor",
    "Date",
    "Enum",
    "Function",
    "Integer",
    "Intersect",
    "Iterator",
    "Literal",
    "MappedKey",
    "MappedResult",
    "Not",
    "Null",
    "Number",
    "Object",
    "Promise",
    "Record",
    "Ref",
    "RegExp",
    "String",
    "Symbol",
    "TemplateLiteral",
    "This",
    "Tuple",
    "Undefined",
    "Union",
    "Uint8Array",
    "Unknown",
    "Void"
  ];
  function IsPattern(value) {
    try {
      new RegExp(value);
      return true;
    } catch {
      return false;
    }
  }
  function IsControlCharacterFree(value) {
    if (!IsString(value))
      return false;
    for (let i = 0;i < value.length; i++) {
      const code = value.charCodeAt(i);
      if (code >= 7 && code <= 13 || code === 27 || code === 127) {
        return false;
      }
    }
    return true;
  }
  function IsAdditionalProperties(value) {
    return IsOptionalBoolean(value) || IsSchema2(value);
  }
  function IsOptionalBigInt(value) {
    return IsUndefined(value) || IsBigInt(value);
  }
  function IsOptionalNumber(value) {
    return IsUndefined(value) || IsNumber(value);
  }
  function IsOptionalBoolean(value) {
    return IsUndefined(value) || IsBoolean(value);
  }
  function IsOptionalString(value) {
    return IsUndefined(value) || IsString(value);
  }
  function IsOptionalPattern(value) {
    return IsUndefined(value) || IsString(value) && IsControlCharacterFree(value) && IsPattern(value);
  }
  function IsOptionalFormat(value) {
    return IsUndefined(value) || IsString(value) && IsControlCharacterFree(value);
  }
  function IsOptionalSchema(value) {
    return IsUndefined(value) || IsSchema2(value);
  }
  function IsReadonly2(value) {
    return IsObject(value) && value[ReadonlyKind] === "Readonly";
  }
  function IsOptional2(value) {
    return IsObject(value) && value[OptionalKind] === "Optional";
  }
  function IsAny2(value) {
    return IsKindOf2(value, "Any") && IsOptionalString(value.$id);
  }
  function IsArgument2(value) {
    return IsKindOf2(value, "Argument") && IsNumber(value.index);
  }
  function IsArray4(value) {
    return IsKindOf2(value, "Array") && value.type === "array" && IsOptionalString(value.$id) && IsSchema2(value.items) && IsOptionalNumber(value.minItems) && IsOptionalNumber(value.maxItems) && IsOptionalBoolean(value.uniqueItems) && IsOptionalSchema(value.contains) && IsOptionalNumber(value.minContains) && IsOptionalNumber(value.maxContains);
  }
  function IsAsyncIterator4(value) {
    return IsKindOf2(value, "AsyncIterator") && value.type === "AsyncIterator" && IsOptionalString(value.$id) && IsSchema2(value.items);
  }
  function IsBigInt4(value) {
    return IsKindOf2(value, "BigInt") && value.type === "bigint" && IsOptionalString(value.$id) && IsOptionalBigInt(value.exclusiveMaximum) && IsOptionalBigInt(value.exclusiveMinimum) && IsOptionalBigInt(value.maximum) && IsOptionalBigInt(value.minimum) && IsOptionalBigInt(value.multipleOf);
  }
  function IsBoolean4(value) {
    return IsKindOf2(value, "Boolean") && value.type === "boolean" && IsOptionalString(value.$id);
  }
  function IsComputed2(value) {
    return IsKindOf2(value, "Computed") && IsString(value.target) && IsArray(value.parameters) && value.parameters.every((schema) => IsSchema2(schema));
  }
  function IsConstructor2(value) {
    return IsKindOf2(value, "Constructor") && value.type === "Constructor" && IsOptionalString(value.$id) && IsArray(value.parameters) && value.parameters.every((schema) => IsSchema2(schema)) && IsSchema2(value.returns);
  }
  function IsDate4(value) {
    return IsKindOf2(value, "Date") && value.type === "Date" && IsOptionalString(value.$id) && IsOptionalNumber(value.exclusiveMaximumTimestamp) && IsOptionalNumber(value.exclusiveMinimumTimestamp) && IsOptionalNumber(value.maximumTimestamp) && IsOptionalNumber(value.minimumTimestamp) && IsOptionalNumber(value.multipleOfTimestamp);
  }
  function IsFunction4(value) {
    return IsKindOf2(value, "Function") && value.type === "Function" && IsOptionalString(value.$id) && IsArray(value.parameters) && value.parameters.every((schema) => IsSchema2(schema)) && IsSchema2(value.returns);
  }
  function IsImport(value) {
    return IsKindOf2(value, "Import") && HasPropertyKey(value, "$defs") && IsObject(value.$defs) && IsProperties(value.$defs) && HasPropertyKey(value, "$ref") && IsString(value.$ref) && value.$ref in value.$defs;
  }
  function IsInteger3(value) {
    return IsKindOf2(value, "Integer") && value.type === "integer" && IsOptionalString(value.$id) && IsOptionalNumber(value.exclusiveMaximum) && IsOptionalNumber(value.exclusiveMinimum) && IsOptionalNumber(value.maximum) && IsOptionalNumber(value.minimum) && IsOptionalNumber(value.multipleOf);
  }
  function IsProperties(value) {
    return IsObject(value) && Object.entries(value).every(([key, schema]) => IsControlCharacterFree(key) && IsSchema2(schema));
  }
  function IsIntersect2(value) {
    return IsKindOf2(value, "Intersect") && (IsString(value.type) && value.type !== "object" ? false : true) && IsArray(value.allOf) && value.allOf.every((schema) => IsSchema2(schema) && !IsTransform2(schema)) && IsOptionalString(value.type) && (IsOptionalBoolean(value.unevaluatedProperties) || IsOptionalSchema(value.unevaluatedProperties)) && IsOptionalString(value.$id);
  }
  function IsIterator4(value) {
    return IsKindOf2(value, "Iterator") && value.type === "Iterator" && IsOptionalString(value.$id) && IsSchema2(value.items);
  }
  function IsKindOf2(value, kind) {
    return IsObject(value) && Kind in value && value[Kind] === kind;
  }
  function IsLiteralString(value) {
    return IsLiteral2(value) && IsString(value.const);
  }
  function IsLiteralNumber(value) {
    return IsLiteral2(value) && IsNumber(value.const);
  }
  function IsLiteralBoolean(value) {
    return IsLiteral2(value) && IsBoolean(value.const);
  }
  function IsLiteral2(value) {
    return IsKindOf2(value, "Literal") && IsOptionalString(value.$id) && IsLiteralValue2(value.const);
  }
  function IsLiteralValue2(value) {
    return IsBoolean(value) || IsNumber(value) || IsString(value);
  }
  function IsMappedKey2(value) {
    return IsKindOf2(value, "MappedKey") && IsArray(value.keys) && value.keys.every((key) => IsNumber(key) || IsString(key));
  }
  function IsMappedResult2(value) {
    return IsKindOf2(value, "MappedResult") && IsProperties(value.properties);
  }
  function IsNever2(value) {
    return IsKindOf2(value, "Never") && IsObject(value.not) && Object.getOwnPropertyNames(value.not).length === 0;
  }
  function IsNot2(value) {
    return IsKindOf2(value, "Not") && IsSchema2(value.not);
  }
  function IsNull4(value) {
    return IsKindOf2(value, "Null") && value.type === "null" && IsOptionalString(value.$id);
  }
  function IsNumber4(value) {
    return IsKindOf2(value, "Number") && value.type === "number" && IsOptionalString(value.$id) && IsOptionalNumber(value.exclusiveMaximum) && IsOptionalNumber(value.exclusiveMinimum) && IsOptionalNumber(value.maximum) && IsOptionalNumber(value.minimum) && IsOptionalNumber(value.multipleOf);
  }
  function IsObject4(value) {
    return IsKindOf2(value, "Object") && value.type === "object" && IsOptionalString(value.$id) && IsProperties(value.properties) && IsAdditionalProperties(value.additionalProperties) && IsOptionalNumber(value.minProperties) && IsOptionalNumber(value.maxProperties);
  }
  function IsPromise3(value) {
    return IsKindOf2(value, "Promise") && value.type === "Promise" && IsOptionalString(value.$id) && IsSchema2(value.item);
  }
  function IsRecord2(value) {
    return IsKindOf2(value, "Record") && value.type === "object" && IsOptionalString(value.$id) && IsAdditionalProperties(value.additionalProperties) && IsObject(value.patternProperties) && ((schema) => {
      const keys = Object.getOwnPropertyNames(schema.patternProperties);
      return keys.length === 1 && IsPattern(keys[0]) && IsObject(schema.patternProperties) && IsSchema2(schema.patternProperties[keys[0]]);
    })(value);
  }
  function IsRecursive(value) {
    return IsObject(value) && Hint in value && value[Hint] === "Recursive";
  }
  function IsRef2(value) {
    return IsKindOf2(value, "Ref") && IsOptionalString(value.$id) && IsString(value.$ref);
  }
  function IsRegExp3(value) {
    return IsKindOf2(value, "RegExp") && IsOptionalString(value.$id) && IsString(value.source) && IsString(value.flags) && IsOptionalNumber(value.maxLength) && IsOptionalNumber(value.minLength);
  }
  function IsString4(value) {
    return IsKindOf2(value, "String") && value.type === "string" && IsOptionalString(value.$id) && IsOptionalNumber(value.minLength) && IsOptionalNumber(value.maxLength) && IsOptionalPattern(value.pattern) && IsOptionalFormat(value.format);
  }
  function IsSymbol4(value) {
    return IsKindOf2(value, "Symbol") && value.type === "symbol" && IsOptionalString(value.$id);
  }
  function IsTemplateLiteral2(value) {
    return IsKindOf2(value, "TemplateLiteral") && value.type === "string" && IsString(value.pattern) && value.pattern[0] === "^" && value.pattern[value.pattern.length - 1] === "$";
  }
  function IsThis2(value) {
    return IsKindOf2(value, "This") && IsOptionalString(value.$id) && IsString(value.$ref);
  }
  function IsTransform2(value) {
    return IsObject(value) && TransformKind in value;
  }
  function IsTuple2(value) {
    return IsKindOf2(value, "Tuple") && value.type === "array" && IsOptionalString(value.$id) && IsNumber(value.minItems) && IsNumber(value.maxItems) && value.minItems === value.maxItems && (IsUndefined(value.items) && IsUndefined(value.additionalItems) && value.minItems === 0 || IsArray(value.items) && value.items.every((schema) => IsSchema2(schema)));
  }
  function IsUndefined4(value) {
    return IsKindOf2(value, "Undefined") && value.type === "undefined" && IsOptionalString(value.$id);
  }
  function IsUnionLiteral(value) {
    return IsUnion2(value) && value.anyOf.every((schema) => IsLiteralString(schema) || IsLiteralNumber(schema));
  }
  function IsUnion2(value) {
    return IsKindOf2(value, "Union") && IsOptionalString(value.$id) && IsObject(value) && IsArray(value.anyOf) && value.anyOf.every((schema) => IsSchema2(schema));
  }
  function IsUint8Array4(value) {
    return IsKindOf2(value, "Uint8Array") && value.type === "Uint8Array" && IsOptionalString(value.$id) && IsOptionalNumber(value.minByteLength) && IsOptionalNumber(value.maxByteLength);
  }
  function IsUnknown2(value) {
    return IsKindOf2(value, "Unknown") && IsOptionalString(value.$id);
  }
  function IsUnsafe2(value) {
    return IsKindOf2(value, "Unsafe");
  }
  function IsVoid2(value) {
    return IsKindOf2(value, "Void") && value.type === "void" && IsOptionalString(value.$id);
  }
  function IsKind2(value) {
    return IsObject(value) && Kind in value && IsString(value[Kind]) && !KnownTypes.includes(value[Kind]);
  }
  function IsSchema2(value) {
    return IsObject(value) && (IsAny2(value) || IsArgument2(value) || IsArray4(value) || IsBoolean4(value) || IsBigInt4(value) || IsAsyncIterator4(value) || IsComputed2(value) || IsConstructor2(value) || IsDate4(value) || IsFunction4(value) || IsInteger3(value) || IsIntersect2(value) || IsIterator4(value) || IsLiteral2(value) || IsMappedKey2(value) || IsMappedResult2(value) || IsNever2(value) || IsNot2(value) || IsNull4(value) || IsNumber4(value) || IsObject4(value) || IsPromise3(value) || IsRecord2(value) || IsRef2(value) || IsRegExp3(value) || IsString4(value) || IsSymbol4(value) || IsTemplateLiteral2(value) || IsThis2(value) || IsTuple2(value) || IsUndefined4(value) || IsUnion2(value) || IsUint8Array4(value) || IsUnknown2(value) || IsUnsafe2(value) || IsVoid2(value) || IsKind2(value));
  }
  // node_modules/@sinclair/typebox/build/esm/type/patterns/patterns.mjs
  var PatternBoolean = "(true|false)";
  var PatternNumber = "(0|[1-9][0-9]*)";
  var PatternString = "(.*)";
  var PatternNever = "(?!.*)";
  var PatternBooleanExact = `^${PatternBoolean}$`;
  var PatternNumberExact = `^${PatternNumber}$`;
  var PatternStringExact = `^${PatternString}$`;
  var PatternNeverExact = `^${PatternNever}$`;

  // node_modules/@sinclair/typebox/build/esm/type/registry/format.mjs
  var exports_format = {};
  __export(exports_format, {
    Set: () => Set2,
    Has: () => Has,
    Get: () => Get,
    Entries: () => Entries,
    Delete: () => Delete,
    Clear: () => Clear
  });
  var map = new Map;
  function Entries() {
    return new Map(map);
  }
  function Clear() {
    return map.clear();
  }
  function Delete(format) {
    return map.delete(format);
  }
  function Has(format) {
    return map.has(format);
  }
  function Set2(format, func) {
    map.set(format, func);
  }
  function Get(format) {
    return map.get(format);
  }
  // node_modules/@sinclair/typebox/build/esm/type/registry/type.mjs
  var exports_type2 = {};
  __export(exports_type2, {
    Set: () => Set3,
    Has: () => Has2,
    Get: () => Get2,
    Entries: () => Entries2,
    Delete: () => Delete2,
    Clear: () => Clear2
  });
  var map2 = new Map;
  function Entries2() {
    return new Map(map2);
  }
  function Clear2() {
    return map2.clear();
  }
  function Delete2(kind) {
    return map2.delete(kind);
  }
  function Has2(kind) {
    return map2.has(kind);
  }
  function Set3(kind, func) {
    map2.set(kind, func);
  }
  function Get2(kind) {
    return map2.get(kind);
  }
  // node_modules/@sinclair/typebox/build/esm/type/sets/set.mjs
  function SetIncludes(T, S) {
    return T.includes(S);
  }
  function SetDistinct(T) {
    return [...new Set(T)];
  }
  function SetIntersect(T, S) {
    return T.filter((L) => S.includes(L));
  }
  function SetIntersectManyResolve(T, Init) {
    return T.reduce((Acc, L) => {
      return SetIntersect(Acc, L);
    }, Init);
  }
  function SetIntersectMany(T) {
    return T.length === 1 ? T[0] : T.length > 1 ? SetIntersectManyResolve(T.slice(1), T[0]) : [];
  }
  function SetUnionMany(T) {
    const Acc = [];
    for (const L of T)
      Acc.push(...L);
    return Acc;
  }

  // node_modules/@sinclair/typebox/build/esm/type/any/any.mjs
  function Any(options) {
    return CreateType({ [Kind]: "Any" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/array/array.mjs
  function Array2(items, options) {
    return CreateType({ [Kind]: "Array", type: "array", items }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/argument/argument.mjs
  function Argument(index) {
    return CreateType({ [Kind]: "Argument", index });
  }

  // node_modules/@sinclair/typebox/build/esm/type/async-iterator/async-iterator.mjs
  function AsyncIterator(items, options) {
    return CreateType({ [Kind]: "AsyncIterator", type: "AsyncIterator", items }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/computed/computed.mjs
  function Computed(target, parameters, options) {
    return CreateType({ [Kind]: "Computed", target, parameters }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/discard/discard.mjs
  function DiscardKey(value, key) {
    const { [key]: _, ...rest } = value;
    return rest;
  }
  function Discard(value, keys) {
    return keys.reduce((acc, key) => DiscardKey(acc, key), value);
  }

  // node_modules/@sinclair/typebox/build/esm/type/never/never.mjs
  function Never(options) {
    return CreateType({ [Kind]: "Never", not: {} }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/mapped/mapped-result.mjs
  function MappedResult(properties) {
    return CreateType({
      [Kind]: "MappedResult",
      properties
    });
  }

  // node_modules/@sinclair/typebox/build/esm/type/constructor/constructor.mjs
  function Constructor(parameters, returns, options) {
    return CreateType({ [Kind]: "Constructor", type: "Constructor", parameters, returns }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/function/function.mjs
  function Function(parameters, returns, options) {
    return CreateType({ [Kind]: "Function", type: "Function", parameters, returns }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/union/union-create.mjs
  function UnionCreate(T, options) {
    return CreateType({ [Kind]: "Union", anyOf: T }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/union/union-evaluated.mjs
  function IsUnionOptional(types) {
    return types.some((type) => IsOptional(type));
  }
  function RemoveOptionalFromRest(types) {
    return types.map((left) => IsOptional(left) ? RemoveOptionalFromType(left) : left);
  }
  function RemoveOptionalFromType(T) {
    return Discard(T, [OptionalKind]);
  }
  function ResolveUnion(types, options) {
    const isOptional = IsUnionOptional(types);
    return isOptional ? Optional(UnionCreate(RemoveOptionalFromRest(types), options)) : UnionCreate(RemoveOptionalFromRest(types), options);
  }
  function UnionEvaluated(T, options) {
    return T.length === 1 ? CreateType(T[0], options) : T.length === 0 ? Never(options) : ResolveUnion(T, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/union/union.mjs
  function Union(types, options) {
    return types.length === 0 ? Never(options) : types.length === 1 ? CreateType(types[0], options) : UnionCreate(types, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/template-literal/parse.mjs
  class TemplateLiteralParserError extends TypeBoxError {
  }
  function Unescape(pattern) {
    return pattern.replace(/\\\$/g, "$").replace(/\\\*/g, "*").replace(/\\\^/g, "^").replace(/\\\|/g, "|").replace(/\\\(/g, "(").replace(/\\\)/g, ")");
  }
  function IsNonEscaped(pattern, index, char) {
    return pattern[index] === char && pattern.charCodeAt(index - 1) !== 92;
  }
  function IsOpenParen(pattern, index) {
    return IsNonEscaped(pattern, index, "(");
  }
  function IsCloseParen(pattern, index) {
    return IsNonEscaped(pattern, index, ")");
  }
  function IsSeparator(pattern, index) {
    return IsNonEscaped(pattern, index, "|");
  }
  function IsGroup(pattern) {
    if (!(IsOpenParen(pattern, 0) && IsCloseParen(pattern, pattern.length - 1)))
      return false;
    let count = 0;
    for (let index = 0;index < pattern.length; index++) {
      if (IsOpenParen(pattern, index))
        count += 1;
      if (IsCloseParen(pattern, index))
        count -= 1;
      if (count === 0 && index !== pattern.length - 1)
        return false;
    }
    return true;
  }
  function InGroup(pattern) {
    return pattern.slice(1, pattern.length - 1);
  }
  function IsPrecedenceOr(pattern) {
    let count = 0;
    for (let index = 0;index < pattern.length; index++) {
      if (IsOpenParen(pattern, index))
        count += 1;
      if (IsCloseParen(pattern, index))
        count -= 1;
      if (IsSeparator(pattern, index) && count === 0)
        return true;
    }
    return false;
  }
  function IsPrecedenceAnd(pattern) {
    for (let index = 0;index < pattern.length; index++) {
      if (IsOpenParen(pattern, index))
        return true;
    }
    return false;
  }
  function Or(pattern) {
    let [count, start] = [0, 0];
    const expressions = [];
    for (let index = 0;index < pattern.length; index++) {
      if (IsOpenParen(pattern, index))
        count += 1;
      if (IsCloseParen(pattern, index))
        count -= 1;
      if (IsSeparator(pattern, index) && count === 0) {
        const range2 = pattern.slice(start, index);
        if (range2.length > 0)
          expressions.push(TemplateLiteralParse(range2));
        start = index + 1;
      }
    }
    const range = pattern.slice(start);
    if (range.length > 0)
      expressions.push(TemplateLiteralParse(range));
    if (expressions.length === 0)
      return { type: "const", const: "" };
    if (expressions.length === 1)
      return expressions[0];
    return { type: "or", expr: expressions };
  }
  function And(pattern) {
    function Group(value, index) {
      if (!IsOpenParen(value, index))
        throw new TemplateLiteralParserError(`TemplateLiteralParser: Index must point to open parens`);
      let count = 0;
      for (let scan = index;scan < value.length; scan++) {
        if (IsOpenParen(value, scan))
          count += 1;
        if (IsCloseParen(value, scan))
          count -= 1;
        if (count === 0)
          return [index, scan];
      }
      throw new TemplateLiteralParserError(`TemplateLiteralParser: Unclosed group parens in expression`);
    }
    function Range(pattern2, index) {
      for (let scan = index;scan < pattern2.length; scan++) {
        if (IsOpenParen(pattern2, scan))
          return [index, scan];
      }
      return [index, pattern2.length];
    }
    const expressions = [];
    for (let index = 0;index < pattern.length; index++) {
      if (IsOpenParen(pattern, index)) {
        const [start, end] = Group(pattern, index);
        const range = pattern.slice(start, end + 1);
        expressions.push(TemplateLiteralParse(range));
        index = end;
      } else {
        const [start, end] = Range(pattern, index);
        const range = pattern.slice(start, end);
        if (range.length > 0)
          expressions.push(TemplateLiteralParse(range));
        index = end - 1;
      }
    }
    return expressions.length === 0 ? { type: "const", const: "" } : expressions.length === 1 ? expressions[0] : { type: "and", expr: expressions };
  }
  function TemplateLiteralParse(pattern) {
    return IsGroup(pattern) ? TemplateLiteralParse(InGroup(pattern)) : IsPrecedenceOr(pattern) ? Or(pattern) : IsPrecedenceAnd(pattern) ? And(pattern) : { type: "const", const: Unescape(pattern) };
  }
  function TemplateLiteralParseExact(pattern) {
    return TemplateLiteralParse(pattern.slice(1, pattern.length - 1));
  }

  // node_modules/@sinclair/typebox/build/esm/type/template-literal/finite.mjs
  class TemplateLiteralFiniteError extends TypeBoxError {
  }
  function IsNumberExpression(expression) {
    return expression.type === "or" && expression.expr.length === 2 && expression.expr[0].type === "const" && expression.expr[0].const === "0" && expression.expr[1].type === "const" && expression.expr[1].const === "[1-9][0-9]*";
  }
  function IsBooleanExpression(expression) {
    return expression.type === "or" && expression.expr.length === 2 && expression.expr[0].type === "const" && expression.expr[0].const === "true" && expression.expr[1].type === "const" && expression.expr[1].const === "false";
  }
  function IsStringExpression(expression) {
    return expression.type === "const" && expression.const === ".*";
  }
  function IsTemplateLiteralExpressionFinite(expression) {
    return IsNumberExpression(expression) || IsStringExpression(expression) ? false : IsBooleanExpression(expression) ? true : expression.type === "and" ? expression.expr.every((expr) => IsTemplateLiteralExpressionFinite(expr)) : expression.type === "or" ? expression.expr.every((expr) => IsTemplateLiteralExpressionFinite(expr)) : expression.type === "const" ? true : (() => {
      throw new TemplateLiteralFiniteError(`Unknown expression type`);
    })();
  }
  function IsTemplateLiteralFinite(schema) {
    const expression = TemplateLiteralParseExact(schema.pattern);
    return IsTemplateLiteralExpressionFinite(expression);
  }

  // node_modules/@sinclair/typebox/build/esm/type/template-literal/generate.mjs
  class TemplateLiteralGenerateError extends TypeBoxError {
  }
  function* GenerateReduce(buffer) {
    if (buffer.length === 1)
      return yield* buffer[0];
    for (const left of buffer[0]) {
      for (const right of GenerateReduce(buffer.slice(1))) {
        yield `${left}${right}`;
      }
    }
  }
  function* GenerateAnd(expression) {
    return yield* GenerateReduce(expression.expr.map((expr) => [...TemplateLiteralExpressionGenerate(expr)]));
  }
  function* GenerateOr(expression) {
    for (const expr of expression.expr)
      yield* TemplateLiteralExpressionGenerate(expr);
  }
  function* GenerateConst(expression) {
    return yield expression.const;
  }
  function* TemplateLiteralExpressionGenerate(expression) {
    return expression.type === "and" ? yield* GenerateAnd(expression) : expression.type === "or" ? yield* GenerateOr(expression) : expression.type === "const" ? yield* GenerateConst(expression) : (() => {
      throw new TemplateLiteralGenerateError("Unknown expression");
    })();
  }
  function TemplateLiteralGenerate(schema) {
    const expression = TemplateLiteralParseExact(schema.pattern);
    return IsTemplateLiteralExpressionFinite(expression) ? [...TemplateLiteralExpressionGenerate(expression)] : [];
  }

  // node_modules/@sinclair/typebox/build/esm/type/literal/literal.mjs
  function Literal(value, options) {
    return CreateType({
      [Kind]: "Literal",
      const: value,
      type: typeof value
    }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/boolean/boolean.mjs
  function Boolean2(options) {
    return CreateType({ [Kind]: "Boolean", type: "boolean" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/bigint/bigint.mjs
  function BigInt2(options) {
    return CreateType({ [Kind]: "BigInt", type: "bigint" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/number/number.mjs
  function Number2(options) {
    return CreateType({ [Kind]: "Number", type: "number" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/string/string.mjs
  function String2(options) {
    return CreateType({ [Kind]: "String", type: "string" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/template-literal/syntax.mjs
  function* FromUnion(syntax) {
    const trim = syntax.trim().replace(/"|'/g, "");
    return trim === "boolean" ? yield Boolean2() : trim === "number" ? yield Number2() : trim === "bigint" ? yield BigInt2() : trim === "string" ? yield String2() : yield (() => {
      const literals = trim.split("|").map((literal) => Literal(literal.trim()));
      return literals.length === 0 ? Never() : literals.length === 1 ? literals[0] : UnionEvaluated(literals);
    })();
  }
  function* FromTerminal(syntax) {
    if (syntax[1] !== "{") {
      const L = Literal("$");
      const R = FromSyntax(syntax.slice(1));
      return yield* [L, ...R];
    }
    for (let i = 2;i < syntax.length; i++) {
      if (syntax[i] === "}") {
        const L = FromUnion(syntax.slice(2, i));
        const R = FromSyntax(syntax.slice(i + 1));
        return yield* [...L, ...R];
      }
    }
    yield Literal(syntax);
  }
  function* FromSyntax(syntax) {
    for (let i = 0;i < syntax.length; i++) {
      if (syntax[i] === "$") {
        const L = Literal(syntax.slice(0, i));
        const R = FromTerminal(syntax.slice(i));
        return yield* [L, ...R];
      }
    }
    yield Literal(syntax);
  }
  function TemplateLiteralSyntax(syntax) {
    return [...FromSyntax(syntax)];
  }

  // node_modules/@sinclair/typebox/build/esm/type/template-literal/pattern.mjs
  class TemplateLiteralPatternError extends TypeBoxError {
  }
  function Escape(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function Visit2(schema, acc) {
    return IsTemplateLiteral(schema) ? schema.pattern.slice(1, schema.pattern.length - 1) : IsUnion(schema) ? `(${schema.anyOf.map((schema2) => Visit2(schema2, acc)).join("|")})` : IsNumber3(schema) ? `${acc}${PatternNumber}` : IsInteger2(schema) ? `${acc}${PatternNumber}` : IsBigInt3(schema) ? `${acc}${PatternNumber}` : IsString3(schema) ? `${acc}${PatternString}` : IsLiteral(schema) ? `${acc}${Escape(schema.const.toString())}` : IsBoolean3(schema) ? `${acc}${PatternBoolean}` : (() => {
      throw new TemplateLiteralPatternError(`Unexpected Kind '${schema[Kind]}'`);
    })();
  }
  function TemplateLiteralPattern(kinds) {
    return `^${kinds.map((schema) => Visit2(schema, "")).join("")}$`;
  }

  // node_modules/@sinclair/typebox/build/esm/type/template-literal/union.mjs
  function TemplateLiteralToUnion(schema) {
    const R = TemplateLiteralGenerate(schema);
    const L = R.map((S) => Literal(S));
    return UnionEvaluated(L);
  }

  // node_modules/@sinclair/typebox/build/esm/type/template-literal/template-literal.mjs
  function TemplateLiteral(unresolved, options) {
    const pattern = IsString(unresolved) ? TemplateLiteralPattern(TemplateLiteralSyntax(unresolved)) : TemplateLiteralPattern(unresolved);
    return CreateType({ [Kind]: "TemplateLiteral", type: "string", pattern }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/indexed/indexed-property-keys.mjs
  function FromTemplateLiteral(templateLiteral) {
    const keys = TemplateLiteralGenerate(templateLiteral);
    return keys.map((key) => key.toString());
  }
  function FromUnion2(types) {
    const result = [];
    for (const type of types)
      result.push(...IndexPropertyKeys(type));
    return result;
  }
  function FromLiteral(literalValue) {
    return [literalValue.toString()];
  }
  function IndexPropertyKeys(type) {
    return [...new Set(IsTemplateLiteral(type) ? FromTemplateLiteral(type) : IsUnion(type) ? FromUnion2(type.anyOf) : IsLiteral(type) ? FromLiteral(type.const) : IsNumber3(type) ? ["[number]"] : IsInteger2(type) ? ["[number]"] : [])];
  }

  // node_modules/@sinclair/typebox/build/esm/type/indexed/indexed-from-mapped-result.mjs
  function FromProperties(type, properties, options) {
    const result = {};
    for (const K2 of Object.getOwnPropertyNames(properties)) {
      result[K2] = Index(type, IndexPropertyKeys(properties[K2]), options);
    }
    return result;
  }
  function FromMappedResult(type, mappedResult, options) {
    return FromProperties(type, mappedResult.properties, options);
  }
  function IndexFromMappedResult(type, mappedResult, options) {
    const properties = FromMappedResult(type, mappedResult, options);
    return MappedResult(properties);
  }

  // node_modules/@sinclair/typebox/build/esm/type/indexed/indexed.mjs
  function FromRest(types, key) {
    return types.map((type) => IndexFromPropertyKey(type, key));
  }
  function FromIntersectRest(types) {
    return types.filter((type) => !IsNever(type));
  }
  function FromIntersect(types, key) {
    return IntersectEvaluated(FromIntersectRest(FromRest(types, key)));
  }
  function FromUnionRest(types) {
    return types.some((L) => IsNever(L)) ? [] : types;
  }
  function FromUnion3(types, key) {
    return UnionEvaluated(FromUnionRest(FromRest(types, key)));
  }
  function FromTuple(types, key) {
    return key in types ? types[key] : key === "[number]" ? UnionEvaluated(types) : Never();
  }
  function FromArray(type, key) {
    return key === "[number]" ? type : Never();
  }
  function FromProperty(properties, propertyKey) {
    return propertyKey in properties ? properties[propertyKey] : Never();
  }
  function IndexFromPropertyKey(type, propertyKey) {
    return IsIntersect(type) ? FromIntersect(type.allOf, propertyKey) : IsUnion(type) ? FromUnion3(type.anyOf, propertyKey) : IsTuple(type) ? FromTuple(type.items ?? [], propertyKey) : IsArray3(type) ? FromArray(type.items, propertyKey) : IsObject3(type) ? FromProperty(type.properties, propertyKey) : Never();
  }
  function IndexFromPropertyKeys(type, propertyKeys) {
    return propertyKeys.map((propertyKey) => IndexFromPropertyKey(type, propertyKey));
  }
  function FromSchema(type, propertyKeys) {
    return UnionEvaluated(IndexFromPropertyKeys(type, propertyKeys));
  }
  function Index(type, key, options) {
    if (IsRef(type) || IsRef(key)) {
      const error = `Index types using Ref parameters require both Type and Key to be of TSchema`;
      if (!IsSchema(type) || !IsSchema(key))
        throw new TypeBoxError(error);
      return Computed("Index", [type, key]);
    }
    if (IsMappedResult(key))
      return IndexFromMappedResult(type, key, options);
    if (IsMappedKey(key))
      return IndexFromMappedKey(type, key, options);
    return CreateType(IsSchema(key) ? FromSchema(type, IndexPropertyKeys(key)) : FromSchema(type, key), options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/indexed/indexed-from-mapped-key.mjs
  function MappedIndexPropertyKey(type, key, options) {
    return { [key]: Index(type, [key], Clone(options)) };
  }
  function MappedIndexPropertyKeys(type, propertyKeys, options) {
    return propertyKeys.reduce((result, left) => {
      return { ...result, ...MappedIndexPropertyKey(type, left, options) };
    }, {});
  }
  function MappedIndexProperties(type, mappedKey, options) {
    return MappedIndexPropertyKeys(type, mappedKey.keys, options);
  }
  function IndexFromMappedKey(type, mappedKey, options) {
    const properties = MappedIndexProperties(type, mappedKey, options);
    return MappedResult(properties);
  }

  // node_modules/@sinclair/typebox/build/esm/type/iterator/iterator.mjs
  function Iterator(items, options) {
    return CreateType({ [Kind]: "Iterator", type: "Iterator", items }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/object/object.mjs
  function RequiredArray(properties) {
    return globalThis.Object.keys(properties).filter((key) => !IsOptional(properties[key]));
  }
  function _Object(properties, options) {
    const required = RequiredArray(properties);
    const schema = required.length > 0 ? { [Kind]: "Object", type: "object", required, properties } : { [Kind]: "Object", type: "object", properties };
    return CreateType(schema, options);
  }
  var Object2 = _Object;

  // node_modules/@sinclair/typebox/build/esm/type/promise/promise.mjs
  function Promise2(item, options) {
    return CreateType({ [Kind]: "Promise", type: "Promise", item }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/readonly/readonly.mjs
  function RemoveReadonly(schema) {
    return CreateType(Discard(schema, [ReadonlyKind]));
  }
  function AddReadonly(schema) {
    return CreateType({ ...schema, [ReadonlyKind]: "Readonly" });
  }
  function ReadonlyWithFlag(schema, F) {
    return F === false ? RemoveReadonly(schema) : AddReadonly(schema);
  }
  function Readonly(schema, enable) {
    const F = enable ?? true;
    return IsMappedResult(schema) ? ReadonlyFromMappedResult(schema, F) : ReadonlyWithFlag(schema, F);
  }

  // node_modules/@sinclair/typebox/build/esm/type/readonly/readonly-from-mapped-result.mjs
  function FromProperties2(K, F) {
    const Acc = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(K))
      Acc[K2] = Readonly(K[K2], F);
    return Acc;
  }
  function FromMappedResult2(R, F) {
    return FromProperties2(R.properties, F);
  }
  function ReadonlyFromMappedResult(R, F) {
    const P = FromMappedResult2(R, F);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/tuple/tuple.mjs
  function Tuple(types, options) {
    return CreateType(types.length > 0 ? { [Kind]: "Tuple", type: "array", items: types, additionalItems: false, minItems: types.length, maxItems: types.length } : { [Kind]: "Tuple", type: "array", minItems: types.length, maxItems: types.length }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/mapped/mapped.mjs
  function FromMappedResult3(K, P) {
    return K in P ? FromSchemaType(K, P[K]) : MappedResult(P);
  }
  function MappedKeyToKnownMappedResultProperties(K) {
    return { [K]: Literal(K) };
  }
  function MappedKeyToUnknownMappedResultProperties(P) {
    const Acc = {};
    for (const L of P)
      Acc[L] = Literal(L);
    return Acc;
  }
  function MappedKeyToMappedResultProperties(K, P) {
    return SetIncludes(P, K) ? MappedKeyToKnownMappedResultProperties(K) : MappedKeyToUnknownMappedResultProperties(P);
  }
  function FromMappedKey(K, P) {
    const R = MappedKeyToMappedResultProperties(K, P);
    return FromMappedResult3(K, R);
  }
  function FromRest2(K, T) {
    return T.map((L) => FromSchemaType(K, L));
  }
  function FromProperties3(K, T) {
    const Acc = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(T))
      Acc[K2] = FromSchemaType(K, T[K2]);
    return Acc;
  }
  function FromSchemaType(K, T) {
    const options = { ...T };
    return IsOptional(T) ? Optional(FromSchemaType(K, Discard(T, [OptionalKind]))) : IsReadonly(T) ? Readonly(FromSchemaType(K, Discard(T, [ReadonlyKind]))) : IsMappedResult(T) ? FromMappedResult3(K, T.properties) : IsMappedKey(T) ? FromMappedKey(K, T.keys) : IsConstructor(T) ? Constructor(FromRest2(K, T.parameters), FromSchemaType(K, T.returns), options) : IsFunction3(T) ? Function(FromRest2(K, T.parameters), FromSchemaType(K, T.returns), options) : IsAsyncIterator3(T) ? AsyncIterator(FromSchemaType(K, T.items), options) : IsIterator3(T) ? Iterator(FromSchemaType(K, T.items), options) : IsIntersect(T) ? Intersect(FromRest2(K, T.allOf), options) : IsUnion(T) ? Union(FromRest2(K, T.anyOf), options) : IsTuple(T) ? Tuple(FromRest2(K, T.items ?? []), options) : IsObject3(T) ? Object2(FromProperties3(K, T.properties), options) : IsArray3(T) ? Array2(FromSchemaType(K, T.items), options) : IsPromise2(T) ? Promise2(FromSchemaType(K, T.item), options) : T;
  }
  function MappedFunctionReturnType(K, T) {
    const Acc = {};
    for (const L of K)
      Acc[L] = FromSchemaType(L, T);
    return Acc;
  }
  function Mapped(key, map3, options) {
    const K = IsSchema(key) ? IndexPropertyKeys(key) : key;
    const RT = map3({ [Kind]: "MappedKey", keys: K });
    const R = MappedFunctionReturnType(K, RT);
    return Object2(R, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/optional/optional.mjs
  function RemoveOptional(schema) {
    return CreateType(Discard(schema, [OptionalKind]));
  }
  function AddOptional(schema) {
    return CreateType({ ...schema, [OptionalKind]: "Optional" });
  }
  function OptionalWithFlag(schema, F) {
    return F === false ? RemoveOptional(schema) : AddOptional(schema);
  }
  function Optional(schema, enable) {
    const F = enable ?? true;
    return IsMappedResult(schema) ? OptionalFromMappedResult(schema, F) : OptionalWithFlag(schema, F);
  }

  // node_modules/@sinclair/typebox/build/esm/type/optional/optional-from-mapped-result.mjs
  function FromProperties4(P, F) {
    const Acc = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(P))
      Acc[K2] = Optional(P[K2], F);
    return Acc;
  }
  function FromMappedResult4(R, F) {
    return FromProperties4(R.properties, F);
  }
  function OptionalFromMappedResult(R, F) {
    const P = FromMappedResult4(R, F);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intersect/intersect-create.mjs
  function IntersectCreate(T, options = {}) {
    const allObjects = T.every((schema) => IsObject3(schema));
    const clonedUnevaluatedProperties = IsSchema(options.unevaluatedProperties) ? { unevaluatedProperties: options.unevaluatedProperties } : {};
    return CreateType(options.unevaluatedProperties === false || IsSchema(options.unevaluatedProperties) || allObjects ? { ...clonedUnevaluatedProperties, [Kind]: "Intersect", type: "object", allOf: T } : { ...clonedUnevaluatedProperties, [Kind]: "Intersect", allOf: T }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intersect/intersect-evaluated.mjs
  function IsIntersectOptional(types) {
    return types.every((left) => IsOptional(left));
  }
  function RemoveOptionalFromType2(type) {
    return Discard(type, [OptionalKind]);
  }
  function RemoveOptionalFromRest2(types) {
    return types.map((left) => IsOptional(left) ? RemoveOptionalFromType2(left) : left);
  }
  function ResolveIntersect(types, options) {
    return IsIntersectOptional(types) ? Optional(IntersectCreate(RemoveOptionalFromRest2(types), options)) : IntersectCreate(RemoveOptionalFromRest2(types), options);
  }
  function IntersectEvaluated(types, options = {}) {
    if (types.length === 1)
      return CreateType(types[0], options);
    if (types.length === 0)
      return Never(options);
    if (types.some((schema) => IsTransform(schema)))
      throw new Error("Cannot intersect transform types");
    return ResolveIntersect(types, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intersect/intersect.mjs
  function Intersect(types, options) {
    if (types.length === 1)
      return CreateType(types[0], options);
    if (types.length === 0)
      return Never(options);
    if (types.some((schema) => IsTransform(schema)))
      throw new Error("Cannot intersect transform types");
    return IntersectCreate(types, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/ref/ref.mjs
  function Ref(...args) {
    const [$ref, options] = typeof args[0] === "string" ? [args[0], args[1]] : [args[0].$id, args[1]];
    if (typeof $ref !== "string")
      throw new TypeBoxError("Ref: $ref must be a string");
    return CreateType({ [Kind]: "Ref", $ref }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/awaited/awaited.mjs
  function FromComputed(target, parameters) {
    return Computed("Awaited", [Computed(target, parameters)]);
  }
  function FromRef($ref) {
    return Computed("Awaited", [Ref($ref)]);
  }
  function FromIntersect2(types) {
    return Intersect(FromRest3(types));
  }
  function FromUnion4(types) {
    return Union(FromRest3(types));
  }
  function FromPromise(type) {
    return Awaited(type);
  }
  function FromRest3(types) {
    return types.map((type) => Awaited(type));
  }
  function Awaited(type, options) {
    return CreateType(IsComputed(type) ? FromComputed(type.target, type.parameters) : IsIntersect(type) ? FromIntersect2(type.allOf) : IsUnion(type) ? FromUnion4(type.anyOf) : IsPromise2(type) ? FromPromise(type.item) : IsRef(type) ? FromRef(type.$ref) : type, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/keyof/keyof-property-keys.mjs
  function FromRest4(types) {
    const result = [];
    for (const L of types)
      result.push(KeyOfPropertyKeys(L));
    return result;
  }
  function FromIntersect3(types) {
    const propertyKeysArray = FromRest4(types);
    const propertyKeys = SetUnionMany(propertyKeysArray);
    return propertyKeys;
  }
  function FromUnion5(types) {
    const propertyKeysArray = FromRest4(types);
    const propertyKeys = SetIntersectMany(propertyKeysArray);
    return propertyKeys;
  }
  function FromTuple2(types) {
    return types.map((_, indexer) => indexer.toString());
  }
  function FromArray2(_) {
    return ["[number]"];
  }
  function FromProperties5(T) {
    return globalThis.Object.getOwnPropertyNames(T);
  }
  function FromPatternProperties(patternProperties) {
    if (!includePatternProperties)
      return [];
    const patternPropertyKeys = globalThis.Object.getOwnPropertyNames(patternProperties);
    return patternPropertyKeys.map((key) => {
      return key[0] === "^" && key[key.length - 1] === "$" ? key.slice(1, key.length - 1) : key;
    });
  }
  function KeyOfPropertyKeys(type) {
    return IsIntersect(type) ? FromIntersect3(type.allOf) : IsUnion(type) ? FromUnion5(type.anyOf) : IsTuple(type) ? FromTuple2(type.items ?? []) : IsArray3(type) ? FromArray2(type.items) : IsObject3(type) ? FromProperties5(type.properties) : IsRecord(type) ? FromPatternProperties(type.patternProperties) : [];
  }
  var includePatternProperties = false;
  function KeyOfPattern(schema) {
    includePatternProperties = true;
    const keys = KeyOfPropertyKeys(schema);
    includePatternProperties = false;
    const pattern = keys.map((key) => `(${key})`);
    return `^(${pattern.join("|")})$`;
  }

  // node_modules/@sinclair/typebox/build/esm/type/keyof/keyof.mjs
  function FromComputed2(target, parameters) {
    return Computed("KeyOf", [Computed(target, parameters)]);
  }
  function FromRef2($ref) {
    return Computed("KeyOf", [Ref($ref)]);
  }
  function KeyOfFromType(type, options) {
    const propertyKeys = KeyOfPropertyKeys(type);
    const propertyKeyTypes = KeyOfPropertyKeysToRest(propertyKeys);
    const result = UnionEvaluated(propertyKeyTypes);
    return CreateType(result, options);
  }
  function KeyOfPropertyKeysToRest(propertyKeys) {
    return propertyKeys.map((L) => L === "[number]" ? Number2() : Literal(L));
  }
  function KeyOf(type, options) {
    return IsComputed(type) ? FromComputed2(type.target, type.parameters) : IsRef(type) ? FromRef2(type.$ref) : IsMappedResult(type) ? KeyOfFromMappedResult(type, options) : KeyOfFromType(type, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/keyof/keyof-from-mapped-result.mjs
  function FromProperties6(properties, options) {
    const result = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(properties))
      result[K2] = KeyOf(properties[K2], Clone(options));
    return result;
  }
  function FromMappedResult5(mappedResult, options) {
    return FromProperties6(mappedResult.properties, options);
  }
  function KeyOfFromMappedResult(mappedResult, options) {
    const properties = FromMappedResult5(mappedResult, options);
    return MappedResult(properties);
  }

  // node_modules/@sinclair/typebox/build/esm/type/keyof/keyof-property-entries.mjs
  function KeyOfPropertyEntries(schema) {
    const keys = KeyOfPropertyKeys(schema);
    const schemas = IndexFromPropertyKeys(schema, keys);
    return keys.map((_, index) => [keys[index], schemas[index]]);
  }

  // node_modules/@sinclair/typebox/build/esm/type/composite/composite.mjs
  function CompositeKeys(T) {
    const Acc = [];
    for (const L of T)
      Acc.push(...KeyOfPropertyKeys(L));
    return SetDistinct(Acc);
  }
  function FilterNever(T) {
    return T.filter((L) => !IsNever(L));
  }
  function CompositeProperty(T, K) {
    const Acc = [];
    for (const L of T)
      Acc.push(...IndexFromPropertyKeys(L, [K]));
    return FilterNever(Acc);
  }
  function CompositeProperties(T, K) {
    const Acc = {};
    for (const L of K) {
      Acc[L] = IntersectEvaluated(CompositeProperty(T, L));
    }
    return Acc;
  }
  function Composite(T, options) {
    const K = CompositeKeys(T);
    const P = CompositeProperties(T, K);
    const R = Object2(P, options);
    return R;
  }

  // node_modules/@sinclair/typebox/build/esm/type/date/date.mjs
  function Date2(options) {
    return CreateType({ [Kind]: "Date", type: "Date" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/null/null.mjs
  function Null(options) {
    return CreateType({ [Kind]: "Null", type: "null" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/symbol/symbol.mjs
  function Symbol2(options) {
    return CreateType({ [Kind]: "Symbol", type: "symbol" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/undefined/undefined.mjs
  function Undefined(options) {
    return CreateType({ [Kind]: "Undefined", type: "undefined" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/uint8array/uint8array.mjs
  function Uint8Array2(options) {
    return CreateType({ [Kind]: "Uint8Array", type: "Uint8Array" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/unknown/unknown.mjs
  function Unknown(options) {
    return CreateType({ [Kind]: "Unknown" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/const/const.mjs
  function FromArray3(T) {
    return T.map((L) => FromValue(L, false));
  }
  function FromProperties7(value) {
    const Acc = {};
    for (const K of globalThis.Object.getOwnPropertyNames(value))
      Acc[K] = Readonly(FromValue(value[K], false));
    return Acc;
  }
  function ConditionalReadonly(T, root) {
    return root === true ? T : Readonly(T);
  }
  function FromValue(value, root) {
    return IsAsyncIterator(value) ? ConditionalReadonly(Any(), root) : IsIterator(value) ? ConditionalReadonly(Any(), root) : IsArray(value) ? Readonly(Tuple(FromArray3(value))) : IsUint8Array(value) ? Uint8Array2() : IsDate(value) ? Date2() : IsObject(value) ? ConditionalReadonly(Object2(FromProperties7(value)), root) : IsFunction(value) ? ConditionalReadonly(Function([], Unknown()), root) : IsUndefined(value) ? Undefined() : IsNull(value) ? Null() : IsSymbol(value) ? Symbol2() : IsBigInt(value) ? BigInt2() : IsNumber(value) ? Literal(value) : IsBoolean(value) ? Literal(value) : IsString(value) ? Literal(value) : Object2({});
  }
  function Const(T, options) {
    return CreateType(FromValue(T, true), options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/constructor-parameters/constructor-parameters.mjs
  function ConstructorParameters(schema, options) {
    return IsConstructor(schema) ? Tuple(schema.parameters, options) : Never(options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/enum/enum.mjs
  function Enum(item, options) {
    if (IsUndefined(item))
      throw new Error("Enum undefined or empty");
    const values1 = globalThis.Object.getOwnPropertyNames(item).filter((key) => isNaN(key)).map((key) => item[key]);
    const values2 = [...new Set(values1)];
    const anyOf = values2.map((value) => Literal(value));
    return Union(anyOf, { ...options, [Hint]: "Enum" });
  }

  // node_modules/@sinclair/typebox/build/esm/type/extends/extends-check.mjs
  class ExtendsResolverError extends TypeBoxError {
  }
  var ExtendsResult;
  (function(ExtendsResult2) {
    ExtendsResult2[ExtendsResult2["Union"] = 0] = "Union";
    ExtendsResult2[ExtendsResult2["True"] = 1] = "True";
    ExtendsResult2[ExtendsResult2["False"] = 2] = "False";
  })(ExtendsResult || (ExtendsResult = {}));
  function IntoBooleanResult(result) {
    return result === ExtendsResult.False ? result : ExtendsResult.True;
  }
  function Throw(message) {
    throw new ExtendsResolverError(message);
  }
  function IsStructuralRight(right) {
    return exports_type.IsNever(right) || exports_type.IsIntersect(right) || exports_type.IsUnion(right) || exports_type.IsUnknown(right) || exports_type.IsAny(right);
  }
  function StructuralRight(left, right) {
    return exports_type.IsNever(right) ? FromNeverRight(left, right) : exports_type.IsIntersect(right) ? FromIntersectRight(left, right) : exports_type.IsUnion(right) ? FromUnionRight(left, right) : exports_type.IsUnknown(right) ? FromUnknownRight(left, right) : exports_type.IsAny(right) ? FromAnyRight(left, right) : Throw("StructuralRight");
  }
  function FromAnyRight(left, right) {
    return ExtendsResult.True;
  }
  function FromAny(left, right) {
    return exports_type.IsIntersect(right) ? FromIntersectRight(left, right) : exports_type.IsUnion(right) && right.anyOf.some((schema) => exports_type.IsAny(schema) || exports_type.IsUnknown(schema)) ? ExtendsResult.True : exports_type.IsUnion(right) ? ExtendsResult.Union : exports_type.IsUnknown(right) ? ExtendsResult.True : exports_type.IsAny(right) ? ExtendsResult.True : ExtendsResult.Union;
  }
  function FromArrayRight(left, right) {
    return exports_type.IsUnknown(left) ? ExtendsResult.False : exports_type.IsAny(left) ? ExtendsResult.Union : exports_type.IsNever(left) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromArray4(left, right) {
    return exports_type.IsObject(right) && IsObjectArrayLike(right) ? ExtendsResult.True : IsStructuralRight(right) ? StructuralRight(left, right) : !exports_type.IsArray(right) ? ExtendsResult.False : IntoBooleanResult(Visit3(left.items, right.items));
  }
  function FromAsyncIterator(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : !exports_type.IsAsyncIterator(right) ? ExtendsResult.False : IntoBooleanResult(Visit3(left.items, right.items));
  }
  function FromBigInt(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsBigInt(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromBooleanRight(left, right) {
    return exports_type.IsLiteralBoolean(left) ? ExtendsResult.True : exports_type.IsBoolean(left) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromBoolean(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsBoolean(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromConstructor(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : !exports_type.IsConstructor(right) ? ExtendsResult.False : left.parameters.length > right.parameters.length ? ExtendsResult.False : !left.parameters.every((schema, index) => IntoBooleanResult(Visit3(right.parameters[index], schema)) === ExtendsResult.True) ? ExtendsResult.False : IntoBooleanResult(Visit3(left.returns, right.returns));
  }
  function FromDate(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsDate(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromFunction(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : !exports_type.IsFunction(right) ? ExtendsResult.False : left.parameters.length > right.parameters.length ? ExtendsResult.False : !left.parameters.every((schema, index) => IntoBooleanResult(Visit3(right.parameters[index], schema)) === ExtendsResult.True) ? ExtendsResult.False : IntoBooleanResult(Visit3(left.returns, right.returns));
  }
  function FromIntegerRight(left, right) {
    return exports_type.IsLiteral(left) && exports_value.IsNumber(left.const) ? ExtendsResult.True : exports_type.IsNumber(left) || exports_type.IsInteger(left) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromInteger(left, right) {
    return exports_type.IsInteger(right) || exports_type.IsNumber(right) ? ExtendsResult.True : IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : ExtendsResult.False;
  }
  function FromIntersectRight(left, right) {
    return right.allOf.every((schema) => Visit3(left, schema) === ExtendsResult.True) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromIntersect4(left, right) {
    return left.allOf.some((schema) => Visit3(schema, right) === ExtendsResult.True) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromIterator(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : !exports_type.IsIterator(right) ? ExtendsResult.False : IntoBooleanResult(Visit3(left.items, right.items));
  }
  function FromLiteral2(left, right) {
    return exports_type.IsLiteral(right) && right.const === left.const ? ExtendsResult.True : IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsString(right) ? FromStringRight(left, right) : exports_type.IsNumber(right) ? FromNumberRight(left, right) : exports_type.IsInteger(right) ? FromIntegerRight(left, right) : exports_type.IsBoolean(right) ? FromBooleanRight(left, right) : ExtendsResult.False;
  }
  function FromNeverRight(left, right) {
    return ExtendsResult.False;
  }
  function FromNever(left, right) {
    return ExtendsResult.True;
  }
  function UnwrapTNot(schema) {
    let [current, depth] = [schema, 0];
    while (true) {
      if (!exports_type.IsNot(current))
        break;
      current = current.not;
      depth += 1;
    }
    return depth % 2 === 0 ? current : Unknown();
  }
  function FromNot(left, right) {
    return exports_type.IsNot(left) ? Visit3(UnwrapTNot(left), right) : exports_type.IsNot(right) ? Visit3(left, UnwrapTNot(right)) : Throw("Invalid fallthrough for Not");
  }
  function FromNull(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsNull(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromNumberRight(left, right) {
    return exports_type.IsLiteralNumber(left) ? ExtendsResult.True : exports_type.IsNumber(left) || exports_type.IsInteger(left) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromNumber(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsInteger(right) || exports_type.IsNumber(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function IsObjectPropertyCount(schema, count) {
    return Object.getOwnPropertyNames(schema.properties).length === count;
  }
  function IsObjectStringLike(schema) {
    return IsObjectArrayLike(schema);
  }
  function IsObjectSymbolLike(schema) {
    return IsObjectPropertyCount(schema, 0) || IsObjectPropertyCount(schema, 1) && "description" in schema.properties && exports_type.IsUnion(schema.properties.description) && schema.properties.description.anyOf.length === 2 && (exports_type.IsString(schema.properties.description.anyOf[0]) && exports_type.IsUndefined(schema.properties.description.anyOf[1]) || exports_type.IsString(schema.properties.description.anyOf[1]) && exports_type.IsUndefined(schema.properties.description.anyOf[0]));
  }
  function IsObjectNumberLike(schema) {
    return IsObjectPropertyCount(schema, 0);
  }
  function IsObjectBooleanLike(schema) {
    return IsObjectPropertyCount(schema, 0);
  }
  function IsObjectBigIntLike(schema) {
    return IsObjectPropertyCount(schema, 0);
  }
  function IsObjectDateLike(schema) {
    return IsObjectPropertyCount(schema, 0);
  }
  function IsObjectUint8ArrayLike(schema) {
    return IsObjectArrayLike(schema);
  }
  function IsObjectFunctionLike(schema) {
    const length = Number2();
    return IsObjectPropertyCount(schema, 0) || IsObjectPropertyCount(schema, 1) && "length" in schema.properties && IntoBooleanResult(Visit3(schema.properties["length"], length)) === ExtendsResult.True;
  }
  function IsObjectConstructorLike(schema) {
    return IsObjectPropertyCount(schema, 0);
  }
  function IsObjectArrayLike(schema) {
    const length = Number2();
    return IsObjectPropertyCount(schema, 0) || IsObjectPropertyCount(schema, 1) && "length" in schema.properties && IntoBooleanResult(Visit3(schema.properties["length"], length)) === ExtendsResult.True;
  }
  function IsObjectPromiseLike(schema) {
    const then = Function([Any()], Any());
    return IsObjectPropertyCount(schema, 0) || IsObjectPropertyCount(schema, 1) && "then" in schema.properties && IntoBooleanResult(Visit3(schema.properties["then"], then)) === ExtendsResult.True;
  }
  function Property(left, right) {
    return Visit3(left, right) === ExtendsResult.False ? ExtendsResult.False : exports_type.IsOptional(left) && !exports_type.IsOptional(right) ? ExtendsResult.False : ExtendsResult.True;
  }
  function FromObjectRight(left, right) {
    return exports_type.IsUnknown(left) ? ExtendsResult.False : exports_type.IsAny(left) ? ExtendsResult.Union : exports_type.IsNever(left) || exports_type.IsLiteralString(left) && IsObjectStringLike(right) || exports_type.IsLiteralNumber(left) && IsObjectNumberLike(right) || exports_type.IsLiteralBoolean(left) && IsObjectBooleanLike(right) || exports_type.IsSymbol(left) && IsObjectSymbolLike(right) || exports_type.IsBigInt(left) && IsObjectBigIntLike(right) || exports_type.IsString(left) && IsObjectStringLike(right) || exports_type.IsSymbol(left) && IsObjectSymbolLike(right) || exports_type.IsNumber(left) && IsObjectNumberLike(right) || exports_type.IsInteger(left) && IsObjectNumberLike(right) || exports_type.IsBoolean(left) && IsObjectBooleanLike(right) || exports_type.IsUint8Array(left) && IsObjectUint8ArrayLike(right) || exports_type.IsDate(left) && IsObjectDateLike(right) || exports_type.IsConstructor(left) && IsObjectConstructorLike(right) || exports_type.IsFunction(left) && IsObjectFunctionLike(right) ? ExtendsResult.True : exports_type.IsRecord(left) && exports_type.IsString(RecordKey(left)) ? (() => {
      return right[Hint] === "Record" ? ExtendsResult.True : ExtendsResult.False;
    })() : exports_type.IsRecord(left) && exports_type.IsNumber(RecordKey(left)) ? (() => {
      return IsObjectPropertyCount(right, 0) ? ExtendsResult.True : ExtendsResult.False;
    })() : ExtendsResult.False;
  }
  function FromObject(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : !exports_type.IsObject(right) ? ExtendsResult.False : (() => {
      for (const key of Object.getOwnPropertyNames(right.properties)) {
        if (!(key in left.properties) && !exports_type.IsOptional(right.properties[key])) {
          return ExtendsResult.False;
        }
        if (exports_type.IsOptional(right.properties[key])) {
          return ExtendsResult.True;
        }
        if (Property(left.properties[key], right.properties[key]) === ExtendsResult.False) {
          return ExtendsResult.False;
        }
      }
      return ExtendsResult.True;
    })();
  }
  function FromPromise2(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) && IsObjectPromiseLike(right) ? ExtendsResult.True : !exports_type.IsPromise(right) ? ExtendsResult.False : IntoBooleanResult(Visit3(left.item, right.item));
  }
  function RecordKey(schema) {
    return PatternNumberExact in schema.patternProperties ? Number2() : (PatternStringExact in schema.patternProperties) ? String2() : Throw("Unknown record key pattern");
  }
  function RecordValue(schema) {
    return PatternNumberExact in schema.patternProperties ? schema.patternProperties[PatternNumberExact] : (PatternStringExact in schema.patternProperties) ? schema.patternProperties[PatternStringExact] : Throw("Unable to get record value schema");
  }
  function FromRecordRight(left, right) {
    const [Key, Value] = [RecordKey(right), RecordValue(right)];
    return exports_type.IsLiteralString(left) && exports_type.IsNumber(Key) && IntoBooleanResult(Visit3(left, Value)) === ExtendsResult.True ? ExtendsResult.True : exports_type.IsUint8Array(left) && exports_type.IsNumber(Key) ? Visit3(left, Value) : exports_type.IsString(left) && exports_type.IsNumber(Key) ? Visit3(left, Value) : exports_type.IsArray(left) && exports_type.IsNumber(Key) ? Visit3(left, Value) : exports_type.IsObject(left) ? (() => {
      for (const key of Object.getOwnPropertyNames(left.properties)) {
        if (Property(Value, left.properties[key]) === ExtendsResult.False) {
          return ExtendsResult.False;
        }
      }
      return ExtendsResult.True;
    })() : ExtendsResult.False;
  }
  function FromRecord(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : !exports_type.IsRecord(right) ? ExtendsResult.False : Visit3(RecordValue(left), RecordValue(right));
  }
  function FromRegExp(left, right) {
    const L = exports_type.IsRegExp(left) ? String2() : left;
    const R = exports_type.IsRegExp(right) ? String2() : right;
    return Visit3(L, R);
  }
  function FromStringRight(left, right) {
    return exports_type.IsLiteral(left) && exports_value.IsString(left.const) ? ExtendsResult.True : exports_type.IsString(left) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromString(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsString(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromSymbol(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsSymbol(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromTemplateLiteral2(left, right) {
    return exports_type.IsTemplateLiteral(left) ? Visit3(TemplateLiteralToUnion(left), right) : exports_type.IsTemplateLiteral(right) ? Visit3(left, TemplateLiteralToUnion(right)) : Throw("Invalid fallthrough for TemplateLiteral");
  }
  function IsArrayOfTuple(left, right) {
    return exports_type.IsArray(right) && left.items !== undefined && left.items.every((schema) => Visit3(schema, right.items) === ExtendsResult.True);
  }
  function FromTupleRight(left, right) {
    return exports_type.IsNever(left) ? ExtendsResult.True : exports_type.IsUnknown(left) ? ExtendsResult.False : exports_type.IsAny(left) ? ExtendsResult.Union : ExtendsResult.False;
  }
  function FromTuple3(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) && IsObjectArrayLike(right) ? ExtendsResult.True : exports_type.IsArray(right) && IsArrayOfTuple(left, right) ? ExtendsResult.True : !exports_type.IsTuple(right) ? ExtendsResult.False : exports_value.IsUndefined(left.items) && !exports_value.IsUndefined(right.items) || !exports_value.IsUndefined(left.items) && exports_value.IsUndefined(right.items) ? ExtendsResult.False : exports_value.IsUndefined(left.items) && !exports_value.IsUndefined(right.items) ? ExtendsResult.True : left.items.every((schema, index) => Visit3(schema, right.items[index]) === ExtendsResult.True) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromUint8Array(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsUint8Array(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromUndefined(left, right) {
    return IsStructuralRight(right) ? StructuralRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsRecord(right) ? FromRecordRight(left, right) : exports_type.IsVoid(right) ? FromVoidRight(left, right) : exports_type.IsUndefined(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromUnionRight(left, right) {
    return right.anyOf.some((schema) => Visit3(left, schema) === ExtendsResult.True) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromUnion6(left, right) {
    return left.anyOf.every((schema) => Visit3(schema, right) === ExtendsResult.True) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromUnknownRight(left, right) {
    return ExtendsResult.True;
  }
  function FromUnknown(left, right) {
    return exports_type.IsNever(right) ? FromNeverRight(left, right) : exports_type.IsIntersect(right) ? FromIntersectRight(left, right) : exports_type.IsUnion(right) ? FromUnionRight(left, right) : exports_type.IsAny(right) ? FromAnyRight(left, right) : exports_type.IsString(right) ? FromStringRight(left, right) : exports_type.IsNumber(right) ? FromNumberRight(left, right) : exports_type.IsInteger(right) ? FromIntegerRight(left, right) : exports_type.IsBoolean(right) ? FromBooleanRight(left, right) : exports_type.IsArray(right) ? FromArrayRight(left, right) : exports_type.IsTuple(right) ? FromTupleRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsUnknown(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromVoidRight(left, right) {
    return exports_type.IsUndefined(left) ? ExtendsResult.True : exports_type.IsUndefined(left) ? ExtendsResult.True : ExtendsResult.False;
  }
  function FromVoid(left, right) {
    return exports_type.IsIntersect(right) ? FromIntersectRight(left, right) : exports_type.IsUnion(right) ? FromUnionRight(left, right) : exports_type.IsUnknown(right) ? FromUnknownRight(left, right) : exports_type.IsAny(right) ? FromAnyRight(left, right) : exports_type.IsObject(right) ? FromObjectRight(left, right) : exports_type.IsVoid(right) ? ExtendsResult.True : ExtendsResult.False;
  }
  function Visit3(left, right) {
    return exports_type.IsTemplateLiteral(left) || exports_type.IsTemplateLiteral(right) ? FromTemplateLiteral2(left, right) : exports_type.IsRegExp(left) || exports_type.IsRegExp(right) ? FromRegExp(left, right) : exports_type.IsNot(left) || exports_type.IsNot(right) ? FromNot(left, right) : exports_type.IsAny(left) ? FromAny(left, right) : exports_type.IsArray(left) ? FromArray4(left, right) : exports_type.IsBigInt(left) ? FromBigInt(left, right) : exports_type.IsBoolean(left) ? FromBoolean(left, right) : exports_type.IsAsyncIterator(left) ? FromAsyncIterator(left, right) : exports_type.IsConstructor(left) ? FromConstructor(left, right) : exports_type.IsDate(left) ? FromDate(left, right) : exports_type.IsFunction(left) ? FromFunction(left, right) : exports_type.IsInteger(left) ? FromInteger(left, right) : exports_type.IsIntersect(left) ? FromIntersect4(left, right) : exports_type.IsIterator(left) ? FromIterator(left, right) : exports_type.IsLiteral(left) ? FromLiteral2(left, right) : exports_type.IsNever(left) ? FromNever(left, right) : exports_type.IsNull(left) ? FromNull(left, right) : exports_type.IsNumber(left) ? FromNumber(left, right) : exports_type.IsObject(left) ? FromObject(left, right) : exports_type.IsRecord(left) ? FromRecord(left, right) : exports_type.IsString(left) ? FromString(left, right) : exports_type.IsSymbol(left) ? FromSymbol(left, right) : exports_type.IsTuple(left) ? FromTuple3(left, right) : exports_type.IsPromise(left) ? FromPromise2(left, right) : exports_type.IsUint8Array(left) ? FromUint8Array(left, right) : exports_type.IsUndefined(left) ? FromUndefined(left, right) : exports_type.IsUnion(left) ? FromUnion6(left, right) : exports_type.IsUnknown(left) ? FromUnknown(left, right) : exports_type.IsVoid(left) ? FromVoid(left, right) : Throw(`Unknown left type operand '${left[Kind]}'`);
  }
  function ExtendsCheck(left, right) {
    return Visit3(left, right);
  }

  // node_modules/@sinclair/typebox/build/esm/type/extends/extends-from-mapped-result.mjs
  function FromProperties8(P, Right, True, False, options) {
    const Acc = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(P))
      Acc[K2] = Extends(P[K2], Right, True, False, Clone(options));
    return Acc;
  }
  function FromMappedResult6(Left, Right, True, False, options) {
    return FromProperties8(Left.properties, Right, True, False, options);
  }
  function ExtendsFromMappedResult(Left, Right, True, False, options) {
    const P = FromMappedResult6(Left, Right, True, False, options);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/extends/extends.mjs
  function ExtendsResolve(left, right, trueType, falseType) {
    const R = ExtendsCheck(left, right);
    return R === ExtendsResult.Union ? Union([trueType, falseType]) : R === ExtendsResult.True ? trueType : falseType;
  }
  function Extends(L, R, T, F, options) {
    return IsMappedResult(L) ? ExtendsFromMappedResult(L, R, T, F, options) : IsMappedKey(L) ? CreateType(ExtendsFromMappedKey(L, R, T, F, options)) : CreateType(ExtendsResolve(L, R, T, F), options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/extends/extends-from-mapped-key.mjs
  function FromPropertyKey(K, U, L, R, options) {
    return {
      [K]: Extends(Literal(K), U, L, R, Clone(options))
    };
  }
  function FromPropertyKeys(K, U, L, R, options) {
    return K.reduce((Acc, LK) => {
      return { ...Acc, ...FromPropertyKey(LK, U, L, R, options) };
    }, {});
  }
  function FromMappedKey2(K, U, L, R, options) {
    return FromPropertyKeys(K.keys, U, L, R, options);
  }
  function ExtendsFromMappedKey(T, U, L, R, options) {
    const P = FromMappedKey2(T, U, L, R, options);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/extends/extends-undefined.mjs
  function Intersect2(schema) {
    return schema.allOf.every((schema2) => ExtendsUndefinedCheck(schema2));
  }
  function Union2(schema) {
    return schema.anyOf.some((schema2) => ExtendsUndefinedCheck(schema2));
  }
  function Not(schema) {
    return !ExtendsUndefinedCheck(schema.not);
  }
  function ExtendsUndefinedCheck(schema) {
    return schema[Kind] === "Intersect" ? Intersect2(schema) : schema[Kind] === "Union" ? Union2(schema) : schema[Kind] === "Not" ? Not(schema) : schema[Kind] === "Undefined" ? true : false;
  }

  // node_modules/@sinclair/typebox/build/esm/type/exclude/exclude-from-template-literal.mjs
  function ExcludeFromTemplateLiteral(L, R) {
    return Exclude(TemplateLiteralToUnion(L), R);
  }

  // node_modules/@sinclair/typebox/build/esm/type/exclude/exclude.mjs
  function ExcludeRest(L, R) {
    const excluded = L.filter((inner) => ExtendsCheck(inner, R) === ExtendsResult.False);
    return excluded.length === 1 ? excluded[0] : Union(excluded);
  }
  function Exclude(L, R, options = {}) {
    if (IsTemplateLiteral(L))
      return CreateType(ExcludeFromTemplateLiteral(L, R), options);
    if (IsMappedResult(L))
      return CreateType(ExcludeFromMappedResult(L, R), options);
    return CreateType(IsUnion(L) ? ExcludeRest(L.anyOf, R) : ExtendsCheck(L, R) !== ExtendsResult.False ? Never() : L, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/exclude/exclude-from-mapped-result.mjs
  function FromProperties9(P, U) {
    const Acc = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(P))
      Acc[K2] = Exclude(P[K2], U);
    return Acc;
  }
  function FromMappedResult7(R, T) {
    return FromProperties9(R.properties, T);
  }
  function ExcludeFromMappedResult(R, T) {
    const P = FromMappedResult7(R, T);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/extract/extract-from-template-literal.mjs
  function ExtractFromTemplateLiteral(L, R) {
    return Extract(TemplateLiteralToUnion(L), R);
  }

  // node_modules/@sinclair/typebox/build/esm/type/extract/extract.mjs
  function ExtractRest(L, R) {
    const extracted = L.filter((inner) => ExtendsCheck(inner, R) !== ExtendsResult.False);
    return extracted.length === 1 ? extracted[0] : Union(extracted);
  }
  function Extract(L, R, options) {
    if (IsTemplateLiteral(L))
      return CreateType(ExtractFromTemplateLiteral(L, R), options);
    if (IsMappedResult(L))
      return CreateType(ExtractFromMappedResult(L, R), options);
    return CreateType(IsUnion(L) ? ExtractRest(L.anyOf, R) : ExtendsCheck(L, R) !== ExtendsResult.False ? L : Never(), options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/extract/extract-from-mapped-result.mjs
  function FromProperties10(P, T) {
    const Acc = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(P))
      Acc[K2] = Extract(P[K2], T);
    return Acc;
  }
  function FromMappedResult8(R, T) {
    return FromProperties10(R.properties, T);
  }
  function ExtractFromMappedResult(R, T) {
    const P = FromMappedResult8(R, T);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/instance-type/instance-type.mjs
  function InstanceType(schema, options) {
    return IsConstructor(schema) ? CreateType(schema.returns, options) : Never(options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/readonly-optional/readonly-optional.mjs
  function ReadonlyOptional(schema) {
    return Readonly(Optional(schema));
  }

  // node_modules/@sinclair/typebox/build/esm/type/record/record.mjs
  function RecordCreateFromPattern(pattern, T, options) {
    return CreateType({ [Kind]: "Record", type: "object", patternProperties: { [pattern]: T } }, options);
  }
  function RecordCreateFromKeys(K, T, options) {
    const result = {};
    for (const K2 of K)
      result[K2] = T;
    return Object2(result, { ...options, [Hint]: "Record" });
  }
  function FromTemplateLiteralKey(K, T, options) {
    return IsTemplateLiteralFinite(K) ? RecordCreateFromKeys(IndexPropertyKeys(K), T, options) : RecordCreateFromPattern(K.pattern, T, options);
  }
  function FromUnionKey(key, type, options) {
    return RecordCreateFromKeys(IndexPropertyKeys(Union(key)), type, options);
  }
  function FromLiteralKey(key, type, options) {
    return RecordCreateFromKeys([key.toString()], type, options);
  }
  function FromRegExpKey(key, type, options) {
    return RecordCreateFromPattern(key.source, type, options);
  }
  function FromStringKey(key, type, options) {
    const pattern = IsUndefined(key.pattern) ? PatternStringExact : key.pattern;
    return RecordCreateFromPattern(pattern, type, options);
  }
  function FromAnyKey(_, type, options) {
    return RecordCreateFromPattern(PatternStringExact, type, options);
  }
  function FromNeverKey(_key, type, options) {
    return RecordCreateFromPattern(PatternNeverExact, type, options);
  }
  function FromBooleanKey(_key, type, options) {
    return Object2({ true: type, false: type }, options);
  }
  function FromIntegerKey(_key, type, options) {
    return RecordCreateFromPattern(PatternNumberExact, type, options);
  }
  function FromNumberKey(_, type, options) {
    return RecordCreateFromPattern(PatternNumberExact, type, options);
  }
  function Record(key, type, options = {}) {
    return IsUnion(key) ? FromUnionKey(key.anyOf, type, options) : IsTemplateLiteral(key) ? FromTemplateLiteralKey(key, type, options) : IsLiteral(key) ? FromLiteralKey(key.const, type, options) : IsBoolean3(key) ? FromBooleanKey(key, type, options) : IsInteger2(key) ? FromIntegerKey(key, type, options) : IsNumber3(key) ? FromNumberKey(key, type, options) : IsRegExp2(key) ? FromRegExpKey(key, type, options) : IsString3(key) ? FromStringKey(key, type, options) : IsAny(key) ? FromAnyKey(key, type, options) : IsNever(key) ? FromNeverKey(key, type, options) : Never(options);
  }
  function RecordPattern(record) {
    return globalThis.Object.getOwnPropertyNames(record.patternProperties)[0];
  }
  function RecordKey2(type) {
    const pattern = RecordPattern(type);
    return pattern === PatternStringExact ? String2() : pattern === PatternNumberExact ? Number2() : String2({ pattern });
  }
  function RecordValue2(type) {
    return type.patternProperties[RecordPattern(type)];
  }

  // node_modules/@sinclair/typebox/build/esm/type/instantiate/instantiate.mjs
  function FromConstructor2(args, type) {
    type.parameters = FromTypes(args, type.parameters);
    type.returns = FromType(args, type.returns);
    return type;
  }
  function FromFunction2(args, type) {
    type.parameters = FromTypes(args, type.parameters);
    type.returns = FromType(args, type.returns);
    return type;
  }
  function FromIntersect5(args, type) {
    type.allOf = FromTypes(args, type.allOf);
    return type;
  }
  function FromUnion7(args, type) {
    type.anyOf = FromTypes(args, type.anyOf);
    return type;
  }
  function FromTuple4(args, type) {
    if (IsUndefined(type.items))
      return type;
    type.items = FromTypes(args, type.items);
    return type;
  }
  function FromArray5(args, type) {
    type.items = FromType(args, type.items);
    return type;
  }
  function FromAsyncIterator2(args, type) {
    type.items = FromType(args, type.items);
    return type;
  }
  function FromIterator2(args, type) {
    type.items = FromType(args, type.items);
    return type;
  }
  function FromPromise3(args, type) {
    type.item = FromType(args, type.item);
    return type;
  }
  function FromObject2(args, type) {
    const mappedProperties = FromProperties11(args, type.properties);
    return { ...type, ...Object2(mappedProperties) };
  }
  function FromRecord2(args, type) {
    const mappedKey = FromType(args, RecordKey2(type));
    const mappedValue = FromType(args, RecordValue2(type));
    const result = Record(mappedKey, mappedValue);
    return { ...type, ...result };
  }
  function FromArgument(args, argument) {
    return argument.index in args ? args[argument.index] : Unknown();
  }
  function FromProperty2(args, type) {
    const isReadonly = IsReadonly(type);
    const isOptional = IsOptional(type);
    const mapped = FromType(args, type);
    return isReadonly && isOptional ? ReadonlyOptional(mapped) : isReadonly && !isOptional ? Readonly(mapped) : !isReadonly && isOptional ? Optional(mapped) : mapped;
  }
  function FromProperties11(args, properties) {
    return globalThis.Object.getOwnPropertyNames(properties).reduce((result, key) => {
      return { ...result, [key]: FromProperty2(args, properties[key]) };
    }, {});
  }
  function FromTypes(args, types) {
    return types.map((type) => FromType(args, type));
  }
  function FromType(args, type) {
    return IsConstructor(type) ? FromConstructor2(args, type) : IsFunction3(type) ? FromFunction2(args, type) : IsIntersect(type) ? FromIntersect5(args, type) : IsUnion(type) ? FromUnion7(args, type) : IsTuple(type) ? FromTuple4(args, type) : IsArray3(type) ? FromArray5(args, type) : IsAsyncIterator3(type) ? FromAsyncIterator2(args, type) : IsIterator3(type) ? FromIterator2(args, type) : IsPromise2(type) ? FromPromise3(args, type) : IsObject3(type) ? FromObject2(args, type) : IsRecord(type) ? FromRecord2(args, type) : IsArgument(type) ? FromArgument(args, type) : type;
  }
  function Instantiate(type, args) {
    return FromType(args, CloneType(type));
  }

  // node_modules/@sinclair/typebox/build/esm/type/integer/integer.mjs
  function Integer(options) {
    return CreateType({ [Kind]: "Integer", type: "integer" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intrinsic/intrinsic-from-mapped-key.mjs
  function MappedIntrinsicPropertyKey(K, M, options) {
    return {
      [K]: Intrinsic(Literal(K), M, Clone(options))
    };
  }
  function MappedIntrinsicPropertyKeys(K, M, options) {
    const result = K.reduce((Acc, L) => {
      return { ...Acc, ...MappedIntrinsicPropertyKey(L, M, options) };
    }, {});
    return result;
  }
  function MappedIntrinsicProperties(T, M, options) {
    return MappedIntrinsicPropertyKeys(T["keys"], M, options);
  }
  function IntrinsicFromMappedKey(T, M, options) {
    const P = MappedIntrinsicProperties(T, M, options);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intrinsic/intrinsic.mjs
  function ApplyUncapitalize(value) {
    const [first, rest] = [value.slice(0, 1), value.slice(1)];
    return [first.toLowerCase(), rest].join("");
  }
  function ApplyCapitalize(value) {
    const [first, rest] = [value.slice(0, 1), value.slice(1)];
    return [first.toUpperCase(), rest].join("");
  }
  function ApplyUppercase(value) {
    return value.toUpperCase();
  }
  function ApplyLowercase(value) {
    return value.toLowerCase();
  }
  function FromTemplateLiteral3(schema, mode, options) {
    const expression = TemplateLiteralParseExact(schema.pattern);
    const finite = IsTemplateLiteralExpressionFinite(expression);
    if (!finite)
      return { ...schema, pattern: FromLiteralValue(schema.pattern, mode) };
    const strings = [...TemplateLiteralExpressionGenerate(expression)];
    const literals = strings.map((value) => Literal(value));
    const mapped = FromRest5(literals, mode);
    const union = Union(mapped);
    return TemplateLiteral([union], options);
  }
  function FromLiteralValue(value, mode) {
    return typeof value === "string" ? mode === "Uncapitalize" ? ApplyUncapitalize(value) : mode === "Capitalize" ? ApplyCapitalize(value) : mode === "Uppercase" ? ApplyUppercase(value) : mode === "Lowercase" ? ApplyLowercase(value) : value : value.toString();
  }
  function FromRest5(T, M) {
    return T.map((L) => Intrinsic(L, M));
  }
  function Intrinsic(schema, mode, options = {}) {
    return IsMappedKey(schema) ? IntrinsicFromMappedKey(schema, mode, options) : IsTemplateLiteral(schema) ? FromTemplateLiteral3(schema, mode, options) : IsUnion(schema) ? Union(FromRest5(schema.anyOf, mode), options) : IsLiteral(schema) ? Literal(FromLiteralValue(schema.const, mode), options) : CreateType(schema, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intrinsic/capitalize.mjs
  function Capitalize(T, options = {}) {
    return Intrinsic(T, "Capitalize", options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intrinsic/lowercase.mjs
  function Lowercase(T, options = {}) {
    return Intrinsic(T, "Lowercase", options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intrinsic/uncapitalize.mjs
  function Uncapitalize(T, options = {}) {
    return Intrinsic(T, "Uncapitalize", options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/intrinsic/uppercase.mjs
  function Uppercase(T, options = {}) {
    return Intrinsic(T, "Uppercase", options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/omit/omit-from-mapped-result.mjs
  function FromProperties12(properties, propertyKeys, options) {
    const result = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(properties))
      result[K2] = Omit(properties[K2], propertyKeys, Clone(options));
    return result;
  }
  function FromMappedResult9(mappedResult, propertyKeys, options) {
    return FromProperties12(mappedResult.properties, propertyKeys, options);
  }
  function OmitFromMappedResult(mappedResult, propertyKeys, options) {
    const properties = FromMappedResult9(mappedResult, propertyKeys, options);
    return MappedResult(properties);
  }

  // node_modules/@sinclair/typebox/build/esm/type/omit/omit.mjs
  function FromIntersect6(types, propertyKeys) {
    return types.map((type) => OmitResolve(type, propertyKeys));
  }
  function FromUnion8(types, propertyKeys) {
    return types.map((type) => OmitResolve(type, propertyKeys));
  }
  function FromProperty3(properties, key) {
    const { [key]: _, ...R } = properties;
    return R;
  }
  function FromProperties13(properties, propertyKeys) {
    return propertyKeys.reduce((T, K2) => FromProperty3(T, K2), properties);
  }
  function FromObject3(type, propertyKeys, properties) {
    const options = Discard(type, [TransformKind, "$id", "required", "properties"]);
    const mappedProperties = FromProperties13(properties, propertyKeys);
    return Object2(mappedProperties, options);
  }
  function UnionFromPropertyKeys(propertyKeys) {
    const result = propertyKeys.reduce((result2, key) => IsLiteralValue(key) ? [...result2, Literal(key)] : result2, []);
    return Union(result);
  }
  function OmitResolve(type, propertyKeys) {
    return IsIntersect(type) ? Intersect(FromIntersect6(type.allOf, propertyKeys)) : IsUnion(type) ? Union(FromUnion8(type.anyOf, propertyKeys)) : IsObject3(type) ? FromObject3(type, propertyKeys, type.properties) : Object2({});
  }
  function Omit(type, key, options) {
    const typeKey = IsArray(key) ? UnionFromPropertyKeys(key) : key;
    const propertyKeys = IsSchema(key) ? IndexPropertyKeys(key) : key;
    const isTypeRef = IsRef(type);
    const isKeyRef = IsRef(key);
    return IsMappedResult(type) ? OmitFromMappedResult(type, propertyKeys, options) : IsMappedKey(key) ? OmitFromMappedKey(type, key, options) : isTypeRef && isKeyRef ? Computed("Omit", [type, typeKey], options) : !isTypeRef && isKeyRef ? Computed("Omit", [type, typeKey], options) : isTypeRef && !isKeyRef ? Computed("Omit", [type, typeKey], options) : CreateType({ ...OmitResolve(type, propertyKeys), ...options });
  }

  // node_modules/@sinclair/typebox/build/esm/type/omit/omit-from-mapped-key.mjs
  function FromPropertyKey2(type, key, options) {
    return { [key]: Omit(type, [key], Clone(options)) };
  }
  function FromPropertyKeys2(type, propertyKeys, options) {
    return propertyKeys.reduce((Acc, LK) => {
      return { ...Acc, ...FromPropertyKey2(type, LK, options) };
    }, {});
  }
  function FromMappedKey3(type, mappedKey, options) {
    return FromPropertyKeys2(type, mappedKey.keys, options);
  }
  function OmitFromMappedKey(type, mappedKey, options) {
    const properties = FromMappedKey3(type, mappedKey, options);
    return MappedResult(properties);
  }

  // node_modules/@sinclair/typebox/build/esm/type/pick/pick-from-mapped-result.mjs
  function FromProperties14(properties, propertyKeys, options) {
    const result = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(properties))
      result[K2] = Pick(properties[K2], propertyKeys, Clone(options));
    return result;
  }
  function FromMappedResult10(mappedResult, propertyKeys, options) {
    return FromProperties14(mappedResult.properties, propertyKeys, options);
  }
  function PickFromMappedResult(mappedResult, propertyKeys, options) {
    const properties = FromMappedResult10(mappedResult, propertyKeys, options);
    return MappedResult(properties);
  }

  // node_modules/@sinclair/typebox/build/esm/type/pick/pick.mjs
  function FromIntersect7(types, propertyKeys) {
    return types.map((type) => PickResolve(type, propertyKeys));
  }
  function FromUnion9(types, propertyKeys) {
    return types.map((type) => PickResolve(type, propertyKeys));
  }
  function FromProperties15(properties, propertyKeys) {
    const result = {};
    for (const K2 of propertyKeys)
      if (K2 in properties)
        result[K2] = properties[K2];
    return result;
  }
  function FromObject4(Type, keys, properties) {
    const options = Discard(Type, [TransformKind, "$id", "required", "properties"]);
    const mappedProperties = FromProperties15(properties, keys);
    return Object2(mappedProperties, options);
  }
  function UnionFromPropertyKeys2(propertyKeys) {
    const result = propertyKeys.reduce((result2, key) => IsLiteralValue(key) ? [...result2, Literal(key)] : result2, []);
    return Union(result);
  }
  function PickResolve(type, propertyKeys) {
    return IsIntersect(type) ? Intersect(FromIntersect7(type.allOf, propertyKeys)) : IsUnion(type) ? Union(FromUnion9(type.anyOf, propertyKeys)) : IsObject3(type) ? FromObject4(type, propertyKeys, type.properties) : Object2({});
  }
  function Pick(type, key, options) {
    const typeKey = IsArray(key) ? UnionFromPropertyKeys2(key) : key;
    const propertyKeys = IsSchema(key) ? IndexPropertyKeys(key) : key;
    const isTypeRef = IsRef(type);
    const isKeyRef = IsRef(key);
    return IsMappedResult(type) ? PickFromMappedResult(type, propertyKeys, options) : IsMappedKey(key) ? PickFromMappedKey(type, key, options) : isTypeRef && isKeyRef ? Computed("Pick", [type, typeKey], options) : !isTypeRef && isKeyRef ? Computed("Pick", [type, typeKey], options) : isTypeRef && !isKeyRef ? Computed("Pick", [type, typeKey], options) : CreateType({ ...PickResolve(type, propertyKeys), ...options });
  }

  // node_modules/@sinclair/typebox/build/esm/type/pick/pick-from-mapped-key.mjs
  function FromPropertyKey3(type, key, options) {
    return {
      [key]: Pick(type, [key], Clone(options))
    };
  }
  function FromPropertyKeys3(type, propertyKeys, options) {
    return propertyKeys.reduce((result, leftKey) => {
      return { ...result, ...FromPropertyKey3(type, leftKey, options) };
    }, {});
  }
  function FromMappedKey4(type, mappedKey, options) {
    return FromPropertyKeys3(type, mappedKey.keys, options);
  }
  function PickFromMappedKey(type, mappedKey, options) {
    const properties = FromMappedKey4(type, mappedKey, options);
    return MappedResult(properties);
  }

  // node_modules/@sinclair/typebox/build/esm/type/partial/partial.mjs
  function FromComputed3(target, parameters) {
    return Computed("Partial", [Computed(target, parameters)]);
  }
  function FromRef3($ref) {
    return Computed("Partial", [Ref($ref)]);
  }
  function FromProperties16(properties) {
    const partialProperties = {};
    for (const K of globalThis.Object.getOwnPropertyNames(properties))
      partialProperties[K] = Optional(properties[K]);
    return partialProperties;
  }
  function FromObject5(type, properties) {
    const options = Discard(type, [TransformKind, "$id", "required", "properties"]);
    const mappedProperties = FromProperties16(properties);
    return Object2(mappedProperties, options);
  }
  function FromRest6(types) {
    return types.map((type) => PartialResolve(type));
  }
  function PartialResolve(type) {
    return IsComputed(type) ? FromComputed3(type.target, type.parameters) : IsRef(type) ? FromRef3(type.$ref) : IsIntersect(type) ? Intersect(FromRest6(type.allOf)) : IsUnion(type) ? Union(FromRest6(type.anyOf)) : IsObject3(type) ? FromObject5(type, type.properties) : IsBigInt3(type) ? type : IsBoolean3(type) ? type : IsInteger2(type) ? type : IsLiteral(type) ? type : IsNull3(type) ? type : IsNumber3(type) ? type : IsString3(type) ? type : IsSymbol3(type) ? type : IsUndefined3(type) ? type : Object2({});
  }
  function Partial(type, options) {
    if (IsMappedResult(type)) {
      return PartialFromMappedResult(type, options);
    } else {
      return CreateType({ ...PartialResolve(type), ...options });
    }
  }

  // node_modules/@sinclair/typebox/build/esm/type/partial/partial-from-mapped-result.mjs
  function FromProperties17(K, options) {
    const Acc = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(K))
      Acc[K2] = Partial(K[K2], Clone(options));
    return Acc;
  }
  function FromMappedResult11(R, options) {
    return FromProperties17(R.properties, options);
  }
  function PartialFromMappedResult(R, options) {
    const P = FromMappedResult11(R, options);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/required/required.mjs
  function FromComputed4(target, parameters) {
    return Computed("Required", [Computed(target, parameters)]);
  }
  function FromRef4($ref) {
    return Computed("Required", [Ref($ref)]);
  }
  function FromProperties18(properties) {
    const requiredProperties = {};
    for (const K of globalThis.Object.getOwnPropertyNames(properties))
      requiredProperties[K] = Discard(properties[K], [OptionalKind]);
    return requiredProperties;
  }
  function FromObject6(type, properties) {
    const options = Discard(type, [TransformKind, "$id", "required", "properties"]);
    const mappedProperties = FromProperties18(properties);
    return Object2(mappedProperties, options);
  }
  function FromRest7(types) {
    return types.map((type) => RequiredResolve(type));
  }
  function RequiredResolve(type) {
    return IsComputed(type) ? FromComputed4(type.target, type.parameters) : IsRef(type) ? FromRef4(type.$ref) : IsIntersect(type) ? Intersect(FromRest7(type.allOf)) : IsUnion(type) ? Union(FromRest7(type.anyOf)) : IsObject3(type) ? FromObject6(type, type.properties) : IsBigInt3(type) ? type : IsBoolean3(type) ? type : IsInteger2(type) ? type : IsLiteral(type) ? type : IsNull3(type) ? type : IsNumber3(type) ? type : IsString3(type) ? type : IsSymbol3(type) ? type : IsUndefined3(type) ? type : Object2({});
  }
  function Required(type, options) {
    if (IsMappedResult(type)) {
      return RequiredFromMappedResult(type, options);
    } else {
      return CreateType({ ...RequiredResolve(type), ...options });
    }
  }

  // node_modules/@sinclair/typebox/build/esm/type/required/required-from-mapped-result.mjs
  function FromProperties19(P, options) {
    const Acc = {};
    for (const K2 of globalThis.Object.getOwnPropertyNames(P))
      Acc[K2] = Required(P[K2], options);
    return Acc;
  }
  function FromMappedResult12(R, options) {
    return FromProperties19(R.properties, options);
  }
  function RequiredFromMappedResult(R, options) {
    const P = FromMappedResult12(R, options);
    return MappedResult(P);
  }

  // node_modules/@sinclair/typebox/build/esm/type/module/compute.mjs
  function DereferenceParameters(moduleProperties, types) {
    return types.map((type) => {
      return IsRef(type) ? Dereference(moduleProperties, type.$ref) : FromType2(moduleProperties, type);
    });
  }
  function Dereference(moduleProperties, ref) {
    return ref in moduleProperties ? IsRef(moduleProperties[ref]) ? Dereference(moduleProperties, moduleProperties[ref].$ref) : FromType2(moduleProperties, moduleProperties[ref]) : Never();
  }
  function FromAwaited(parameters) {
    return Awaited(parameters[0]);
  }
  function FromIndex(parameters) {
    return Index(parameters[0], parameters[1]);
  }
  function FromKeyOf(parameters) {
    return KeyOf(parameters[0]);
  }
  function FromPartial(parameters) {
    return Partial(parameters[0]);
  }
  function FromOmit(parameters) {
    return Omit(parameters[0], parameters[1]);
  }
  function FromPick(parameters) {
    return Pick(parameters[0], parameters[1]);
  }
  function FromRequired(parameters) {
    return Required(parameters[0]);
  }
  function FromComputed5(moduleProperties, target, parameters) {
    const dereferenced = DereferenceParameters(moduleProperties, parameters);
    return target === "Awaited" ? FromAwaited(dereferenced) : target === "Index" ? FromIndex(dereferenced) : target === "KeyOf" ? FromKeyOf(dereferenced) : target === "Partial" ? FromPartial(dereferenced) : target === "Omit" ? FromOmit(dereferenced) : target === "Pick" ? FromPick(dereferenced) : target === "Required" ? FromRequired(dereferenced) : Never();
  }
  function FromArray6(moduleProperties, type) {
    return Array2(FromType2(moduleProperties, type));
  }
  function FromAsyncIterator3(moduleProperties, type) {
    return AsyncIterator(FromType2(moduleProperties, type));
  }
  function FromConstructor3(moduleProperties, parameters, instanceType) {
    return Constructor(FromTypes2(moduleProperties, parameters), FromType2(moduleProperties, instanceType));
  }
  function FromFunction3(moduleProperties, parameters, returnType) {
    return Function(FromTypes2(moduleProperties, parameters), FromType2(moduleProperties, returnType));
  }
  function FromIntersect8(moduleProperties, types) {
    return Intersect(FromTypes2(moduleProperties, types));
  }
  function FromIterator3(moduleProperties, type) {
    return Iterator(FromType2(moduleProperties, type));
  }
  function FromObject7(moduleProperties, properties) {
    return Object2(globalThis.Object.keys(properties).reduce((result, key) => {
      return { ...result, [key]: FromType2(moduleProperties, properties[key]) };
    }, {}));
  }
  function FromRecord3(moduleProperties, type) {
    const [value, pattern] = [FromType2(moduleProperties, RecordValue2(type)), RecordPattern(type)];
    const result = CloneType(type);
    result.patternProperties[pattern] = value;
    return result;
  }
  function FromTransform(moduleProperties, transform) {
    return IsRef(transform) ? { ...Dereference(moduleProperties, transform.$ref), [TransformKind]: transform[TransformKind] } : transform;
  }
  function FromTuple5(moduleProperties, types) {
    return Tuple(FromTypes2(moduleProperties, types));
  }
  function FromUnion10(moduleProperties, types) {
    return Union(FromTypes2(moduleProperties, types));
  }
  function FromTypes2(moduleProperties, types) {
    return types.map((type) => FromType2(moduleProperties, type));
  }
  function FromType2(moduleProperties, type) {
    return IsOptional(type) ? CreateType(FromType2(moduleProperties, Discard(type, [OptionalKind])), type) : IsReadonly(type) ? CreateType(FromType2(moduleProperties, Discard(type, [ReadonlyKind])), type) : IsTransform(type) ? CreateType(FromTransform(moduleProperties, type), type) : IsArray3(type) ? CreateType(FromArray6(moduleProperties, type.items), type) : IsAsyncIterator3(type) ? CreateType(FromAsyncIterator3(moduleProperties, type.items), type) : IsComputed(type) ? CreateType(FromComputed5(moduleProperties, type.target, type.parameters)) : IsConstructor(type) ? CreateType(FromConstructor3(moduleProperties, type.parameters, type.returns), type) : IsFunction3(type) ? CreateType(FromFunction3(moduleProperties, type.parameters, type.returns), type) : IsIntersect(type) ? CreateType(FromIntersect8(moduleProperties, type.allOf), type) : IsIterator3(type) ? CreateType(FromIterator3(moduleProperties, type.items), type) : IsObject3(type) ? CreateType(FromObject7(moduleProperties, type.properties), type) : IsRecord(type) ? CreateType(FromRecord3(moduleProperties, type)) : IsTuple(type) ? CreateType(FromTuple5(moduleProperties, type.items || []), type) : IsUnion(type) ? CreateType(FromUnion10(moduleProperties, type.anyOf), type) : type;
  }
  function ComputeType(moduleProperties, key) {
    return key in moduleProperties ? FromType2(moduleProperties, moduleProperties[key]) : Never();
  }
  function ComputeModuleProperties(moduleProperties) {
    return globalThis.Object.getOwnPropertyNames(moduleProperties).reduce((result, key) => {
      return { ...result, [key]: ComputeType(moduleProperties, key) };
    }, {});
  }

  // node_modules/@sinclair/typebox/build/esm/type/module/module.mjs
  class TModule {
    constructor($defs) {
      const computed = ComputeModuleProperties($defs);
      const identified = this.WithIdentifiers(computed);
      this.$defs = identified;
    }
    Import(key, options) {
      const $defs = { ...this.$defs, [key]: CreateType(this.$defs[key], options) };
      return CreateType({ [Kind]: "Import", $defs, $ref: key });
    }
    WithIdentifiers($defs) {
      return globalThis.Object.getOwnPropertyNames($defs).reduce((result, key) => {
        return { ...result, [key]: { ...$defs[key], $id: key } };
      }, {});
    }
  }
  function Module(properties) {
    return new TModule(properties);
  }

  // node_modules/@sinclair/typebox/build/esm/type/not/not.mjs
  function Not2(type, options) {
    return CreateType({ [Kind]: "Not", not: type }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/parameters/parameters.mjs
  function Parameters(schema, options) {
    return IsFunction3(schema) ? Tuple(schema.parameters, options) : Never();
  }

  // node_modules/@sinclair/typebox/build/esm/type/recursive/recursive.mjs
  var Ordinal = 0;
  function Recursive(callback, options = {}) {
    if (IsUndefined(options.$id))
      options.$id = `T${Ordinal++}`;
    const thisType = CloneType(callback({ [Kind]: "This", $ref: `${options.$id}` }));
    thisType.$id = options.$id;
    return CreateType({ [Hint]: "Recursive", ...thisType }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/regexp/regexp.mjs
  function RegExp2(unresolved, options) {
    const expr = IsString(unresolved) ? new globalThis.RegExp(unresolved) : unresolved;
    return CreateType({ [Kind]: "RegExp", type: "RegExp", source: expr.source, flags: expr.flags }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/rest/rest.mjs
  function RestResolve(T) {
    return IsIntersect(T) ? T.allOf : IsUnion(T) ? T.anyOf : IsTuple(T) ? T.items ?? [] : [];
  }
  function Rest(T) {
    return RestResolve(T);
  }

  // node_modules/@sinclair/typebox/build/esm/type/return-type/return-type.mjs
  function ReturnType(schema, options) {
    return IsFunction3(schema) ? CreateType(schema.returns, options) : Never(options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/transform/transform.mjs
  class TransformDecodeBuilder {
    constructor(schema) {
      this.schema = schema;
    }
    Decode(decode) {
      return new TransformEncodeBuilder(this.schema, decode);
    }
  }

  class TransformEncodeBuilder {
    constructor(schema, decode) {
      this.schema = schema;
      this.decode = decode;
    }
    EncodeTransform(encode, schema) {
      const Encode = (value) => schema[TransformKind].Encode(encode(value));
      const Decode = (value) => this.decode(schema[TransformKind].Decode(value));
      const Codec = { Encode, Decode };
      return { ...schema, [TransformKind]: Codec };
    }
    EncodeSchema(encode, schema) {
      const Codec = { Decode: this.decode, Encode: encode };
      return { ...schema, [TransformKind]: Codec };
    }
    Encode(encode) {
      return IsTransform(this.schema) ? this.EncodeTransform(encode, this.schema) : this.EncodeSchema(encode, this.schema);
    }
  }
  function Transform(schema) {
    return new TransformDecodeBuilder(schema);
  }

  // node_modules/@sinclair/typebox/build/esm/type/unsafe/unsafe.mjs
  function Unsafe(options = {}) {
    return CreateType({ [Kind]: options[Kind] ?? "Unsafe" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/void/void.mjs
  function Void(options) {
    return CreateType({ [Kind]: "Void", type: "void" }, options);
  }

  // node_modules/@sinclair/typebox/build/esm/type/type/type.mjs
  var exports_type3 = {};
  __export(exports_type3, {
    Void: () => Void,
    Uppercase: () => Uppercase,
    Unsafe: () => Unsafe,
    Unknown: () => Unknown,
    Union: () => Union,
    Undefined: () => Undefined,
    Uncapitalize: () => Uncapitalize,
    Uint8Array: () => Uint8Array2,
    Tuple: () => Tuple,
    Transform: () => Transform,
    TemplateLiteral: () => TemplateLiteral,
    Symbol: () => Symbol2,
    String: () => String2,
    ReturnType: () => ReturnType,
    Rest: () => Rest,
    Required: () => Required,
    RegExp: () => RegExp2,
    Ref: () => Ref,
    Recursive: () => Recursive,
    Record: () => Record,
    ReadonlyOptional: () => ReadonlyOptional,
    Readonly: () => Readonly,
    Promise: () => Promise2,
    Pick: () => Pick,
    Partial: () => Partial,
    Parameters: () => Parameters,
    Optional: () => Optional,
    Omit: () => Omit,
    Object: () => Object2,
    Number: () => Number2,
    Null: () => Null,
    Not: () => Not2,
    Never: () => Never,
    Module: () => Module,
    Mapped: () => Mapped,
    Lowercase: () => Lowercase,
    Literal: () => Literal,
    KeyOf: () => KeyOf,
    Iterator: () => Iterator,
    Intersect: () => Intersect,
    Integer: () => Integer,
    Instantiate: () => Instantiate,
    InstanceType: () => InstanceType,
    Index: () => Index,
    Function: () => Function,
    Extract: () => Extract,
    Extends: () => Extends,
    Exclude: () => Exclude,
    Enum: () => Enum,
    Date: () => Date2,
    ConstructorParameters: () => ConstructorParameters,
    Constructor: () => Constructor,
    Const: () => Const,
    Composite: () => Composite,
    Capitalize: () => Capitalize,
    Boolean: () => Boolean2,
    BigInt: () => BigInt2,
    Awaited: () => Awaited,
    AsyncIterator: () => AsyncIterator,
    Array: () => Array2,
    Argument: () => Argument,
    Any: () => Any
  });

  // node_modules/@sinclair/typebox/build/esm/type/type/index.mjs
  var Type = exports_type3;
  // node_modules/@sinclair/typebox/build/esm/errors/function.mjs
  function DefaultErrorFunction(error) {
    switch (error.errorType) {
      case ValueErrorType.ArrayContains:
        return "Expected array to contain at least one matching value";
      case ValueErrorType.ArrayMaxContains:
        return `Expected array to contain no more than ${error.schema.maxContains} matching values`;
      case ValueErrorType.ArrayMinContains:
        return `Expected array to contain at least ${error.schema.minContains} matching values`;
      case ValueErrorType.ArrayMaxItems:
        return `Expected array length to be less or equal to ${error.schema.maxItems}`;
      case ValueErrorType.ArrayMinItems:
        return `Expected array length to be greater or equal to ${error.schema.minItems}`;
      case ValueErrorType.ArrayUniqueItems:
        return "Expected array elements to be unique";
      case ValueErrorType.Array:
        return "Expected array";
      case ValueErrorType.AsyncIterator:
        return "Expected AsyncIterator";
      case ValueErrorType.BigIntExclusiveMaximum:
        return `Expected bigint to be less than ${error.schema.exclusiveMaximum}`;
      case ValueErrorType.BigIntExclusiveMinimum:
        return `Expected bigint to be greater than ${error.schema.exclusiveMinimum}`;
      case ValueErrorType.BigIntMaximum:
        return `Expected bigint to be less or equal to ${error.schema.maximum}`;
      case ValueErrorType.BigIntMinimum:
        return `Expected bigint to be greater or equal to ${error.schema.minimum}`;
      case ValueErrorType.BigIntMultipleOf:
        return `Expected bigint to be a multiple of ${error.schema.multipleOf}`;
      case ValueErrorType.BigInt:
        return "Expected bigint";
      case ValueErrorType.Boolean:
        return "Expected boolean";
      case ValueErrorType.DateExclusiveMinimumTimestamp:
        return `Expected Date timestamp to be greater than ${error.schema.exclusiveMinimumTimestamp}`;
      case ValueErrorType.DateExclusiveMaximumTimestamp:
        return `Expected Date timestamp to be less than ${error.schema.exclusiveMaximumTimestamp}`;
      case ValueErrorType.DateMinimumTimestamp:
        return `Expected Date timestamp to be greater or equal to ${error.schema.minimumTimestamp}`;
      case ValueErrorType.DateMaximumTimestamp:
        return `Expected Date timestamp to be less or equal to ${error.schema.maximumTimestamp}`;
      case ValueErrorType.DateMultipleOfTimestamp:
        return `Expected Date timestamp to be a multiple of ${error.schema.multipleOfTimestamp}`;
      case ValueErrorType.Date:
        return "Expected Date";
      case ValueErrorType.Function:
        return "Expected function";
      case ValueErrorType.IntegerExclusiveMaximum:
        return `Expected integer to be less than ${error.schema.exclusiveMaximum}`;
      case ValueErrorType.IntegerExclusiveMinimum:
        return `Expected integer to be greater than ${error.schema.exclusiveMinimum}`;
      case ValueErrorType.IntegerMaximum:
        return `Expected integer to be less or equal to ${error.schema.maximum}`;
      case ValueErrorType.IntegerMinimum:
        return `Expected integer to be greater or equal to ${error.schema.minimum}`;
      case ValueErrorType.IntegerMultipleOf:
        return `Expected integer to be a multiple of ${error.schema.multipleOf}`;
      case ValueErrorType.Integer:
        return "Expected integer";
      case ValueErrorType.IntersectUnevaluatedProperties:
        return "Unexpected property";
      case ValueErrorType.Intersect:
        return "Expected all values to match";
      case ValueErrorType.Iterator:
        return "Expected Iterator";
      case ValueErrorType.Literal:
        return `Expected ${typeof error.schema.const === "string" ? `'${error.schema.const}'` : error.schema.const}`;
      case ValueErrorType.Never:
        return "Never";
      case ValueErrorType.Not:
        return "Value should not match";
      case ValueErrorType.Null:
        return "Expected null";
      case ValueErrorType.NumberExclusiveMaximum:
        return `Expected number to be less than ${error.schema.exclusiveMaximum}`;
      case ValueErrorType.NumberExclusiveMinimum:
        return `Expected number to be greater than ${error.schema.exclusiveMinimum}`;
      case ValueErrorType.NumberMaximum:
        return `Expected number to be less or equal to ${error.schema.maximum}`;
      case ValueErrorType.NumberMinimum:
        return `Expected number to be greater or equal to ${error.schema.minimum}`;
      case ValueErrorType.NumberMultipleOf:
        return `Expected number to be a multiple of ${error.schema.multipleOf}`;
      case ValueErrorType.Number:
        return "Expected number";
      case ValueErrorType.Object:
        return "Expected object";
      case ValueErrorType.ObjectAdditionalProperties:
        return "Unexpected property";
      case ValueErrorType.ObjectMaxProperties:
        return `Expected object to have no more than ${error.schema.maxProperties} properties`;
      case ValueErrorType.ObjectMinProperties:
        return `Expected object to have at least ${error.schema.minProperties} properties`;
      case ValueErrorType.ObjectRequiredProperty:
        return "Expected required property";
      case ValueErrorType.Promise:
        return "Expected Promise";
      case ValueErrorType.RegExp:
        return "Expected string to match regular expression";
      case ValueErrorType.StringFormatUnknown:
        return `Unknown format '${error.schema.format}'`;
      case ValueErrorType.StringFormat:
        return `Expected string to match '${error.schema.format}' format`;
      case ValueErrorType.StringMaxLength:
        return `Expected string length less or equal to ${error.schema.maxLength}`;
      case ValueErrorType.StringMinLength:
        return `Expected string length greater or equal to ${error.schema.minLength}`;
      case ValueErrorType.StringPattern:
        return `Expected string to match '${error.schema.pattern}'`;
      case ValueErrorType.String:
        return "Expected string";
      case ValueErrorType.Symbol:
        return "Expected symbol";
      case ValueErrorType.TupleLength:
        return `Expected tuple to have ${error.schema.maxItems || 0} elements`;
      case ValueErrorType.Tuple:
        return "Expected tuple";
      case ValueErrorType.Uint8ArrayMaxByteLength:
        return `Expected byte length less or equal to ${error.schema.maxByteLength}`;
      case ValueErrorType.Uint8ArrayMinByteLength:
        return `Expected byte length greater or equal to ${error.schema.minByteLength}`;
      case ValueErrorType.Uint8Array:
        return "Expected Uint8Array";
      case ValueErrorType.Undefined:
        return "Expected undefined";
      case ValueErrorType.Union:
        return "Expected union value";
      case ValueErrorType.Void:
        return "Expected void";
      case ValueErrorType.Kind:
        return `Expected kind '${error.schema[Kind]}'`;
      default:
        return "Unknown error type";
    }
  }
  var errorFunction = DefaultErrorFunction;
  function GetErrorFunction() {
    return errorFunction;
  }

  // node_modules/@sinclair/typebox/build/esm/value/deref/deref.mjs
  class TypeDereferenceError extends TypeBoxError {
    constructor(schema) {
      super(`Unable to dereference schema with $id '${schema.$ref}'`);
      this.schema = schema;
    }
  }
  function Resolve(schema, references) {
    const target = references.find((target2) => target2.$id === schema.$ref);
    if (target === undefined)
      throw new TypeDereferenceError(schema);
    return Deref(target, references);
  }
  function Pushref(schema, references) {
    if (!IsString2(schema.$id) || references.some((target) => target.$id === schema.$id))
      return references;
    references.push(schema);
    return references;
  }
  function Deref(schema, references) {
    return schema[Kind] === "This" || schema[Kind] === "Ref" ? Resolve(schema, references) : schema;
  }

  // node_modules/@sinclair/typebox/build/esm/value/hash/hash.mjs
  class ValueHashError extends TypeBoxError {
    constructor(value) {
      super(`Unable to hash value`);
      this.value = value;
    }
  }
  var ByteMarker;
  (function(ByteMarker2) {
    ByteMarker2[ByteMarker2["Undefined"] = 0] = "Undefined";
    ByteMarker2[ByteMarker2["Null"] = 1] = "Null";
    ByteMarker2[ByteMarker2["Boolean"] = 2] = "Boolean";
    ByteMarker2[ByteMarker2["Number"] = 3] = "Number";
    ByteMarker2[ByteMarker2["String"] = 4] = "String";
    ByteMarker2[ByteMarker2["Object"] = 5] = "Object";
    ByteMarker2[ByteMarker2["Array"] = 6] = "Array";
    ByteMarker2[ByteMarker2["Date"] = 7] = "Date";
    ByteMarker2[ByteMarker2["Uint8Array"] = 8] = "Uint8Array";
    ByteMarker2[ByteMarker2["Symbol"] = 9] = "Symbol";
    ByteMarker2[ByteMarker2["BigInt"] = 10] = "BigInt";
  })(ByteMarker || (ByteMarker = {}));
  var Accumulator = BigInt("14695981039346656037");
  var [Prime, Size] = [BigInt("1099511628211"), BigInt("18446744073709551616")];
  var Bytes = Array.from({ length: 256 }).map((_, i) => BigInt(i));
  var F64 = new Float64Array(1);
  var F64In = new DataView(F64.buffer);
  var F64Out = new Uint8Array(F64.buffer);
  function* NumberToBytes(value) {
    const byteCount = value === 0 ? 1 : Math.ceil(Math.floor(Math.log2(value) + 1) / 8);
    for (let i = 0;i < byteCount; i++) {
      yield value >> 8 * (byteCount - 1 - i) & 255;
    }
  }
  function ArrayType2(value) {
    FNV1A64(ByteMarker.Array);
    for (const item of value) {
      Visit4(item);
    }
  }
  function BooleanType(value) {
    FNV1A64(ByteMarker.Boolean);
    FNV1A64(value ? 1 : 0);
  }
  function BigIntType(value) {
    FNV1A64(ByteMarker.BigInt);
    F64In.setBigInt64(0, value);
    for (const byte of F64Out) {
      FNV1A64(byte);
    }
  }
  function DateType2(value) {
    FNV1A64(ByteMarker.Date);
    Visit4(value.getTime());
  }
  function NullType(value) {
    FNV1A64(ByteMarker.Null);
  }
  function NumberType(value) {
    FNV1A64(ByteMarker.Number);
    F64In.setFloat64(0, value);
    for (const byte of F64Out) {
      FNV1A64(byte);
    }
  }
  function ObjectType2(value) {
    FNV1A64(ByteMarker.Object);
    for (const key of globalThis.Object.getOwnPropertyNames(value).sort()) {
      Visit4(key);
      Visit4(value[key]);
    }
  }
  function StringType(value) {
    FNV1A64(ByteMarker.String);
    for (let i = 0;i < value.length; i++) {
      for (const byte of NumberToBytes(value.charCodeAt(i))) {
        FNV1A64(byte);
      }
    }
  }
  function SymbolType(value) {
    FNV1A64(ByteMarker.Symbol);
    Visit4(value.description);
  }
  function Uint8ArrayType2(value) {
    FNV1A64(ByteMarker.Uint8Array);
    for (let i = 0;i < value.length; i++) {
      FNV1A64(value[i]);
    }
  }
  function UndefinedType(value) {
    return FNV1A64(ByteMarker.Undefined);
  }
  function Visit4(value) {
    if (IsArray2(value))
      return ArrayType2(value);
    if (IsBoolean2(value))
      return BooleanType(value);
    if (IsBigInt2(value))
      return BigIntType(value);
    if (IsDate2(value))
      return DateType2(value);
    if (IsNull2(value))
      return NullType(value);
    if (IsNumber2(value))
      return NumberType(value);
    if (IsObject2(value))
      return ObjectType2(value);
    if (IsString2(value))
      return StringType(value);
    if (IsSymbol2(value))
      return SymbolType(value);
    if (IsUint8Array2(value))
      return Uint8ArrayType2(value);
    if (IsUndefined2(value))
      return UndefinedType(value);
    throw new ValueHashError(value);
  }
  function FNV1A64(byte) {
    Accumulator = Accumulator ^ Bytes[byte];
    Accumulator = Accumulator * Prime % Size;
  }
  function Hash(value) {
    Accumulator = BigInt("14695981039346656037");
    Visit4(value);
    return Accumulator;
  }

  // node_modules/@sinclair/typebox/build/esm/value/check/check.mjs
  class ValueCheckUnknownTypeError extends TypeBoxError {
    constructor(schema) {
      super(`Unknown type`);
      this.schema = schema;
    }
  }
  function IsAnyOrUnknown(schema) {
    return schema[Kind] === "Any" || schema[Kind] === "Unknown";
  }
  function IsDefined(value) {
    return value !== undefined;
  }
  function FromAny2(schema, references, value) {
    return true;
  }
  function FromArgument2(schema, references, value) {
    return true;
  }
  function FromArray7(schema, references, value) {
    if (!IsArray2(value))
      return false;
    if (IsDefined(schema.minItems) && !(value.length >= schema.minItems)) {
      return false;
    }
    if (IsDefined(schema.maxItems) && !(value.length <= schema.maxItems)) {
      return false;
    }
    for (const element of value) {
      if (!Visit5(schema.items, references, element))
        return false;
    }
    if (schema.uniqueItems === true && !function() {
      const set = new Set;
      for (const element of value) {
        const hashed = Hash(element);
        if (set.has(hashed)) {
          return false;
        } else {
          set.add(hashed);
        }
      }
      return true;
    }()) {
      return false;
    }
    if (!(IsDefined(schema.contains) || IsNumber2(schema.minContains) || IsNumber2(schema.maxContains))) {
      return true;
    }
    const containsSchema = IsDefined(schema.contains) ? schema.contains : Never();
    const containsCount = value.reduce((acc, value2) => Visit5(containsSchema, references, value2) ? acc + 1 : acc, 0);
    if (containsCount === 0) {
      return false;
    }
    if (IsNumber2(schema.minContains) && containsCount < schema.minContains) {
      return false;
    }
    if (IsNumber2(schema.maxContains) && containsCount > schema.maxContains) {
      return false;
    }
    return true;
  }
  function FromAsyncIterator4(schema, references, value) {
    return IsAsyncIterator2(value);
  }
  function FromBigInt2(schema, references, value) {
    if (!IsBigInt2(value))
      return false;
    if (IsDefined(schema.exclusiveMaximum) && !(value < schema.exclusiveMaximum)) {
      return false;
    }
    if (IsDefined(schema.exclusiveMinimum) && !(value > schema.exclusiveMinimum)) {
      return false;
    }
    if (IsDefined(schema.maximum) && !(value <= schema.maximum)) {
      return false;
    }
    if (IsDefined(schema.minimum) && !(value >= schema.minimum)) {
      return false;
    }
    if (IsDefined(schema.multipleOf) && !(value % schema.multipleOf === BigInt(0))) {
      return false;
    }
    return true;
  }
  function FromBoolean2(schema, references, value) {
    return IsBoolean2(value);
  }
  function FromConstructor4(schema, references, value) {
    return Visit5(schema.returns, references, value.prototype);
  }
  function FromDate2(schema, references, value) {
    if (!IsDate2(value))
      return false;
    if (IsDefined(schema.exclusiveMaximumTimestamp) && !(value.getTime() < schema.exclusiveMaximumTimestamp)) {
      return false;
    }
    if (IsDefined(schema.exclusiveMinimumTimestamp) && !(value.getTime() > schema.exclusiveMinimumTimestamp)) {
      return false;
    }
    if (IsDefined(schema.maximumTimestamp) && !(value.getTime() <= schema.maximumTimestamp)) {
      return false;
    }
    if (IsDefined(schema.minimumTimestamp) && !(value.getTime() >= schema.minimumTimestamp)) {
      return false;
    }
    if (IsDefined(schema.multipleOfTimestamp) && !(value.getTime() % schema.multipleOfTimestamp === 0)) {
      return false;
    }
    return true;
  }
  function FromFunction4(schema, references, value) {
    return IsFunction2(value);
  }
  function FromImport(schema, references, value) {
    const definitions = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    return Visit5(target, [...references, ...definitions], value);
  }
  function FromInteger2(schema, references, value) {
    if (!IsInteger(value)) {
      return false;
    }
    if (IsDefined(schema.exclusiveMaximum) && !(value < schema.exclusiveMaximum)) {
      return false;
    }
    if (IsDefined(schema.exclusiveMinimum) && !(value > schema.exclusiveMinimum)) {
      return false;
    }
    if (IsDefined(schema.maximum) && !(value <= schema.maximum)) {
      return false;
    }
    if (IsDefined(schema.minimum) && !(value >= schema.minimum)) {
      return false;
    }
    if (IsDefined(schema.multipleOf) && !(value % schema.multipleOf === 0)) {
      return false;
    }
    return true;
  }
  function FromIntersect9(schema, references, value) {
    const check1 = schema.allOf.every((schema2) => Visit5(schema2, references, value));
    if (schema.unevaluatedProperties === false) {
      const keyPattern = new RegExp(KeyOfPattern(schema));
      const check2 = Object.getOwnPropertyNames(value).every((key) => keyPattern.test(key));
      return check1 && check2;
    } else if (IsSchema(schema.unevaluatedProperties)) {
      const keyCheck = new RegExp(KeyOfPattern(schema));
      const check2 = Object.getOwnPropertyNames(value).every((key) => keyCheck.test(key) || Visit5(schema.unevaluatedProperties, references, value[key]));
      return check1 && check2;
    } else {
      return check1;
    }
  }
  function FromIterator4(schema, references, value) {
    return IsIterator2(value);
  }
  function FromLiteral3(schema, references, value) {
    return value === schema.const;
  }
  function FromNever2(schema, references, value) {
    return false;
  }
  function FromNot2(schema, references, value) {
    return !Visit5(schema.not, references, value);
  }
  function FromNull2(schema, references, value) {
    return IsNull2(value);
  }
  function FromNumber2(schema, references, value) {
    if (!TypeSystemPolicy.IsNumberLike(value))
      return false;
    if (IsDefined(schema.exclusiveMaximum) && !(value < schema.exclusiveMaximum)) {
      return false;
    }
    if (IsDefined(schema.exclusiveMinimum) && !(value > schema.exclusiveMinimum)) {
      return false;
    }
    if (IsDefined(schema.minimum) && !(value >= schema.minimum)) {
      return false;
    }
    if (IsDefined(schema.maximum) && !(value <= schema.maximum)) {
      return false;
    }
    if (IsDefined(schema.multipleOf) && !(value % schema.multipleOf === 0)) {
      return false;
    }
    return true;
  }
  function FromObject8(schema, references, value) {
    if (!TypeSystemPolicy.IsObjectLike(value))
      return false;
    if (IsDefined(schema.minProperties) && !(Object.getOwnPropertyNames(value).length >= schema.minProperties)) {
      return false;
    }
    if (IsDefined(schema.maxProperties) && !(Object.getOwnPropertyNames(value).length <= schema.maxProperties)) {
      return false;
    }
    const knownKeys = Object.getOwnPropertyNames(schema.properties);
    for (const knownKey of knownKeys) {
      const property = schema.properties[knownKey];
      if (schema.required && schema.required.includes(knownKey)) {
        if (!Visit5(property, references, value[knownKey])) {
          return false;
        }
        if ((ExtendsUndefinedCheck(property) || IsAnyOrUnknown(property)) && !(knownKey in value)) {
          return false;
        }
      } else {
        if (TypeSystemPolicy.IsExactOptionalProperty(value, knownKey) && !Visit5(property, references, value[knownKey])) {
          return false;
        }
      }
    }
    if (schema.additionalProperties === false) {
      const valueKeys = Object.getOwnPropertyNames(value);
      if (schema.required && schema.required.length === knownKeys.length && valueKeys.length === knownKeys.length) {
        return true;
      } else {
        return valueKeys.every((valueKey) => knownKeys.includes(valueKey));
      }
    } else if (typeof schema.additionalProperties === "object") {
      const valueKeys = Object.getOwnPropertyNames(value);
      return valueKeys.every((key) => knownKeys.includes(key) || Visit5(schema.additionalProperties, references, value[key]));
    } else {
      return true;
    }
  }
  function FromPromise4(schema, references, value) {
    return IsPromise(value);
  }
  function FromRecord4(schema, references, value) {
    if (!TypeSystemPolicy.IsRecordLike(value)) {
      return false;
    }
    if (IsDefined(schema.minProperties) && !(Object.getOwnPropertyNames(value).length >= schema.minProperties)) {
      return false;
    }
    if (IsDefined(schema.maxProperties) && !(Object.getOwnPropertyNames(value).length <= schema.maxProperties)) {
      return false;
    }
    const [patternKey, patternSchema] = Object.entries(schema.patternProperties)[0];
    const regex = new RegExp(patternKey);
    const check1 = Object.entries(value).every(([key, value2]) => {
      return regex.test(key) ? Visit5(patternSchema, references, value2) : true;
    });
    const check2 = typeof schema.additionalProperties === "object" ? Object.entries(value).every(([key, value2]) => {
      return !regex.test(key) ? Visit5(schema.additionalProperties, references, value2) : true;
    }) : true;
    const check3 = schema.additionalProperties === false ? Object.getOwnPropertyNames(value).every((key) => {
      return regex.test(key);
    }) : true;
    return check1 && check2 && check3;
  }
  function FromRef5(schema, references, value) {
    return Visit5(Deref(schema, references), references, value);
  }
  function FromRegExp2(schema, references, value) {
    const regex = new RegExp(schema.source, schema.flags);
    if (IsDefined(schema.minLength)) {
      if (!(value.length >= schema.minLength))
        return false;
    }
    if (IsDefined(schema.maxLength)) {
      if (!(value.length <= schema.maxLength))
        return false;
    }
    return regex.test(value);
  }
  function FromString2(schema, references, value) {
    if (!IsString2(value)) {
      return false;
    }
    if (IsDefined(schema.minLength)) {
      if (!(value.length >= schema.minLength))
        return false;
    }
    if (IsDefined(schema.maxLength)) {
      if (!(value.length <= schema.maxLength))
        return false;
    }
    if (IsDefined(schema.pattern)) {
      const regex = new RegExp(schema.pattern);
      if (!regex.test(value))
        return false;
    }
    if (IsDefined(schema.format)) {
      if (!exports_format.Has(schema.format))
        return false;
      const func = exports_format.Get(schema.format);
      return func(value);
    }
    return true;
  }
  function FromSymbol2(schema, references, value) {
    return IsSymbol2(value);
  }
  function FromTemplateLiteral4(schema, references, value) {
    return IsString2(value) && new RegExp(schema.pattern).test(value);
  }
  function FromThis(schema, references, value) {
    return Visit5(Deref(schema, references), references, value);
  }
  function FromTuple6(schema, references, value) {
    if (!IsArray2(value)) {
      return false;
    }
    if (schema.items === undefined && !(value.length === 0)) {
      return false;
    }
    if (!(value.length === schema.maxItems)) {
      return false;
    }
    if (!schema.items) {
      return true;
    }
    for (let i = 0;i < schema.items.length; i++) {
      if (!Visit5(schema.items[i], references, value[i]))
        return false;
    }
    return true;
  }
  function FromUndefined2(schema, references, value) {
    return IsUndefined2(value);
  }
  function FromUnion11(schema, references, value) {
    return schema.anyOf.some((inner) => Visit5(inner, references, value));
  }
  function FromUint8Array2(schema, references, value) {
    if (!IsUint8Array2(value)) {
      return false;
    }
    if (IsDefined(schema.maxByteLength) && !(value.length <= schema.maxByteLength)) {
      return false;
    }
    if (IsDefined(schema.minByteLength) && !(value.length >= schema.minByteLength)) {
      return false;
    }
    return true;
  }
  function FromUnknown2(schema, references, value) {
    return true;
  }
  function FromVoid2(schema, references, value) {
    return TypeSystemPolicy.IsVoidLike(value);
  }
  function FromKind(schema, references, value) {
    if (!exports_type2.Has(schema[Kind]))
      return false;
    const func = exports_type2.Get(schema[Kind]);
    return func(schema, value);
  }
  function Visit5(schema, references, value) {
    const references_ = IsDefined(schema.$id) ? Pushref(schema, references) : references;
    const schema_ = schema;
    switch (schema_[Kind]) {
      case "Any":
        return FromAny2(schema_, references_, value);
      case "Argument":
        return FromArgument2(schema_, references_, value);
      case "Array":
        return FromArray7(schema_, references_, value);
      case "AsyncIterator":
        return FromAsyncIterator4(schema_, references_, value);
      case "BigInt":
        return FromBigInt2(schema_, references_, value);
      case "Boolean":
        return FromBoolean2(schema_, references_, value);
      case "Constructor":
        return FromConstructor4(schema_, references_, value);
      case "Date":
        return FromDate2(schema_, references_, value);
      case "Function":
        return FromFunction4(schema_, references_, value);
      case "Import":
        return FromImport(schema_, references_, value);
      case "Integer":
        return FromInteger2(schema_, references_, value);
      case "Intersect":
        return FromIntersect9(schema_, references_, value);
      case "Iterator":
        return FromIterator4(schema_, references_, value);
      case "Literal":
        return FromLiteral3(schema_, references_, value);
      case "Never":
        return FromNever2(schema_, references_, value);
      case "Not":
        return FromNot2(schema_, references_, value);
      case "Null":
        return FromNull2(schema_, references_, value);
      case "Number":
        return FromNumber2(schema_, references_, value);
      case "Object":
        return FromObject8(schema_, references_, value);
      case "Promise":
        return FromPromise4(schema_, references_, value);
      case "Record":
        return FromRecord4(schema_, references_, value);
      case "Ref":
        return FromRef5(schema_, references_, value);
      case "RegExp":
        return FromRegExp2(schema_, references_, value);
      case "String":
        return FromString2(schema_, references_, value);
      case "Symbol":
        return FromSymbol2(schema_, references_, value);
      case "TemplateLiteral":
        return FromTemplateLiteral4(schema_, references_, value);
      case "This":
        return FromThis(schema_, references_, value);
      case "Tuple":
        return FromTuple6(schema_, references_, value);
      case "Undefined":
        return FromUndefined2(schema_, references_, value);
      case "Union":
        return FromUnion11(schema_, references_, value);
      case "Uint8Array":
        return FromUint8Array2(schema_, references_, value);
      case "Unknown":
        return FromUnknown2(schema_, references_, value);
      case "Void":
        return FromVoid2(schema_, references_, value);
      default:
        if (!exports_type2.Has(schema_[Kind]))
          throw new ValueCheckUnknownTypeError(schema_);
        return FromKind(schema_, references_, value);
    }
  }
  function Check(...args) {
    return args.length === 3 ? Visit5(args[0], args[1], args[2]) : Visit5(args[0], [], args[1]);
  }

  // node_modules/@sinclair/typebox/build/esm/errors/errors.mjs
  var ValueErrorType;
  (function(ValueErrorType2) {
    ValueErrorType2[ValueErrorType2["ArrayContains"] = 0] = "ArrayContains";
    ValueErrorType2[ValueErrorType2["ArrayMaxContains"] = 1] = "ArrayMaxContains";
    ValueErrorType2[ValueErrorType2["ArrayMaxItems"] = 2] = "ArrayMaxItems";
    ValueErrorType2[ValueErrorType2["ArrayMinContains"] = 3] = "ArrayMinContains";
    ValueErrorType2[ValueErrorType2["ArrayMinItems"] = 4] = "ArrayMinItems";
    ValueErrorType2[ValueErrorType2["ArrayUniqueItems"] = 5] = "ArrayUniqueItems";
    ValueErrorType2[ValueErrorType2["Array"] = 6] = "Array";
    ValueErrorType2[ValueErrorType2["AsyncIterator"] = 7] = "AsyncIterator";
    ValueErrorType2[ValueErrorType2["BigIntExclusiveMaximum"] = 8] = "BigIntExclusiveMaximum";
    ValueErrorType2[ValueErrorType2["BigIntExclusiveMinimum"] = 9] = "BigIntExclusiveMinimum";
    ValueErrorType2[ValueErrorType2["BigIntMaximum"] = 10] = "BigIntMaximum";
    ValueErrorType2[ValueErrorType2["BigIntMinimum"] = 11] = "BigIntMinimum";
    ValueErrorType2[ValueErrorType2["BigIntMultipleOf"] = 12] = "BigIntMultipleOf";
    ValueErrorType2[ValueErrorType2["BigInt"] = 13] = "BigInt";
    ValueErrorType2[ValueErrorType2["Boolean"] = 14] = "Boolean";
    ValueErrorType2[ValueErrorType2["DateExclusiveMaximumTimestamp"] = 15] = "DateExclusiveMaximumTimestamp";
    ValueErrorType2[ValueErrorType2["DateExclusiveMinimumTimestamp"] = 16] = "DateExclusiveMinimumTimestamp";
    ValueErrorType2[ValueErrorType2["DateMaximumTimestamp"] = 17] = "DateMaximumTimestamp";
    ValueErrorType2[ValueErrorType2["DateMinimumTimestamp"] = 18] = "DateMinimumTimestamp";
    ValueErrorType2[ValueErrorType2["DateMultipleOfTimestamp"] = 19] = "DateMultipleOfTimestamp";
    ValueErrorType2[ValueErrorType2["Date"] = 20] = "Date";
    ValueErrorType2[ValueErrorType2["Function"] = 21] = "Function";
    ValueErrorType2[ValueErrorType2["IntegerExclusiveMaximum"] = 22] = "IntegerExclusiveMaximum";
    ValueErrorType2[ValueErrorType2["IntegerExclusiveMinimum"] = 23] = "IntegerExclusiveMinimum";
    ValueErrorType2[ValueErrorType2["IntegerMaximum"] = 24] = "IntegerMaximum";
    ValueErrorType2[ValueErrorType2["IntegerMinimum"] = 25] = "IntegerMinimum";
    ValueErrorType2[ValueErrorType2["IntegerMultipleOf"] = 26] = "IntegerMultipleOf";
    ValueErrorType2[ValueErrorType2["Integer"] = 27] = "Integer";
    ValueErrorType2[ValueErrorType2["IntersectUnevaluatedProperties"] = 28] = "IntersectUnevaluatedProperties";
    ValueErrorType2[ValueErrorType2["Intersect"] = 29] = "Intersect";
    ValueErrorType2[ValueErrorType2["Iterator"] = 30] = "Iterator";
    ValueErrorType2[ValueErrorType2["Kind"] = 31] = "Kind";
    ValueErrorType2[ValueErrorType2["Literal"] = 32] = "Literal";
    ValueErrorType2[ValueErrorType2["Never"] = 33] = "Never";
    ValueErrorType2[ValueErrorType2["Not"] = 34] = "Not";
    ValueErrorType2[ValueErrorType2["Null"] = 35] = "Null";
    ValueErrorType2[ValueErrorType2["NumberExclusiveMaximum"] = 36] = "NumberExclusiveMaximum";
    ValueErrorType2[ValueErrorType2["NumberExclusiveMinimum"] = 37] = "NumberExclusiveMinimum";
    ValueErrorType2[ValueErrorType2["NumberMaximum"] = 38] = "NumberMaximum";
    ValueErrorType2[ValueErrorType2["NumberMinimum"] = 39] = "NumberMinimum";
    ValueErrorType2[ValueErrorType2["NumberMultipleOf"] = 40] = "NumberMultipleOf";
    ValueErrorType2[ValueErrorType2["Number"] = 41] = "Number";
    ValueErrorType2[ValueErrorType2["ObjectAdditionalProperties"] = 42] = "ObjectAdditionalProperties";
    ValueErrorType2[ValueErrorType2["ObjectMaxProperties"] = 43] = "ObjectMaxProperties";
    ValueErrorType2[ValueErrorType2["ObjectMinProperties"] = 44] = "ObjectMinProperties";
    ValueErrorType2[ValueErrorType2["ObjectRequiredProperty"] = 45] = "ObjectRequiredProperty";
    ValueErrorType2[ValueErrorType2["Object"] = 46] = "Object";
    ValueErrorType2[ValueErrorType2["Promise"] = 47] = "Promise";
    ValueErrorType2[ValueErrorType2["RegExp"] = 48] = "RegExp";
    ValueErrorType2[ValueErrorType2["StringFormatUnknown"] = 49] = "StringFormatUnknown";
    ValueErrorType2[ValueErrorType2["StringFormat"] = 50] = "StringFormat";
    ValueErrorType2[ValueErrorType2["StringMaxLength"] = 51] = "StringMaxLength";
    ValueErrorType2[ValueErrorType2["StringMinLength"] = 52] = "StringMinLength";
    ValueErrorType2[ValueErrorType2["StringPattern"] = 53] = "StringPattern";
    ValueErrorType2[ValueErrorType2["String"] = 54] = "String";
    ValueErrorType2[ValueErrorType2["Symbol"] = 55] = "Symbol";
    ValueErrorType2[ValueErrorType2["TupleLength"] = 56] = "TupleLength";
    ValueErrorType2[ValueErrorType2["Tuple"] = 57] = "Tuple";
    ValueErrorType2[ValueErrorType2["Uint8ArrayMaxByteLength"] = 58] = "Uint8ArrayMaxByteLength";
    ValueErrorType2[ValueErrorType2["Uint8ArrayMinByteLength"] = 59] = "Uint8ArrayMinByteLength";
    ValueErrorType2[ValueErrorType2["Uint8Array"] = 60] = "Uint8Array";
    ValueErrorType2[ValueErrorType2["Undefined"] = 61] = "Undefined";
    ValueErrorType2[ValueErrorType2["Union"] = 62] = "Union";
    ValueErrorType2[ValueErrorType2["Void"] = 63] = "Void";
  })(ValueErrorType || (ValueErrorType = {}));

  class ValueErrorsUnknownTypeError extends TypeBoxError {
    constructor(schema) {
      super("Unknown type");
      this.schema = schema;
    }
  }
  function EscapeKey(key) {
    return key.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  function IsDefined2(value) {
    return value !== undefined;
  }

  class ValueErrorIterator {
    constructor(iterator) {
      this.iterator = iterator;
    }
    [Symbol.iterator]() {
      return this.iterator;
    }
    First() {
      const next = this.iterator.next();
      return next.done ? undefined : next.value;
    }
  }
  function Create(errorType, schema, path, value, errors = []) {
    return {
      type: errorType,
      schema,
      path,
      value,
      message: GetErrorFunction()({ errorType, path, schema, value, errors }),
      errors
    };
  }
  function* FromAny3(schema, references, path, value) {}
  function* FromArgument3(schema, references, path, value) {}
  function* FromArray8(schema, references, path, value) {
    if (!IsArray2(value)) {
      return yield Create(ValueErrorType.Array, schema, path, value);
    }
    if (IsDefined2(schema.minItems) && !(value.length >= schema.minItems)) {
      yield Create(ValueErrorType.ArrayMinItems, schema, path, value);
    }
    if (IsDefined2(schema.maxItems) && !(value.length <= schema.maxItems)) {
      yield Create(ValueErrorType.ArrayMaxItems, schema, path, value);
    }
    for (let i = 0;i < value.length; i++) {
      yield* Visit6(schema.items, references, `${path}/${i}`, value[i]);
    }
    if (schema.uniqueItems === true && !function() {
      const set = new Set;
      for (const element of value) {
        const hashed = Hash(element);
        if (set.has(hashed)) {
          return false;
        } else {
          set.add(hashed);
        }
      }
      return true;
    }()) {
      yield Create(ValueErrorType.ArrayUniqueItems, schema, path, value);
    }
    if (!(IsDefined2(schema.contains) || IsDefined2(schema.minContains) || IsDefined2(schema.maxContains))) {
      return;
    }
    const containsSchema = IsDefined2(schema.contains) ? schema.contains : Never();
    const containsCount = value.reduce((acc, value2, index) => Visit6(containsSchema, references, `${path}${index}`, value2).next().done === true ? acc + 1 : acc, 0);
    if (containsCount === 0) {
      yield Create(ValueErrorType.ArrayContains, schema, path, value);
    }
    if (IsNumber2(schema.minContains) && containsCount < schema.minContains) {
      yield Create(ValueErrorType.ArrayMinContains, schema, path, value);
    }
    if (IsNumber2(schema.maxContains) && containsCount > schema.maxContains) {
      yield Create(ValueErrorType.ArrayMaxContains, schema, path, value);
    }
  }
  function* FromAsyncIterator5(schema, references, path, value) {
    if (!IsAsyncIterator2(value))
      yield Create(ValueErrorType.AsyncIterator, schema, path, value);
  }
  function* FromBigInt3(schema, references, path, value) {
    if (!IsBigInt2(value))
      return yield Create(ValueErrorType.BigInt, schema, path, value);
    if (IsDefined2(schema.exclusiveMaximum) && !(value < schema.exclusiveMaximum)) {
      yield Create(ValueErrorType.BigIntExclusiveMaximum, schema, path, value);
    }
    if (IsDefined2(schema.exclusiveMinimum) && !(value > schema.exclusiveMinimum)) {
      yield Create(ValueErrorType.BigIntExclusiveMinimum, schema, path, value);
    }
    if (IsDefined2(schema.maximum) && !(value <= schema.maximum)) {
      yield Create(ValueErrorType.BigIntMaximum, schema, path, value);
    }
    if (IsDefined2(schema.minimum) && !(value >= schema.minimum)) {
      yield Create(ValueErrorType.BigIntMinimum, schema, path, value);
    }
    if (IsDefined2(schema.multipleOf) && !(value % schema.multipleOf === BigInt(0))) {
      yield Create(ValueErrorType.BigIntMultipleOf, schema, path, value);
    }
  }
  function* FromBoolean3(schema, references, path, value) {
    if (!IsBoolean2(value))
      yield Create(ValueErrorType.Boolean, schema, path, value);
  }
  function* FromConstructor5(schema, references, path, value) {
    yield* Visit6(schema.returns, references, path, value.prototype);
  }
  function* FromDate3(schema, references, path, value) {
    if (!IsDate2(value))
      return yield Create(ValueErrorType.Date, schema, path, value);
    if (IsDefined2(schema.exclusiveMaximumTimestamp) && !(value.getTime() < schema.exclusiveMaximumTimestamp)) {
      yield Create(ValueErrorType.DateExclusiveMaximumTimestamp, schema, path, value);
    }
    if (IsDefined2(schema.exclusiveMinimumTimestamp) && !(value.getTime() > schema.exclusiveMinimumTimestamp)) {
      yield Create(ValueErrorType.DateExclusiveMinimumTimestamp, schema, path, value);
    }
    if (IsDefined2(schema.maximumTimestamp) && !(value.getTime() <= schema.maximumTimestamp)) {
      yield Create(ValueErrorType.DateMaximumTimestamp, schema, path, value);
    }
    if (IsDefined2(schema.minimumTimestamp) && !(value.getTime() >= schema.minimumTimestamp)) {
      yield Create(ValueErrorType.DateMinimumTimestamp, schema, path, value);
    }
    if (IsDefined2(schema.multipleOfTimestamp) && !(value.getTime() % schema.multipleOfTimestamp === 0)) {
      yield Create(ValueErrorType.DateMultipleOfTimestamp, schema, path, value);
    }
  }
  function* FromFunction5(schema, references, path, value) {
    if (!IsFunction2(value))
      yield Create(ValueErrorType.Function, schema, path, value);
  }
  function* FromImport2(schema, references, path, value) {
    const definitions = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    yield* Visit6(target, [...references, ...definitions], path, value);
  }
  function* FromInteger3(schema, references, path, value) {
    if (!IsInteger(value))
      return yield Create(ValueErrorType.Integer, schema, path, value);
    if (IsDefined2(schema.exclusiveMaximum) && !(value < schema.exclusiveMaximum)) {
      yield Create(ValueErrorType.IntegerExclusiveMaximum, schema, path, value);
    }
    if (IsDefined2(schema.exclusiveMinimum) && !(value > schema.exclusiveMinimum)) {
      yield Create(ValueErrorType.IntegerExclusiveMinimum, schema, path, value);
    }
    if (IsDefined2(schema.maximum) && !(value <= schema.maximum)) {
      yield Create(ValueErrorType.IntegerMaximum, schema, path, value);
    }
    if (IsDefined2(schema.minimum) && !(value >= schema.minimum)) {
      yield Create(ValueErrorType.IntegerMinimum, schema, path, value);
    }
    if (IsDefined2(schema.multipleOf) && !(value % schema.multipleOf === 0)) {
      yield Create(ValueErrorType.IntegerMultipleOf, schema, path, value);
    }
  }
  function* FromIntersect10(schema, references, path, value) {
    let hasError = false;
    for (const inner of schema.allOf) {
      for (const error of Visit6(inner, references, path, value)) {
        hasError = true;
        yield error;
      }
    }
    if (hasError) {
      return yield Create(ValueErrorType.Intersect, schema, path, value);
    }
    if (schema.unevaluatedProperties === false) {
      const keyCheck = new RegExp(KeyOfPattern(schema));
      for (const valueKey of Object.getOwnPropertyNames(value)) {
        if (!keyCheck.test(valueKey)) {
          yield Create(ValueErrorType.IntersectUnevaluatedProperties, schema, `${path}/${valueKey}`, value);
        }
      }
    }
    if (typeof schema.unevaluatedProperties === "object") {
      const keyCheck = new RegExp(KeyOfPattern(schema));
      for (const valueKey of Object.getOwnPropertyNames(value)) {
        if (!keyCheck.test(valueKey)) {
          const next = Visit6(schema.unevaluatedProperties, references, `${path}/${valueKey}`, value[valueKey]).next();
          if (!next.done)
            yield next.value;
        }
      }
    }
  }
  function* FromIterator5(schema, references, path, value) {
    if (!IsIterator2(value))
      yield Create(ValueErrorType.Iterator, schema, path, value);
  }
  function* FromLiteral4(schema, references, path, value) {
    if (!(value === schema.const))
      yield Create(ValueErrorType.Literal, schema, path, value);
  }
  function* FromNever3(schema, references, path, value) {
    yield Create(ValueErrorType.Never, schema, path, value);
  }
  function* FromNot3(schema, references, path, value) {
    if (Visit6(schema.not, references, path, value).next().done === true)
      yield Create(ValueErrorType.Not, schema, path, value);
  }
  function* FromNull3(schema, references, path, value) {
    if (!IsNull2(value))
      yield Create(ValueErrorType.Null, schema, path, value);
  }
  function* FromNumber3(schema, references, path, value) {
    if (!TypeSystemPolicy.IsNumberLike(value))
      return yield Create(ValueErrorType.Number, schema, path, value);
    if (IsDefined2(schema.exclusiveMaximum) && !(value < schema.exclusiveMaximum)) {
      yield Create(ValueErrorType.NumberExclusiveMaximum, schema, path, value);
    }
    if (IsDefined2(schema.exclusiveMinimum) && !(value > schema.exclusiveMinimum)) {
      yield Create(ValueErrorType.NumberExclusiveMinimum, schema, path, value);
    }
    if (IsDefined2(schema.maximum) && !(value <= schema.maximum)) {
      yield Create(ValueErrorType.NumberMaximum, schema, path, value);
    }
    if (IsDefined2(schema.minimum) && !(value >= schema.minimum)) {
      yield Create(ValueErrorType.NumberMinimum, schema, path, value);
    }
    if (IsDefined2(schema.multipleOf) && !(value % schema.multipleOf === 0)) {
      yield Create(ValueErrorType.NumberMultipleOf, schema, path, value);
    }
  }
  function* FromObject9(schema, references, path, value) {
    if (!TypeSystemPolicy.IsObjectLike(value))
      return yield Create(ValueErrorType.Object, schema, path, value);
    if (IsDefined2(schema.minProperties) && !(Object.getOwnPropertyNames(value).length >= schema.minProperties)) {
      yield Create(ValueErrorType.ObjectMinProperties, schema, path, value);
    }
    if (IsDefined2(schema.maxProperties) && !(Object.getOwnPropertyNames(value).length <= schema.maxProperties)) {
      yield Create(ValueErrorType.ObjectMaxProperties, schema, path, value);
    }
    const requiredKeys = Array.isArray(schema.required) ? schema.required : [];
    const knownKeys = Object.getOwnPropertyNames(schema.properties);
    const unknownKeys = Object.getOwnPropertyNames(value);
    for (const requiredKey of requiredKeys) {
      if (unknownKeys.includes(requiredKey))
        continue;
      yield Create(ValueErrorType.ObjectRequiredProperty, schema.properties[requiredKey], `${path}/${EscapeKey(requiredKey)}`, undefined);
    }
    if (schema.additionalProperties === false) {
      for (const valueKey of unknownKeys) {
        if (!knownKeys.includes(valueKey)) {
          yield Create(ValueErrorType.ObjectAdditionalProperties, schema, `${path}/${EscapeKey(valueKey)}`, value[valueKey]);
        }
      }
    }
    if (typeof schema.additionalProperties === "object") {
      for (const valueKey of unknownKeys) {
        if (knownKeys.includes(valueKey))
          continue;
        yield* Visit6(schema.additionalProperties, references, `${path}/${EscapeKey(valueKey)}`, value[valueKey]);
      }
    }
    for (const knownKey of knownKeys) {
      const property = schema.properties[knownKey];
      if (schema.required && schema.required.includes(knownKey)) {
        yield* Visit6(property, references, `${path}/${EscapeKey(knownKey)}`, value[knownKey]);
        if (ExtendsUndefinedCheck(schema) && !(knownKey in value)) {
          yield Create(ValueErrorType.ObjectRequiredProperty, property, `${path}/${EscapeKey(knownKey)}`, undefined);
        }
      } else {
        if (TypeSystemPolicy.IsExactOptionalProperty(value, knownKey)) {
          yield* Visit6(property, references, `${path}/${EscapeKey(knownKey)}`, value[knownKey]);
        }
      }
    }
  }
  function* FromPromise5(schema, references, path, value) {
    if (!IsPromise(value))
      yield Create(ValueErrorType.Promise, schema, path, value);
  }
  function* FromRecord5(schema, references, path, value) {
    if (!TypeSystemPolicy.IsRecordLike(value))
      return yield Create(ValueErrorType.Object, schema, path, value);
    if (IsDefined2(schema.minProperties) && !(Object.getOwnPropertyNames(value).length >= schema.minProperties)) {
      yield Create(ValueErrorType.ObjectMinProperties, schema, path, value);
    }
    if (IsDefined2(schema.maxProperties) && !(Object.getOwnPropertyNames(value).length <= schema.maxProperties)) {
      yield Create(ValueErrorType.ObjectMaxProperties, schema, path, value);
    }
    const [patternKey, patternSchema] = Object.entries(schema.patternProperties)[0];
    const regex = new RegExp(patternKey);
    for (const [propertyKey, propertyValue] of Object.entries(value)) {
      if (regex.test(propertyKey))
        yield* Visit6(patternSchema, references, `${path}/${EscapeKey(propertyKey)}`, propertyValue);
    }
    if (typeof schema.additionalProperties === "object") {
      for (const [propertyKey, propertyValue] of Object.entries(value)) {
        if (!regex.test(propertyKey))
          yield* Visit6(schema.additionalProperties, references, `${path}/${EscapeKey(propertyKey)}`, propertyValue);
      }
    }
    if (schema.additionalProperties === false) {
      for (const [propertyKey, propertyValue] of Object.entries(value)) {
        if (regex.test(propertyKey))
          continue;
        return yield Create(ValueErrorType.ObjectAdditionalProperties, schema, `${path}/${EscapeKey(propertyKey)}`, propertyValue);
      }
    }
  }
  function* FromRef6(schema, references, path, value) {
    yield* Visit6(Deref(schema, references), references, path, value);
  }
  function* FromRegExp3(schema, references, path, value) {
    if (!IsString2(value))
      return yield Create(ValueErrorType.String, schema, path, value);
    if (IsDefined2(schema.minLength) && !(value.length >= schema.minLength)) {
      yield Create(ValueErrorType.StringMinLength, schema, path, value);
    }
    if (IsDefined2(schema.maxLength) && !(value.length <= schema.maxLength)) {
      yield Create(ValueErrorType.StringMaxLength, schema, path, value);
    }
    const regex = new RegExp(schema.source, schema.flags);
    if (!regex.test(value)) {
      return yield Create(ValueErrorType.RegExp, schema, path, value);
    }
  }
  function* FromString3(schema, references, path, value) {
    if (!IsString2(value))
      return yield Create(ValueErrorType.String, schema, path, value);
    if (IsDefined2(schema.minLength) && !(value.length >= schema.minLength)) {
      yield Create(ValueErrorType.StringMinLength, schema, path, value);
    }
    if (IsDefined2(schema.maxLength) && !(value.length <= schema.maxLength)) {
      yield Create(ValueErrorType.StringMaxLength, schema, path, value);
    }
    if (IsString2(schema.pattern)) {
      const regex = new RegExp(schema.pattern);
      if (!regex.test(value)) {
        yield Create(ValueErrorType.StringPattern, schema, path, value);
      }
    }
    if (IsString2(schema.format)) {
      if (!exports_format.Has(schema.format)) {
        yield Create(ValueErrorType.StringFormatUnknown, schema, path, value);
      } else {
        const format = exports_format.Get(schema.format);
        if (!format(value)) {
          yield Create(ValueErrorType.StringFormat, schema, path, value);
        }
      }
    }
  }
  function* FromSymbol3(schema, references, path, value) {
    if (!IsSymbol2(value))
      yield Create(ValueErrorType.Symbol, schema, path, value);
  }
  function* FromTemplateLiteral5(schema, references, path, value) {
    if (!IsString2(value))
      return yield Create(ValueErrorType.String, schema, path, value);
    const regex = new RegExp(schema.pattern);
    if (!regex.test(value)) {
      yield Create(ValueErrorType.StringPattern, schema, path, value);
    }
  }
  function* FromThis2(schema, references, path, value) {
    yield* Visit6(Deref(schema, references), references, path, value);
  }
  function* FromTuple7(schema, references, path, value) {
    if (!IsArray2(value))
      return yield Create(ValueErrorType.Tuple, schema, path, value);
    if (schema.items === undefined && !(value.length === 0)) {
      return yield Create(ValueErrorType.TupleLength, schema, path, value);
    }
    if (!(value.length === schema.maxItems)) {
      return yield Create(ValueErrorType.TupleLength, schema, path, value);
    }
    if (!schema.items) {
      return;
    }
    for (let i = 0;i < schema.items.length; i++) {
      yield* Visit6(schema.items[i], references, `${path}/${i}`, value[i]);
    }
  }
  function* FromUndefined3(schema, references, path, value) {
    if (!IsUndefined2(value))
      yield Create(ValueErrorType.Undefined, schema, path, value);
  }
  function* FromUnion12(schema, references, path, value) {
    if (Check(schema, references, value))
      return;
    const errors = schema.anyOf.map((variant) => new ValueErrorIterator(Visit6(variant, references, path, value)));
    yield Create(ValueErrorType.Union, schema, path, value, errors);
  }
  function* FromUint8Array3(schema, references, path, value) {
    if (!IsUint8Array2(value))
      return yield Create(ValueErrorType.Uint8Array, schema, path, value);
    if (IsDefined2(schema.maxByteLength) && !(value.length <= schema.maxByteLength)) {
      yield Create(ValueErrorType.Uint8ArrayMaxByteLength, schema, path, value);
    }
    if (IsDefined2(schema.minByteLength) && !(value.length >= schema.minByteLength)) {
      yield Create(ValueErrorType.Uint8ArrayMinByteLength, schema, path, value);
    }
  }
  function* FromUnknown3(schema, references, path, value) {}
  function* FromVoid3(schema, references, path, value) {
    if (!TypeSystemPolicy.IsVoidLike(value))
      yield Create(ValueErrorType.Void, schema, path, value);
  }
  function* FromKind2(schema, references, path, value) {
    const check = exports_type2.Get(schema[Kind]);
    if (!check(schema, value))
      yield Create(ValueErrorType.Kind, schema, path, value);
  }
  function* Visit6(schema, references, path, value) {
    const references_ = IsDefined2(schema.$id) ? [...references, schema] : references;
    const schema_ = schema;
    switch (schema_[Kind]) {
      case "Any":
        return yield* FromAny3(schema_, references_, path, value);
      case "Argument":
        return yield* FromArgument3(schema_, references_, path, value);
      case "Array":
        return yield* FromArray8(schema_, references_, path, value);
      case "AsyncIterator":
        return yield* FromAsyncIterator5(schema_, references_, path, value);
      case "BigInt":
        return yield* FromBigInt3(schema_, references_, path, value);
      case "Boolean":
        return yield* FromBoolean3(schema_, references_, path, value);
      case "Constructor":
        return yield* FromConstructor5(schema_, references_, path, value);
      case "Date":
        return yield* FromDate3(schema_, references_, path, value);
      case "Function":
        return yield* FromFunction5(schema_, references_, path, value);
      case "Import":
        return yield* FromImport2(schema_, references_, path, value);
      case "Integer":
        return yield* FromInteger3(schema_, references_, path, value);
      case "Intersect":
        return yield* FromIntersect10(schema_, references_, path, value);
      case "Iterator":
        return yield* FromIterator5(schema_, references_, path, value);
      case "Literal":
        return yield* FromLiteral4(schema_, references_, path, value);
      case "Never":
        return yield* FromNever3(schema_, references_, path, value);
      case "Not":
        return yield* FromNot3(schema_, references_, path, value);
      case "Null":
        return yield* FromNull3(schema_, references_, path, value);
      case "Number":
        return yield* FromNumber3(schema_, references_, path, value);
      case "Object":
        return yield* FromObject9(schema_, references_, path, value);
      case "Promise":
        return yield* FromPromise5(schema_, references_, path, value);
      case "Record":
        return yield* FromRecord5(schema_, references_, path, value);
      case "Ref":
        return yield* FromRef6(schema_, references_, path, value);
      case "RegExp":
        return yield* FromRegExp3(schema_, references_, path, value);
      case "String":
        return yield* FromString3(schema_, references_, path, value);
      case "Symbol":
        return yield* FromSymbol3(schema_, references_, path, value);
      case "TemplateLiteral":
        return yield* FromTemplateLiteral5(schema_, references_, path, value);
      case "This":
        return yield* FromThis2(schema_, references_, path, value);
      case "Tuple":
        return yield* FromTuple7(schema_, references_, path, value);
      case "Undefined":
        return yield* FromUndefined3(schema_, references_, path, value);
      case "Union":
        return yield* FromUnion12(schema_, references_, path, value);
      case "Uint8Array":
        return yield* FromUint8Array3(schema_, references_, path, value);
      case "Unknown":
        return yield* FromUnknown3(schema_, references_, path, value);
      case "Void":
        return yield* FromVoid3(schema_, references_, path, value);
      default:
        if (!exports_type2.Has(schema_[Kind]))
          throw new ValueErrorsUnknownTypeError(schema);
        return yield* FromKind2(schema_, references_, path, value);
    }
  }
  function Errors(...args) {
    const iterator = args.length === 3 ? Visit6(args[0], args[1], "", args[2]) : Visit6(args[0], [], "", args[1]);
    return new ValueErrorIterator(iterator);
  }

  // node_modules/@sinclair/typebox/build/esm/value/assert/assert.mjs
  var __classPrivateFieldSet = function(receiver, state, value, kind, f) {
    if (kind === "m")
      throw new TypeError("Private method is not writable");
    if (kind === "a" && !f)
      throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
      throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
  };
  var __classPrivateFieldGet = function(receiver, state, kind, f) {
    if (kind === "a" && !f)
      throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
      throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
  };
  var _AssertError_instances;
  var _AssertError_iterator;
  var _AssertError_Iterator;

  class AssertError extends TypeBoxError {
    constructor(iterator) {
      const error = iterator.First();
      super(error === undefined ? "Invalid Value" : error.message);
      _AssertError_instances.add(this);
      _AssertError_iterator.set(this, undefined);
      __classPrivateFieldSet(this, _AssertError_iterator, iterator, "f");
      this.error = error;
    }
    Errors() {
      return new ValueErrorIterator(__classPrivateFieldGet(this, _AssertError_instances, "m", _AssertError_Iterator).call(this));
    }
  }
  _AssertError_iterator = new WeakMap, _AssertError_instances = new WeakSet, _AssertError_Iterator = function* _AssertError_Iterator2() {
    if (this.error)
      yield this.error;
    yield* __classPrivateFieldGet(this, _AssertError_iterator, "f");
  };
  function AssertValue(schema, references, value) {
    if (Check(schema, references, value))
      return;
    throw new AssertError(Errors(schema, references, value));
  }
  function Assert(...args) {
    return args.length === 3 ? AssertValue(args[0], args[1], args[2]) : AssertValue(args[0], [], args[1]);
  }
  // node_modules/@sinclair/typebox/build/esm/value/clone/clone.mjs
  function FromObject10(value) {
    const Acc = {};
    for (const key of Object.getOwnPropertyNames(value)) {
      Acc[key] = Clone2(value[key]);
    }
    for (const key of Object.getOwnPropertySymbols(value)) {
      Acc[key] = Clone2(value[key]);
    }
    return Acc;
  }
  function FromArray9(value) {
    return value.map((element) => Clone2(element));
  }
  function FromTypedArray(value) {
    return value.slice();
  }
  function FromMap(value) {
    return new Map(Clone2([...value.entries()]));
  }
  function FromSet(value) {
    return new Set(Clone2([...value.entries()]));
  }
  function FromDate4(value) {
    return new Date(value.toISOString());
  }
  function FromValue2(value) {
    return value;
  }
  function Clone2(value) {
    if (IsArray2(value))
      return FromArray9(value);
    if (IsDate2(value))
      return FromDate4(value);
    if (IsTypedArray(value))
      return FromTypedArray(value);
    if (IsMap(value))
      return FromMap(value);
    if (IsSet(value))
      return FromSet(value);
    if (IsObject2(value))
      return FromObject10(value);
    if (IsValueType(value))
      return FromValue2(value);
    throw new Error("ValueClone: Unable to clone value");
  }

  // node_modules/@sinclair/typebox/build/esm/value/create/create.mjs
  class ValueCreateError extends TypeBoxError {
    constructor(schema, message) {
      super(message);
      this.schema = schema;
    }
  }
  function FromDefault(value) {
    return IsFunction2(value) ? value() : Clone2(value);
  }
  function FromAny4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return {};
    }
  }
  function FromArgument4(schema, references) {
    return {};
  }
  function FromArray10(schema, references) {
    if (schema.uniqueItems === true && !HasPropertyKey2(schema, "default")) {
      throw new ValueCreateError(schema, "Array with the uniqueItems constraint requires a default value");
    } else if ("contains" in schema && !HasPropertyKey2(schema, "default")) {
      throw new ValueCreateError(schema, "Array with the contains constraint requires a default value");
    } else if ("default" in schema) {
      return FromDefault(schema.default);
    } else if (schema.minItems !== undefined) {
      return Array.from({ length: schema.minItems }).map((item) => {
        return Visit7(schema.items, references);
      });
    } else {
      return [];
    }
  }
  function FromAsyncIterator6(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return async function* () {}();
    }
  }
  function FromBigInt4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return BigInt(0);
    }
  }
  function FromBoolean4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return false;
    }
  }
  function FromConstructor6(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      const value = Visit7(schema.returns, references);
      if (typeof value === "object" && !Array.isArray(value)) {
        return class {
          constructor() {
            for (const [key, val] of Object.entries(value)) {
              const self = this;
              self[key] = val;
            }
          }
        };
      } else {
        return class {
        };
      }
    }
  }
  function FromDate5(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else if (schema.minimumTimestamp !== undefined) {
      return new Date(schema.minimumTimestamp);
    } else {
      return new Date;
    }
  }
  function FromFunction6(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return () => Visit7(schema.returns, references);
    }
  }
  function FromImport3(schema, references) {
    const definitions = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    return Visit7(target, [...references, ...definitions]);
  }
  function FromInteger4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else if (schema.minimum !== undefined) {
      return schema.minimum;
    } else {
      return 0;
    }
  }
  function FromIntersect11(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      const value = schema.allOf.reduce((acc, schema2) => {
        const next = Visit7(schema2, references);
        return typeof next === "object" ? { ...acc, ...next } : next;
      }, {});
      if (!Check(schema, references, value))
        throw new ValueCreateError(schema, "Intersect produced invalid value. Consider using a default value.");
      return value;
    }
  }
  function FromIterator6(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return function* () {}();
    }
  }
  function FromLiteral5(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return schema.const;
    }
  }
  function FromNever4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      throw new ValueCreateError(schema, "Never types cannot be created. Consider using a default value.");
    }
  }
  function FromNot4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      throw new ValueCreateError(schema, "Not types must have a default value");
    }
  }
  function FromNull4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return null;
    }
  }
  function FromNumber4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else if (schema.minimum !== undefined) {
      return schema.minimum;
    } else {
      return 0;
    }
  }
  function FromObject11(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      const required = new Set(schema.required);
      const Acc = {};
      for (const [key, subschema] of Object.entries(schema.properties)) {
        if (!required.has(key))
          continue;
        Acc[key] = Visit7(subschema, references);
      }
      return Acc;
    }
  }
  function FromPromise6(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return Promise.resolve(Visit7(schema.item, references));
    }
  }
  function FromRecord6(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return {};
    }
  }
  function FromRef7(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return Visit7(Deref(schema, references), references);
    }
  }
  function FromRegExp4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      throw new ValueCreateError(schema, "RegExp types cannot be created. Consider using a default value.");
    }
  }
  function FromString4(schema, references) {
    if (schema.pattern !== undefined) {
      if (!HasPropertyKey2(schema, "default")) {
        throw new ValueCreateError(schema, "String types with patterns must specify a default value");
      } else {
        return FromDefault(schema.default);
      }
    } else if (schema.format !== undefined) {
      if (!HasPropertyKey2(schema, "default")) {
        throw new ValueCreateError(schema, "String types with formats must specify a default value");
      } else {
        return FromDefault(schema.default);
      }
    } else {
      if (HasPropertyKey2(schema, "default")) {
        return FromDefault(schema.default);
      } else if (schema.minLength !== undefined) {
        return Array.from({ length: schema.minLength }).map(() => " ").join("");
      } else {
        return "";
      }
    }
  }
  function FromSymbol4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else if ("value" in schema) {
      return Symbol.for(schema.value);
    } else {
      return Symbol();
    }
  }
  function FromTemplateLiteral6(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    }
    if (!IsTemplateLiteralFinite(schema))
      throw new ValueCreateError(schema, "Can only create template literals that produce a finite variants. Consider using a default value.");
    const generated = TemplateLiteralGenerate(schema);
    return generated[0];
  }
  function FromThis3(schema, references) {
    if (recursiveDepth++ > recursiveMaxDepth)
      throw new ValueCreateError(schema, "Cannot create recursive type as it appears possibly infinite. Consider using a default.");
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return Visit7(Deref(schema, references), references);
    }
  }
  function FromTuple8(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    }
    if (schema.items === undefined) {
      return [];
    } else {
      return Array.from({ length: schema.minItems }).map((_, index) => Visit7(schema.items[index], references));
    }
  }
  function FromUndefined4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return;
    }
  }
  function FromUnion13(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else if (schema.anyOf.length === 0) {
      throw new Error("ValueCreate.Union: Cannot create Union with zero variants");
    } else {
      return Visit7(schema.anyOf[0], references);
    }
  }
  function FromUint8Array4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else if (schema.minByteLength !== undefined) {
      return new Uint8Array(schema.minByteLength);
    } else {
      return new Uint8Array(0);
    }
  }
  function FromUnknown4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return {};
    }
  }
  function FromVoid4(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      return;
    }
  }
  function FromKind3(schema, references) {
    if (HasPropertyKey2(schema, "default")) {
      return FromDefault(schema.default);
    } else {
      throw new Error("User defined types must specify a default value");
    }
  }
  function Visit7(schema, references) {
    const references_ = Pushref(schema, references);
    const schema_ = schema;
    switch (schema_[Kind]) {
      case "Any":
        return FromAny4(schema_, references_);
      case "Argument":
        return FromArgument4(schema_, references_);
      case "Array":
        return FromArray10(schema_, references_);
      case "AsyncIterator":
        return FromAsyncIterator6(schema_, references_);
      case "BigInt":
        return FromBigInt4(schema_, references_);
      case "Boolean":
        return FromBoolean4(schema_, references_);
      case "Constructor":
        return FromConstructor6(schema_, references_);
      case "Date":
        return FromDate5(schema_, references_);
      case "Function":
        return FromFunction6(schema_, references_);
      case "Import":
        return FromImport3(schema_, references_);
      case "Integer":
        return FromInteger4(schema_, references_);
      case "Intersect":
        return FromIntersect11(schema_, references_);
      case "Iterator":
        return FromIterator6(schema_, references_);
      case "Literal":
        return FromLiteral5(schema_, references_);
      case "Never":
        return FromNever4(schema_, references_);
      case "Not":
        return FromNot4(schema_, references_);
      case "Null":
        return FromNull4(schema_, references_);
      case "Number":
        return FromNumber4(schema_, references_);
      case "Object":
        return FromObject11(schema_, references_);
      case "Promise":
        return FromPromise6(schema_, references_);
      case "Record":
        return FromRecord6(schema_, references_);
      case "Ref":
        return FromRef7(schema_, references_);
      case "RegExp":
        return FromRegExp4(schema_, references_);
      case "String":
        return FromString4(schema_, references_);
      case "Symbol":
        return FromSymbol4(schema_, references_);
      case "TemplateLiteral":
        return FromTemplateLiteral6(schema_, references_);
      case "This":
        return FromThis3(schema_, references_);
      case "Tuple":
        return FromTuple8(schema_, references_);
      case "Undefined":
        return FromUndefined4(schema_, references_);
      case "Union":
        return FromUnion13(schema_, references_);
      case "Uint8Array":
        return FromUint8Array4(schema_, references_);
      case "Unknown":
        return FromUnknown4(schema_, references_);
      case "Void":
        return FromVoid4(schema_, references_);
      default:
        if (!exports_type2.Has(schema_[Kind]))
          throw new ValueCreateError(schema_, "Unknown type");
        return FromKind3(schema_, references_);
    }
  }
  var recursiveMaxDepth = 512;
  var recursiveDepth = 0;
  function Create2(...args) {
    recursiveDepth = 0;
    return args.length === 2 ? Visit7(args[0], args[1]) : Visit7(args[0], []);
  }

  // node_modules/@sinclair/typebox/build/esm/value/cast/cast.mjs
  class ValueCastError extends TypeBoxError {
    constructor(schema, message) {
      super(message);
      this.schema = schema;
    }
  }
  function ScoreUnion(schema, references, value) {
    if (schema[Kind] === "Object" && typeof value === "object" && !IsNull2(value)) {
      const object = schema;
      const keys = Object.getOwnPropertyNames(value);
      const entries = Object.entries(object.properties);
      return entries.reduce((acc, [key, schema2]) => {
        const literal = schema2[Kind] === "Literal" && schema2.const === value[key] ? 100 : 0;
        const checks = Check(schema2, references, value[key]) ? 10 : 0;
        const exists = keys.includes(key) ? 1 : 0;
        return acc + (literal + checks + exists);
      }, 0);
    } else if (schema[Kind] === "Union") {
      const schemas = schema.anyOf.map((schema2) => Deref(schema2, references));
      const scores = schemas.map((schema2) => ScoreUnion(schema2, references, value));
      return Math.max(...scores);
    } else {
      return Check(schema, references, value) ? 1 : 0;
    }
  }
  function SelectUnion(union, references, value) {
    const schemas = union.anyOf.map((schema) => Deref(schema, references));
    let [select, best] = [schemas[0], 0];
    for (const schema of schemas) {
      const score = ScoreUnion(schema, references, value);
      if (score > best) {
        select = schema;
        best = score;
      }
    }
    return select;
  }
  function CastUnion(union, references, value) {
    if ("default" in union) {
      return typeof value === "function" ? union.default : Clone2(union.default);
    } else {
      const schema = SelectUnion(union, references, value);
      return Cast(schema, references, value);
    }
  }
  function DefaultClone(schema, references, value) {
    return Check(schema, references, value) ? Clone2(value) : Create2(schema, references);
  }
  function Default(schema, references, value) {
    return Check(schema, references, value) ? value : Create2(schema, references);
  }
  function FromArray11(schema, references, value) {
    if (Check(schema, references, value))
      return Clone2(value);
    const created = IsArray2(value) ? Clone2(value) : Create2(schema, references);
    const minimum = IsNumber2(schema.minItems) && created.length < schema.minItems ? [...created, ...Array.from({ length: schema.minItems - created.length }, () => null)] : created;
    const maximum = IsNumber2(schema.maxItems) && minimum.length > schema.maxItems ? minimum.slice(0, schema.maxItems) : minimum;
    const casted = maximum.map((value2) => Visit8(schema.items, references, value2));
    if (schema.uniqueItems !== true)
      return casted;
    const unique = [...new Set(casted)];
    if (!Check(schema, references, unique))
      throw new ValueCastError(schema, "Array cast produced invalid data due to uniqueItems constraint");
    return unique;
  }
  function FromConstructor7(schema, references, value) {
    if (Check(schema, references, value))
      return Create2(schema, references);
    const required = new Set(schema.returns.required || []);
    const result = function() {};
    for (const [key, property] of Object.entries(schema.returns.properties)) {
      if (!required.has(key) && value.prototype[key] === undefined)
        continue;
      result.prototype[key] = Visit8(property, references, value.prototype[key]);
    }
    return result;
  }
  function FromImport4(schema, references, value) {
    const definitions = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    return Visit8(target, [...references, ...definitions], value);
  }
  function IntersectAssign(correct, value) {
    if (IsObject2(correct) && !IsObject2(value) || !IsObject2(correct) && IsObject2(value))
      return correct;
    if (!IsObject2(correct) || !IsObject2(value))
      return value;
    return globalThis.Object.getOwnPropertyNames(correct).reduce((result, key) => {
      const property = key in value ? IntersectAssign(correct[key], value[key]) : correct[key];
      return { ...result, [key]: property };
    }, {});
  }
  function FromIntersect12(schema, references, value) {
    if (Check(schema, references, value))
      return value;
    const correct = Create2(schema, references);
    const assigned = IntersectAssign(correct, value);
    return Check(schema, references, assigned) ? assigned : correct;
  }
  function FromNever5(schema, references, value) {
    throw new ValueCastError(schema, "Never types cannot be cast");
  }
  function FromObject12(schema, references, value) {
    if (Check(schema, references, value))
      return value;
    if (value === null || typeof value !== "object")
      return Create2(schema, references);
    const required = new Set(schema.required || []);
    const result = {};
    for (const [key, property] of Object.entries(schema.properties)) {
      if (!required.has(key) && value[key] === undefined)
        continue;
      result[key] = Visit8(property, references, value[key]);
    }
    if (typeof schema.additionalProperties === "object") {
      const propertyNames = Object.getOwnPropertyNames(schema.properties);
      for (const propertyName of Object.getOwnPropertyNames(value)) {
        if (propertyNames.includes(propertyName))
          continue;
        result[propertyName] = Visit8(schema.additionalProperties, references, value[propertyName]);
      }
    }
    return result;
  }
  function FromRecord7(schema, references, value) {
    if (Check(schema, references, value))
      return Clone2(value);
    if (value === null || typeof value !== "object" || Array.isArray(value) || value instanceof Date)
      return Create2(schema, references);
    const subschemaPropertyName = Object.getOwnPropertyNames(schema.patternProperties)[0];
    const subschema = schema.patternProperties[subschemaPropertyName];
    const result = {};
    for (const [propKey, propValue] of Object.entries(value)) {
      result[propKey] = Visit8(subschema, references, propValue);
    }
    return result;
  }
  function FromRef8(schema, references, value) {
    return Visit8(Deref(schema, references), references, value);
  }
  function FromThis4(schema, references, value) {
    return Visit8(Deref(schema, references), references, value);
  }
  function FromTuple9(schema, references, value) {
    if (Check(schema, references, value))
      return Clone2(value);
    if (!IsArray2(value))
      return Create2(schema, references);
    if (schema.items === undefined)
      return [];
    return schema.items.map((schema2, index) => Visit8(schema2, references, value[index]));
  }
  function FromUnion14(schema, references, value) {
    return Check(schema, references, value) ? Clone2(value) : CastUnion(schema, references, value);
  }
  function Visit8(schema, references, value) {
    const references_ = IsString2(schema.$id) ? Pushref(schema, references) : references;
    const schema_ = schema;
    switch (schema[Kind]) {
      case "Array":
        return FromArray11(schema_, references_, value);
      case "Constructor":
        return FromConstructor7(schema_, references_, value);
      case "Import":
        return FromImport4(schema_, references_, value);
      case "Intersect":
        return FromIntersect12(schema_, references_, value);
      case "Never":
        return FromNever5(schema_, references_, value);
      case "Object":
        return FromObject12(schema_, references_, value);
      case "Record":
        return FromRecord7(schema_, references_, value);
      case "Ref":
        return FromRef8(schema_, references_, value);
      case "This":
        return FromThis4(schema_, references_, value);
      case "Tuple":
        return FromTuple9(schema_, references_, value);
      case "Union":
        return FromUnion14(schema_, references_, value);
      case "Date":
      case "Symbol":
      case "Uint8Array":
        return DefaultClone(schema, references, value);
      default:
        return Default(schema_, references_, value);
    }
  }
  function Cast(...args) {
    return args.length === 3 ? Visit8(args[0], args[1], args[2]) : Visit8(args[0], [], args[1]);
  }
  // node_modules/@sinclair/typebox/build/esm/value/clean/clean.mjs
  function IsCheckable(schema) {
    return IsKind(schema) && schema[Kind] !== "Unsafe";
  }
  function FromArray12(schema, references, value) {
    if (!IsArray2(value))
      return value;
    return value.map((value2) => Visit9(schema.items, references, value2));
  }
  function FromImport5(schema, references, value) {
    const definitions = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    return Visit9(target, [...references, ...definitions], value);
  }
  function FromIntersect13(schema, references, value) {
    const unevaluatedProperties = schema.unevaluatedProperties;
    const intersections = schema.allOf.map((schema2) => Visit9(schema2, references, Clone2(value)));
    const composite = intersections.reduce((acc, value2) => IsObject2(value2) ? { ...acc, ...value2 } : value2, {});
    if (!IsObject2(value) || !IsObject2(composite) || !IsKind(unevaluatedProperties))
      return composite;
    const knownkeys = KeyOfPropertyKeys(schema);
    for (const key of Object.getOwnPropertyNames(value)) {
      if (knownkeys.includes(key))
        continue;
      if (Check(unevaluatedProperties, references, value[key])) {
        composite[key] = Visit9(unevaluatedProperties, references, value[key]);
      }
    }
    return composite;
  }
  function FromObject13(schema, references, value) {
    if (!IsObject2(value) || IsArray2(value))
      return value;
    const additionalProperties = schema.additionalProperties;
    for (const key of Object.getOwnPropertyNames(value)) {
      if (HasPropertyKey2(schema.properties, key)) {
        value[key] = Visit9(schema.properties[key], references, value[key]);
        continue;
      }
      if (IsKind(additionalProperties) && Check(additionalProperties, references, value[key])) {
        value[key] = Visit9(additionalProperties, references, value[key]);
        continue;
      }
      delete value[key];
    }
    return value;
  }
  function FromRecord8(schema, references, value) {
    if (!IsObject2(value))
      return value;
    const additionalProperties = schema.additionalProperties;
    const propertyKeys = Object.getOwnPropertyNames(value);
    const [propertyKey, propertySchema] = Object.entries(schema.patternProperties)[0];
    const propertyKeyTest = new RegExp(propertyKey);
    for (const key of propertyKeys) {
      if (propertyKeyTest.test(key)) {
        value[key] = Visit9(propertySchema, references, value[key]);
        continue;
      }
      if (IsKind(additionalProperties) && Check(additionalProperties, references, value[key])) {
        value[key] = Visit9(additionalProperties, references, value[key]);
        continue;
      }
      delete value[key];
    }
    return value;
  }
  function FromRef9(schema, references, value) {
    return Visit9(Deref(schema, references), references, value);
  }
  function FromThis5(schema, references, value) {
    return Visit9(Deref(schema, references), references, value);
  }
  function FromTuple10(schema, references, value) {
    if (!IsArray2(value))
      return value;
    if (IsUndefined2(schema.items))
      return [];
    const length = Math.min(value.length, schema.items.length);
    for (let i = 0;i < length; i++) {
      value[i] = Visit9(schema.items[i], references, value[i]);
    }
    return value.length > length ? value.slice(0, length) : value;
  }
  function FromUnion15(schema, references, value) {
    for (const inner of schema.anyOf) {
      if (IsCheckable(inner) && Check(inner, references, value)) {
        return Visit9(inner, references, value);
      }
    }
    return value;
  }
  function Visit9(schema, references, value) {
    const references_ = IsString2(schema.$id) ? Pushref(schema, references) : references;
    const schema_ = schema;
    switch (schema_[Kind]) {
      case "Array":
        return FromArray12(schema_, references_, value);
      case "Import":
        return FromImport5(schema_, references_, value);
      case "Intersect":
        return FromIntersect13(schema_, references_, value);
      case "Object":
        return FromObject13(schema_, references_, value);
      case "Record":
        return FromRecord8(schema_, references_, value);
      case "Ref":
        return FromRef9(schema_, references_, value);
      case "This":
        return FromThis5(schema_, references_, value);
      case "Tuple":
        return FromTuple10(schema_, references_, value);
      case "Union":
        return FromUnion15(schema_, references_, value);
      default:
        return value;
    }
  }
  function Clean(...args) {
    return args.length === 3 ? Visit9(args[0], args[1], args[2]) : Visit9(args[0], [], args[1]);
  }
  // node_modules/@sinclair/typebox/build/esm/value/convert/convert.mjs
  function IsStringNumeric(value) {
    return IsString2(value) && !isNaN(value) && !isNaN(parseFloat(value));
  }
  function IsValueToString(value) {
    return IsBigInt2(value) || IsBoolean2(value) || IsNumber2(value);
  }
  function IsValueTrue(value) {
    return value === true || IsNumber2(value) && value === 1 || IsBigInt2(value) && value === BigInt("1") || IsString2(value) && (value.toLowerCase() === "true" || value === "1");
  }
  function IsValueFalse(value) {
    return value === false || IsNumber2(value) && (value === 0 || Object.is(value, -0)) || IsBigInt2(value) && value === BigInt("0") || IsString2(value) && (value.toLowerCase() === "false" || value === "0" || value === "-0");
  }
  function IsTimeStringWithTimeZone(value) {
    return IsString2(value) && /^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i.test(value);
  }
  function IsTimeStringWithoutTimeZone(value) {
    return IsString2(value) && /^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)?$/i.test(value);
  }
  function IsDateTimeStringWithTimeZone(value) {
    return IsString2(value) && /^\d\d\d\d-[0-1]\d-[0-3]\dt(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i.test(value);
  }
  function IsDateTimeStringWithoutTimeZone(value) {
    return IsString2(value) && /^\d\d\d\d-[0-1]\d-[0-3]\dt(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)?$/i.test(value);
  }
  function IsDateString(value) {
    return IsString2(value) && /^\d\d\d\d-[0-1]\d-[0-3]\d$/i.test(value);
  }
  function TryConvertLiteralString(value, target) {
    const conversion = TryConvertString(value);
    return conversion === target ? conversion : value;
  }
  function TryConvertLiteralNumber(value, target) {
    const conversion = TryConvertNumber(value);
    return conversion === target ? conversion : value;
  }
  function TryConvertLiteralBoolean(value, target) {
    const conversion = TryConvertBoolean(value);
    return conversion === target ? conversion : value;
  }
  function TryConvertLiteral(schema, value) {
    return IsString2(schema.const) ? TryConvertLiteralString(value, schema.const) : IsNumber2(schema.const) ? TryConvertLiteralNumber(value, schema.const) : IsBoolean2(schema.const) ? TryConvertLiteralBoolean(value, schema.const) : value;
  }
  function TryConvertBoolean(value) {
    return IsValueTrue(value) ? true : IsValueFalse(value) ? false : value;
  }
  function TryConvertBigInt(value) {
    const truncateInteger = (value2) => value2.split(".")[0];
    return IsStringNumeric(value) ? BigInt(truncateInteger(value)) : IsNumber2(value) ? BigInt(Math.trunc(value)) : IsValueFalse(value) ? BigInt(0) : IsValueTrue(value) ? BigInt(1) : value;
  }
  function TryConvertString(value) {
    return IsSymbol2(value) && value.description !== undefined ? value.description.toString() : IsValueToString(value) ? value.toString() : value;
  }
  function TryConvertNumber(value) {
    return IsStringNumeric(value) ? parseFloat(value) : IsValueTrue(value) ? 1 : IsValueFalse(value) ? 0 : value;
  }
  function TryConvertInteger(value) {
    return IsStringNumeric(value) ? parseInt(value) : IsNumber2(value) ? Math.trunc(value) : IsValueTrue(value) ? 1 : IsValueFalse(value) ? 0 : value;
  }
  function TryConvertNull(value) {
    return IsString2(value) && value.toLowerCase() === "null" ? null : value;
  }
  function TryConvertUndefined(value) {
    return IsString2(value) && value === "undefined" ? undefined : value;
  }
  function TryConvertDate(value) {
    return IsDate2(value) ? value : IsNumber2(value) ? new Date(value) : IsValueTrue(value) ? new Date(1) : IsValueFalse(value) ? new Date(0) : IsStringNumeric(value) ? new Date(parseInt(value)) : IsTimeStringWithoutTimeZone(value) ? new Date(`1970-01-01T${value}.000Z`) : IsTimeStringWithTimeZone(value) ? new Date(`1970-01-01T${value}`) : IsDateTimeStringWithoutTimeZone(value) ? new Date(`${value}.000Z`) : IsDateTimeStringWithTimeZone(value) ? new Date(value) : IsDateString(value) ? new Date(`${value}T00:00:00.000Z`) : value;
  }
  function Default2(value) {
    return value;
  }
  function FromArray13(schema, references, value) {
    const elements = IsArray2(value) ? value : [value];
    return elements.map((element) => Visit10(schema.items, references, element));
  }
  function FromBigInt5(schema, references, value) {
    return TryConvertBigInt(value);
  }
  function FromBoolean5(schema, references, value) {
    return TryConvertBoolean(value);
  }
  function FromDate6(schema, references, value) {
    return TryConvertDate(value);
  }
  function FromImport6(schema, references, value) {
    const definitions = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    return Visit10(target, [...references, ...definitions], value);
  }
  function FromInteger5(schema, references, value) {
    return TryConvertInteger(value);
  }
  function FromIntersect14(schema, references, value) {
    return schema.allOf.reduce((value2, schema2) => Visit10(schema2, references, value2), value);
  }
  function FromLiteral6(schema, references, value) {
    return TryConvertLiteral(schema, value);
  }
  function FromNull5(schema, references, value) {
    return TryConvertNull(value);
  }
  function FromNumber5(schema, references, value) {
    return TryConvertNumber(value);
  }
  function FromObject14(schema, references, value) {
    if (!IsObject2(value) || IsArray2(value))
      return value;
    for (const propertyKey of Object.getOwnPropertyNames(schema.properties)) {
      if (!HasPropertyKey2(value, propertyKey))
        continue;
      value[propertyKey] = Visit10(schema.properties[propertyKey], references, value[propertyKey]);
    }
    return value;
  }
  function FromRecord9(schema, references, value) {
    const isConvertable = IsObject2(value) && !IsArray2(value);
    if (!isConvertable)
      return value;
    const propertyKey = Object.getOwnPropertyNames(schema.patternProperties)[0];
    const property = schema.patternProperties[propertyKey];
    for (const [propKey, propValue] of Object.entries(value)) {
      value[propKey] = Visit10(property, references, propValue);
    }
    return value;
  }
  function FromRef10(schema, references, value) {
    return Visit10(Deref(schema, references), references, value);
  }
  function FromString5(schema, references, value) {
    return TryConvertString(value);
  }
  function FromSymbol5(schema, references, value) {
    return IsString2(value) || IsNumber2(value) ? Symbol(value) : value;
  }
  function FromThis6(schema, references, value) {
    return Visit10(Deref(schema, references), references, value);
  }
  function FromTuple11(schema, references, value) {
    const isConvertable = IsArray2(value) && !IsUndefined2(schema.items);
    if (!isConvertable)
      return value;
    return value.map((value2, index) => {
      return index < schema.items.length ? Visit10(schema.items[index], references, value2) : value2;
    });
  }
  function FromUndefined5(schema, references, value) {
    return TryConvertUndefined(value);
  }
  function FromUnion16(schema, references, value) {
    for (const subschema of schema.anyOf) {
      if (Check(subschema, references, value)) {
        return value;
      }
    }
    for (const subschema of schema.anyOf) {
      const converted = Visit10(subschema, references, Clone2(value));
      if (!Check(subschema, references, converted))
        continue;
      return converted;
    }
    return value;
  }
  function Visit10(schema, references, value) {
    const references_ = Pushref(schema, references);
    const schema_ = schema;
    switch (schema[Kind]) {
      case "Array":
        return FromArray13(schema_, references_, value);
      case "BigInt":
        return FromBigInt5(schema_, references_, value);
      case "Boolean":
        return FromBoolean5(schema_, references_, value);
      case "Date":
        return FromDate6(schema_, references_, value);
      case "Import":
        return FromImport6(schema_, references_, value);
      case "Integer":
        return FromInteger5(schema_, references_, value);
      case "Intersect":
        return FromIntersect14(schema_, references_, value);
      case "Literal":
        return FromLiteral6(schema_, references_, value);
      case "Null":
        return FromNull5(schema_, references_, value);
      case "Number":
        return FromNumber5(schema_, references_, value);
      case "Object":
        return FromObject14(schema_, references_, value);
      case "Record":
        return FromRecord9(schema_, references_, value);
      case "Ref":
        return FromRef10(schema_, references_, value);
      case "String":
        return FromString5(schema_, references_, value);
      case "Symbol":
        return FromSymbol5(schema_, references_, value);
      case "This":
        return FromThis6(schema_, references_, value);
      case "Tuple":
        return FromTuple11(schema_, references_, value);
      case "Undefined":
        return FromUndefined5(schema_, references_, value);
      case "Union":
        return FromUnion16(schema_, references_, value);
      default:
        return Default2(value);
    }
  }
  function Convert(...args) {
    return args.length === 3 ? Visit10(args[0], args[1], args[2]) : Visit10(args[0], [], args[1]);
  }
  // node_modules/@sinclair/typebox/build/esm/value/transform/decode.mjs
  class TransformDecodeCheckError extends TypeBoxError {
    constructor(schema, value, error) {
      super(`Unable to decode value as it does not match the expected schema`);
      this.schema = schema;
      this.value = value;
      this.error = error;
    }
  }

  class TransformDecodeError extends TypeBoxError {
    constructor(schema, path, value, error) {
      super(error instanceof Error ? error.message : "Unknown error");
      this.schema = schema;
      this.path = path;
      this.value = value;
      this.error = error;
    }
  }
  function Default3(schema, path, value) {
    try {
      return IsTransform(schema) ? schema[TransformKind].Decode(value) : value;
    } catch (error) {
      throw new TransformDecodeError(schema, path, value, error);
    }
  }
  function FromArray14(schema, references, path, value) {
    return IsArray2(value) ? Default3(schema, path, value.map((value2, index) => Visit11(schema.items, references, `${path}/${index}`, value2))) : Default3(schema, path, value);
  }
  function FromIntersect15(schema, references, path, value) {
    if (!IsObject2(value) || IsValueType(value))
      return Default3(schema, path, value);
    const knownEntries = KeyOfPropertyEntries(schema);
    const knownKeys = knownEntries.map((entry) => entry[0]);
    const knownProperties = { ...value };
    for (const [knownKey, knownSchema] of knownEntries)
      if (knownKey in knownProperties) {
        knownProperties[knownKey] = Visit11(knownSchema, references, `${path}/${knownKey}`, knownProperties[knownKey]);
      }
    if (!IsTransform(schema.unevaluatedProperties)) {
      return Default3(schema, path, knownProperties);
    }
    const unknownKeys = Object.getOwnPropertyNames(knownProperties);
    const unevaluatedProperties = schema.unevaluatedProperties;
    const unknownProperties = { ...knownProperties };
    for (const key of unknownKeys)
      if (!knownKeys.includes(key)) {
        unknownProperties[key] = Default3(unevaluatedProperties, `${path}/${key}`, unknownProperties[key]);
      }
    return Default3(schema, path, unknownProperties);
  }
  function FromImport7(schema, references, path, value) {
    const additional = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    const result = Visit11(target, [...references, ...additional], path, value);
    return Default3(schema, path, result);
  }
  function FromNot5(schema, references, path, value) {
    return Default3(schema, path, Visit11(schema.not, references, path, value));
  }
  function FromObject15(schema, references, path, value) {
    if (!IsObject2(value))
      return Default3(schema, path, value);
    const knownKeys = KeyOfPropertyKeys(schema);
    const knownProperties = { ...value };
    for (const key of knownKeys) {
      if (!HasPropertyKey2(knownProperties, key))
        continue;
      if (IsUndefined2(knownProperties[key]) && (!IsUndefined3(schema.properties[key]) || TypeSystemPolicy.IsExactOptionalProperty(knownProperties, key)))
        continue;
      knownProperties[key] = Visit11(schema.properties[key], references, `${path}/${key}`, knownProperties[key]);
    }
    if (!IsSchema(schema.additionalProperties)) {
      return Default3(schema, path, knownProperties);
    }
    const unknownKeys = Object.getOwnPropertyNames(knownProperties);
    const additionalProperties = schema.additionalProperties;
    const unknownProperties = { ...knownProperties };
    for (const key of unknownKeys)
      if (!knownKeys.includes(key)) {
        unknownProperties[key] = Default3(additionalProperties, `${path}/${key}`, unknownProperties[key]);
      }
    return Default3(schema, path, unknownProperties);
  }
  function FromRecord10(schema, references, path, value) {
    if (!IsObject2(value))
      return Default3(schema, path, value);
    const pattern = Object.getOwnPropertyNames(schema.patternProperties)[0];
    const knownKeys = new RegExp(pattern);
    const knownProperties = { ...value };
    for (const key of Object.getOwnPropertyNames(value))
      if (knownKeys.test(key)) {
        knownProperties[key] = Visit11(schema.patternProperties[pattern], references, `${path}/${key}`, knownProperties[key]);
      }
    if (!IsSchema(schema.additionalProperties)) {
      return Default3(schema, path, knownProperties);
    }
    const unknownKeys = Object.getOwnPropertyNames(knownProperties);
    const additionalProperties = schema.additionalProperties;
    const unknownProperties = { ...knownProperties };
    for (const key of unknownKeys)
      if (!knownKeys.test(key)) {
        unknownProperties[key] = Default3(additionalProperties, `${path}/${key}`, unknownProperties[key]);
      }
    return Default3(schema, path, unknownProperties);
  }
  function FromRef11(schema, references, path, value) {
    const target = Deref(schema, references);
    return Default3(schema, path, Visit11(target, references, path, value));
  }
  function FromThis7(schema, references, path, value) {
    const target = Deref(schema, references);
    return Default3(schema, path, Visit11(target, references, path, value));
  }
  function FromTuple12(schema, references, path, value) {
    return IsArray2(value) && IsArray2(schema.items) ? Default3(schema, path, schema.items.map((schema2, index) => Visit11(schema2, references, `${path}/${index}`, value[index]))) : Default3(schema, path, value);
  }
  function FromUnion17(schema, references, path, value) {
    for (const subschema of schema.anyOf) {
      if (!Check(subschema, references, value))
        continue;
      const decoded = Visit11(subschema, references, path, value);
      return Default3(schema, path, decoded);
    }
    return Default3(schema, path, value);
  }
  function Visit11(schema, references, path, value) {
    const references_ = Pushref(schema, references);
    const schema_ = schema;
    switch (schema[Kind]) {
      case "Array":
        return FromArray14(schema_, references_, path, value);
      case "Import":
        return FromImport7(schema_, references_, path, value);
      case "Intersect":
        return FromIntersect15(schema_, references_, path, value);
      case "Not":
        return FromNot5(schema_, references_, path, value);
      case "Object":
        return FromObject15(schema_, references_, path, value);
      case "Record":
        return FromRecord10(schema_, references_, path, value);
      case "Ref":
        return FromRef11(schema_, references_, path, value);
      case "Symbol":
        return Default3(schema_, path, value);
      case "This":
        return FromThis7(schema_, references_, path, value);
      case "Tuple":
        return FromTuple12(schema_, references_, path, value);
      case "Union":
        return FromUnion17(schema_, references_, path, value);
      default:
        return Default3(schema_, path, value);
    }
  }
  function TransformDecode(schema, references, value) {
    return Visit11(schema, references, "", value);
  }

  // node_modules/@sinclair/typebox/build/esm/value/transform/encode.mjs
  class TransformEncodeCheckError extends TypeBoxError {
    constructor(schema, value, error) {
      super(`The encoded value does not match the expected schema`);
      this.schema = schema;
      this.value = value;
      this.error = error;
    }
  }

  class TransformEncodeError extends TypeBoxError {
    constructor(schema, path, value, error) {
      super(`${error instanceof Error ? error.message : "Unknown error"}`);
      this.schema = schema;
      this.path = path;
      this.value = value;
      this.error = error;
    }
  }
  function Default4(schema, path, value) {
    try {
      return IsTransform(schema) ? schema[TransformKind].Encode(value) : value;
    } catch (error) {
      throw new TransformEncodeError(schema, path, value, error);
    }
  }
  function FromArray15(schema, references, path, value) {
    const defaulted = Default4(schema, path, value);
    return IsArray2(defaulted) ? defaulted.map((value2, index) => Visit12(schema.items, references, `${path}/${index}`, value2)) : defaulted;
  }
  function FromImport8(schema, references, path, value) {
    const additional = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    const result = Default4(schema, path, value);
    return Visit12(target, [...references, ...additional], path, result);
  }
  function FromIntersect16(schema, references, path, value) {
    const defaulted = Default4(schema, path, value);
    if (!IsObject2(value) || IsValueType(value))
      return defaulted;
    const knownEntries = KeyOfPropertyEntries(schema);
    const knownKeys = knownEntries.map((entry) => entry[0]);
    const knownProperties = { ...defaulted };
    for (const [knownKey, knownSchema] of knownEntries)
      if (knownKey in knownProperties) {
        knownProperties[knownKey] = Visit12(knownSchema, references, `${path}/${knownKey}`, knownProperties[knownKey]);
      }
    if (!IsTransform(schema.unevaluatedProperties)) {
      return knownProperties;
    }
    const unknownKeys = Object.getOwnPropertyNames(knownProperties);
    const unevaluatedProperties = schema.unevaluatedProperties;
    const properties = { ...knownProperties };
    for (const key of unknownKeys)
      if (!knownKeys.includes(key)) {
        properties[key] = Default4(unevaluatedProperties, `${path}/${key}`, properties[key]);
      }
    return properties;
  }
  function FromNot6(schema, references, path, value) {
    return Default4(schema.not, path, Default4(schema, path, value));
  }
  function FromObject16(schema, references, path, value) {
    const defaulted = Default4(schema, path, value);
    if (!IsObject2(defaulted))
      return defaulted;
    const knownKeys = KeyOfPropertyKeys(schema);
    const knownProperties = { ...defaulted };
    for (const key of knownKeys) {
      if (!HasPropertyKey2(knownProperties, key))
        continue;
      if (IsUndefined2(knownProperties[key]) && (!IsUndefined3(schema.properties[key]) || TypeSystemPolicy.IsExactOptionalProperty(knownProperties, key)))
        continue;
      knownProperties[key] = Visit12(schema.properties[key], references, `${path}/${key}`, knownProperties[key]);
    }
    if (!IsSchema(schema.additionalProperties)) {
      return knownProperties;
    }
    const unknownKeys = Object.getOwnPropertyNames(knownProperties);
    const additionalProperties = schema.additionalProperties;
    const properties = { ...knownProperties };
    for (const key of unknownKeys)
      if (!knownKeys.includes(key)) {
        properties[key] = Default4(additionalProperties, `${path}/${key}`, properties[key]);
      }
    return properties;
  }
  function FromRecord11(schema, references, path, value) {
    const defaulted = Default4(schema, path, value);
    if (!IsObject2(value))
      return defaulted;
    const pattern = Object.getOwnPropertyNames(schema.patternProperties)[0];
    const knownKeys = new RegExp(pattern);
    const knownProperties = { ...defaulted };
    for (const key of Object.getOwnPropertyNames(value))
      if (knownKeys.test(key)) {
        knownProperties[key] = Visit12(schema.patternProperties[pattern], references, `${path}/${key}`, knownProperties[key]);
      }
    if (!IsSchema(schema.additionalProperties)) {
      return knownProperties;
    }
    const unknownKeys = Object.getOwnPropertyNames(knownProperties);
    const additionalProperties = schema.additionalProperties;
    const properties = { ...knownProperties };
    for (const key of unknownKeys)
      if (!knownKeys.test(key)) {
        properties[key] = Default4(additionalProperties, `${path}/${key}`, properties[key]);
      }
    return properties;
  }
  function FromRef12(schema, references, path, value) {
    const target = Deref(schema, references);
    const resolved = Visit12(target, references, path, value);
    return Default4(schema, path, resolved);
  }
  function FromThis8(schema, references, path, value) {
    const target = Deref(schema, references);
    const resolved = Visit12(target, references, path, value);
    return Default4(schema, path, resolved);
  }
  function FromTuple13(schema, references, path, value) {
    const value1 = Default4(schema, path, value);
    return IsArray2(schema.items) ? schema.items.map((schema2, index) => Visit12(schema2, references, `${path}/${index}`, value1[index])) : [];
  }
  function FromUnion18(schema, references, path, value) {
    for (const subschema of schema.anyOf) {
      if (!Check(subschema, references, value))
        continue;
      const value1 = Visit12(subschema, references, path, value);
      return Default4(schema, path, value1);
    }
    for (const subschema of schema.anyOf) {
      const value1 = Visit12(subschema, references, path, value);
      if (!Check(schema, references, value1))
        continue;
      return Default4(schema, path, value1);
    }
    return Default4(schema, path, value);
  }
  function Visit12(schema, references, path, value) {
    const references_ = Pushref(schema, references);
    const schema_ = schema;
    switch (schema[Kind]) {
      case "Array":
        return FromArray15(schema_, references_, path, value);
      case "Import":
        return FromImport8(schema_, references_, path, value);
      case "Intersect":
        return FromIntersect16(schema_, references_, path, value);
      case "Not":
        return FromNot6(schema_, references_, path, value);
      case "Object":
        return FromObject16(schema_, references_, path, value);
      case "Record":
        return FromRecord11(schema_, references_, path, value);
      case "Ref":
        return FromRef12(schema_, references_, path, value);
      case "This":
        return FromThis8(schema_, references_, path, value);
      case "Tuple":
        return FromTuple13(schema_, references_, path, value);
      case "Union":
        return FromUnion18(schema_, references_, path, value);
      default:
        return Default4(schema_, path, value);
    }
  }
  function TransformEncode(schema, references, value) {
    return Visit12(schema, references, "", value);
  }

  // node_modules/@sinclair/typebox/build/esm/value/transform/has.mjs
  function FromArray16(schema, references) {
    return IsTransform(schema) || Visit13(schema.items, references);
  }
  function FromAsyncIterator7(schema, references) {
    return IsTransform(schema) || Visit13(schema.items, references);
  }
  function FromConstructor8(schema, references) {
    return IsTransform(schema) || Visit13(schema.returns, references) || schema.parameters.some((schema2) => Visit13(schema2, references));
  }
  function FromFunction7(schema, references) {
    return IsTransform(schema) || Visit13(schema.returns, references) || schema.parameters.some((schema2) => Visit13(schema2, references));
  }
  function FromIntersect17(schema, references) {
    return IsTransform(schema) || IsTransform(schema.unevaluatedProperties) || schema.allOf.some((schema2) => Visit13(schema2, references));
  }
  function FromImport9(schema, references) {
    const additional = globalThis.Object.getOwnPropertyNames(schema.$defs).reduce((result, key) => [...result, schema.$defs[key]], []);
    const target = schema.$defs[schema.$ref];
    return IsTransform(schema) || Visit13(target, [...additional, ...references]);
  }
  function FromIterator7(schema, references) {
    return IsTransform(schema) || Visit13(schema.items, references);
  }
  function FromNot7(schema, references) {
    return IsTransform(schema) || Visit13(schema.not, references);
  }
  function FromObject17(schema, references) {
    return IsTransform(schema) || Object.values(schema.properties).some((schema2) => Visit13(schema2, references)) || IsSchema(schema.additionalProperties) && Visit13(schema.additionalProperties, references);
  }
  function FromPromise7(schema, references) {
    return IsTransform(schema) || Visit13(schema.item, references);
  }
  function FromRecord12(schema, references) {
    const pattern = Object.getOwnPropertyNames(schema.patternProperties)[0];
    const property = schema.patternProperties[pattern];
    return IsTransform(schema) || Visit13(property, references) || IsSchema(schema.additionalProperties) && IsTransform(schema.additionalProperties);
  }
  function FromRef13(schema, references) {
    if (IsTransform(schema))
      return true;
    return Visit13(Deref(schema, references), references);
  }
  function FromThis9(schema, references) {
    if (IsTransform(schema))
      return true;
    return Visit13(Deref(schema, references), references);
  }
  function FromTuple14(schema, references) {
    return IsTransform(schema) || !IsUndefined2(schema.items) && schema.items.some((schema2) => Visit13(schema2, references));
  }
  function FromUnion19(schema, references) {
    return IsTransform(schema) || schema.anyOf.some((schema2) => Visit13(schema2, references));
  }
  function Visit13(schema, references) {
    const references_ = Pushref(schema, references);
    const schema_ = schema;
    if (schema.$id && visited.has(schema.$id))
      return false;
    if (schema.$id)
      visited.add(schema.$id);
    switch (schema[Kind]) {
      case "Array":
        return FromArray16(schema_, references_);
      case "AsyncIterator":
        return FromAsyncIterator7(schema_, references_);
      case "Constructor":
        return FromConstructor8(schema_, references_);
      case "Function":
        return FromFunction7(schema_, references_);
      case "Import":
        return FromImport9(schema_, references_);
      case "Intersect":
        return FromIntersect17(schema_, references_);
      case "Iterator":
        return FromIterator7(schema_, references_);
      case "Not":
        return FromNot7(schema_, references_);
      case "Object":
        return FromObject17(schema_, references_);
      case "Promise":
        return FromPromise7(schema_, references_);
      case "Record":
        return FromRecord12(schema_, references_);
      case "Ref":
        return FromRef13(schema_, references_);
      case "This":
        return FromThis9(schema_, references_);
      case "Tuple":
        return FromTuple14(schema_, references_);
      case "Union":
        return FromUnion19(schema_, references_);
      default:
        return IsTransform(schema);
    }
  }
  var visited = new Set;
  function HasTransform(schema, references) {
    visited.clear();
    return Visit13(schema, references);
  }

  // node_modules/@sinclair/typebox/build/esm/value/decode/decode.mjs
  function Decode(...args) {
    const [schema, references, value] = args.length === 3 ? [args[0], args[1], args[2]] : [args[0], [], args[1]];
    if (!Check(schema, references, value))
      throw new TransformDecodeCheckError(schema, value, Errors(schema, references, value).First());
    return HasTransform(schema, references) ? TransformDecode(schema, references, value) : value;
  }
  // node_modules/@sinclair/typebox/build/esm/value/default/default.mjs
  function ValueOrDefault(schema, value) {
    const defaultValue = HasPropertyKey2(schema, "default") ? schema.default : undefined;
    const clone = IsFunction2(defaultValue) ? defaultValue() : Clone2(defaultValue);
    return IsUndefined2(value) ? clone : IsObject2(value) && IsObject2(clone) ? Object.assign(clone, value) : value;
  }
  function HasDefaultProperty(schema) {
    return IsKind(schema) && "default" in schema;
  }
  function FromArray17(schema, references, value) {
    if (IsArray2(value)) {
      for (let i = 0;i < value.length; i++) {
        value[i] = Visit14(schema.items, references, value[i]);
      }
      return value;
    }
    const defaulted = ValueOrDefault(schema, value);
    if (!IsArray2(defaulted))
      return defaulted;
    for (let i = 0;i < defaulted.length; i++) {
      defaulted[i] = Visit14(schema.items, references, defaulted[i]);
    }
    return defaulted;
  }
  function FromDate7(schema, references, value) {
    return IsDate2(value) ? value : ValueOrDefault(schema, value);
  }
  function FromImport10(schema, references, value) {
    const definitions = globalThis.Object.values(schema.$defs);
    const target = schema.$defs[schema.$ref];
    return Visit14(target, [...references, ...definitions], value);
  }
  function FromIntersect18(schema, references, value) {
    const defaulted = ValueOrDefault(schema, value);
    return schema.allOf.reduce((acc, schema2) => {
      const next = Visit14(schema2, references, defaulted);
      return IsObject2(next) ? { ...acc, ...next } : next;
    }, {});
  }
  function FromObject18(schema, references, value) {
    const defaulted = ValueOrDefault(schema, value);
    if (!IsObject2(defaulted))
      return defaulted;
    const knownPropertyKeys = Object.getOwnPropertyNames(schema.properties);
    for (const key of knownPropertyKeys) {
      const propertyValue = Visit14(schema.properties[key], references, defaulted[key]);
      if (IsUndefined2(propertyValue))
        continue;
      defaulted[key] = Visit14(schema.properties[key], references, defaulted[key]);
    }
    if (!HasDefaultProperty(schema.additionalProperties))
      return defaulted;
    for (const key of Object.getOwnPropertyNames(defaulted)) {
      if (knownPropertyKeys.includes(key))
        continue;
      defaulted[key] = Visit14(schema.additionalProperties, references, defaulted[key]);
    }
    return defaulted;
  }
  function FromRecord13(schema, references, value) {
    const defaulted = ValueOrDefault(schema, value);
    if (!IsObject2(defaulted))
      return defaulted;
    const additionalPropertiesSchema = schema.additionalProperties;
    const [propertyKeyPattern, propertySchema] = Object.entries(schema.patternProperties)[0];
    const knownPropertyKey = new RegExp(propertyKeyPattern);
    for (const key of Object.getOwnPropertyNames(defaulted)) {
      if (!(knownPropertyKey.test(key) && HasDefaultProperty(propertySchema)))
        continue;
      defaulted[key] = Visit14(propertySchema, references, defaulted[key]);
    }
    if (!HasDefaultProperty(additionalPropertiesSchema))
      return defaulted;
    for (const key of Object.getOwnPropertyNames(defaulted)) {
      if (knownPropertyKey.test(key))
        continue;
      defaulted[key] = Visit14(additionalPropertiesSchema, references, defaulted[key]);
    }
    return defaulted;
  }
  function FromRef14(schema, references, value) {
    return Visit14(Deref(schema, references), references, ValueOrDefault(schema, value));
  }
  function FromThis10(schema, references, value) {
    return Visit14(Deref(schema, references), references, value);
  }
  function FromTuple15(schema, references, value) {
    const defaulted = ValueOrDefault(schema, value);
    if (!IsArray2(defaulted) || IsUndefined2(schema.items))
      return defaulted;
    const [items, max] = [schema.items, Math.max(schema.items.length, defaulted.length)];
    for (let i = 0;i < max; i++) {
      if (i < items.length)
        defaulted[i] = Visit14(items[i], references, defaulted[i]);
    }
    return defaulted;
  }
  function FromUnion20(schema, references, value) {
    const defaulted = ValueOrDefault(schema, value);
    for (const inner of schema.anyOf) {
      const result = Visit14(inner, references, Clone2(defaulted));
      if (Check(inner, references, result)) {
        return result;
      }
    }
    return defaulted;
  }
  function Visit14(schema, references, value) {
    const references_ = Pushref(schema, references);
    const schema_ = schema;
    switch (schema_[Kind]) {
      case "Array":
        return FromArray17(schema_, references_, value);
      case "Date":
        return FromDate7(schema_, references_, value);
      case "Import":
        return FromImport10(schema_, references_, value);
      case "Intersect":
        return FromIntersect18(schema_, references_, value);
      case "Object":
        return FromObject18(schema_, references_, value);
      case "Record":
        return FromRecord13(schema_, references_, value);
      case "Ref":
        return FromRef14(schema_, references_, value);
      case "This":
        return FromThis10(schema_, references_, value);
      case "Tuple":
        return FromTuple15(schema_, references_, value);
      case "Union":
        return FromUnion20(schema_, references_, value);
      default:
        return ValueOrDefault(schema_, value);
    }
  }
  function Default5(...args) {
    return args.length === 3 ? Visit14(args[0], args[1], args[2]) : Visit14(args[0], [], args[1]);
  }
  // node_modules/@sinclair/typebox/build/esm/value/pointer/pointer.mjs
  var exports_pointer = {};
  __export(exports_pointer, {
    ValuePointerRootSetError: () => ValuePointerRootSetError,
    ValuePointerRootDeleteError: () => ValuePointerRootDeleteError,
    Set: () => Set4,
    Has: () => Has3,
    Get: () => Get3,
    Format: () => Format,
    Delete: () => Delete3
  });
  class ValuePointerRootSetError extends TypeBoxError {
    constructor(value, path, update) {
      super("Cannot set root value");
      this.value = value;
      this.path = path;
      this.update = update;
    }
  }

  class ValuePointerRootDeleteError extends TypeBoxError {
    constructor(value, path) {
      super("Cannot delete root value");
      this.value = value;
      this.path = path;
    }
  }
  function Escape2(component) {
    return component.indexOf("~") === -1 ? component : component.replace(/~1/g, "/").replace(/~0/g, "~");
  }
  function* Format(pointer) {
    if (pointer === "")
      return;
    let [start, end] = [0, 0];
    for (let i = 0;i < pointer.length; i++) {
      const char = pointer.charAt(i);
      if (char === "/") {
        if (i === 0) {
          start = i + 1;
        } else {
          end = i;
          yield Escape2(pointer.slice(start, end));
          start = i + 1;
        }
      } else {
        end = i;
      }
    }
    yield Escape2(pointer.slice(start));
  }
  function Set4(value, pointer, update) {
    if (pointer === "")
      throw new ValuePointerRootSetError(value, pointer, update);
    let [owner, next, key] = [null, value, ""];
    for (const component of Format(pointer)) {
      if (next[component] === undefined)
        next[component] = {};
      owner = next;
      next = next[component];
      key = component;
    }
    owner[key] = update;
  }
  function Delete3(value, pointer) {
    if (pointer === "")
      throw new ValuePointerRootDeleteError(value, pointer);
    let [owner, next, key] = [null, value, ""];
    for (const component of Format(pointer)) {
      if (next[component] === undefined || next[component] === null)
        return;
      owner = next;
      next = next[component];
      key = component;
    }
    if (Array.isArray(owner)) {
      const index = parseInt(key);
      owner.splice(index, 1);
    } else {
      delete owner[key];
    }
  }
  function Has3(value, pointer) {
    if (pointer === "")
      return true;
    let [owner, next, key] = [null, value, ""];
    for (const component of Format(pointer)) {
      if (next[component] === undefined)
        return false;
      owner = next;
      next = next[component];
      key = component;
    }
    return Object.getOwnPropertyNames(owner).includes(key);
  }
  function Get3(value, pointer) {
    if (pointer === "")
      return value;
    let current = value;
    for (const component of Format(pointer)) {
      if (current[component] === undefined)
        return;
      current = current[component];
    }
    return current;
  }
  // node_modules/@sinclair/typebox/build/esm/value/equal/equal.mjs
  function ObjectType3(left, right) {
    if (!IsObject2(right))
      return false;
    const leftKeys = [...Object.keys(left), ...Object.getOwnPropertySymbols(left)];
    const rightKeys = [...Object.keys(right), ...Object.getOwnPropertySymbols(right)];
    if (leftKeys.length !== rightKeys.length)
      return false;
    return leftKeys.every((key) => Equal(left[key], right[key]));
  }
  function DateType3(left, right) {
    return IsDate2(right) && left.getTime() === right.getTime();
  }
  function ArrayType3(left, right) {
    if (!IsArray2(right) || left.length !== right.length)
      return false;
    return left.every((value, index) => Equal(value, right[index]));
  }
  function TypedArrayType(left, right) {
    if (!IsTypedArray(right) || left.length !== right.length || Object.getPrototypeOf(left).constructor.name !== Object.getPrototypeOf(right).constructor.name)
      return false;
    return left.every((value, index) => Equal(value, right[index]));
  }
  function ValueType(left, right) {
    return left === right;
  }
  function Equal(left, right) {
    if (IsDate2(left))
      return DateType3(left, right);
    if (IsTypedArray(left))
      return TypedArrayType(left, right);
    if (IsArray2(left))
      return ArrayType3(left, right);
    if (IsObject2(left))
      return ObjectType3(left, right);
    if (IsValueType(left))
      return ValueType(left, right);
    throw new Error("ValueEquals: Unable to compare value");
  }

  // node_modules/@sinclair/typebox/build/esm/value/delta/delta.mjs
  var Insert = Object2({
    type: Literal("insert"),
    path: String2(),
    value: Unknown()
  });
  var Update = Object2({
    type: Literal("update"),
    path: String2(),
    value: Unknown()
  });
  var Delete4 = Object2({
    type: Literal("delete"),
    path: String2()
  });
  var Edit = Union([Insert, Update, Delete4]);

  class ValueDiffError extends TypeBoxError {
    constructor(value, message) {
      super(message);
      this.value = value;
    }
  }
  function CreateUpdate(path, value) {
    return { type: "update", path, value };
  }
  function CreateInsert(path, value) {
    return { type: "insert", path, value };
  }
  function CreateDelete(path) {
    return { type: "delete", path };
  }
  function AssertDiffable(value) {
    if (globalThis.Object.getOwnPropertySymbols(value).length > 0)
      throw new ValueDiffError(value, "Cannot diff objects with symbols");
  }
  function* ObjectType4(path, current, next) {
    AssertDiffable(current);
    AssertDiffable(next);
    if (!IsStandardObject(next))
      return yield CreateUpdate(path, next);
    const currentKeys = globalThis.Object.getOwnPropertyNames(current);
    const nextKeys = globalThis.Object.getOwnPropertyNames(next);
    for (const key of nextKeys) {
      if (HasPropertyKey2(current, key))
        continue;
      yield CreateInsert(`${path}/${key}`, next[key]);
    }
    for (const key of currentKeys) {
      if (!HasPropertyKey2(next, key))
        continue;
      if (Equal(current, next))
        continue;
      yield* Visit15(`${path}/${key}`, current[key], next[key]);
    }
    for (const key of currentKeys) {
      if (HasPropertyKey2(next, key))
        continue;
      yield CreateDelete(`${path}/${key}`);
    }
  }
  function* ArrayType4(path, current, next) {
    if (!IsArray2(next))
      return yield CreateUpdate(path, next);
    for (let i = 0;i < Math.min(current.length, next.length); i++) {
      yield* Visit15(`${path}/${i}`, current[i], next[i]);
    }
    for (let i = 0;i < next.length; i++) {
      if (i < current.length)
        continue;
      yield CreateInsert(`${path}/${i}`, next[i]);
    }
    for (let i = current.length - 1;i >= 0; i--) {
      if (i < next.length)
        continue;
      yield CreateDelete(`${path}/${i}`);
    }
  }
  function* TypedArrayType2(path, current, next) {
    if (!IsTypedArray(next) || current.length !== next.length || globalThis.Object.getPrototypeOf(current).constructor.name !== globalThis.Object.getPrototypeOf(next).constructor.name)
      return yield CreateUpdate(path, next);
    for (let i = 0;i < Math.min(current.length, next.length); i++) {
      yield* Visit15(`${path}/${i}`, current[i], next[i]);
    }
  }
  function* ValueType2(path, current, next) {
    if (current === next)
      return;
    yield CreateUpdate(path, next);
  }
  function* Visit15(path, current, next) {
    if (IsStandardObject(current))
      return yield* ObjectType4(path, current, next);
    if (IsArray2(current))
      return yield* ArrayType4(path, current, next);
    if (IsTypedArray(current))
      return yield* TypedArrayType2(path, current, next);
    if (IsValueType(current))
      return yield* ValueType2(path, current, next);
    throw new ValueDiffError(current, "Unable to diff value");
  }
  function Diff(current, next) {
    return [...Visit15("", current, next)];
  }
  function IsRootUpdate(edits) {
    return edits.length > 0 && edits[0].path === "" && edits[0].type === "update";
  }
  function IsIdentity(edits) {
    return edits.length === 0;
  }
  function Patch(current, edits) {
    if (IsRootUpdate(edits)) {
      return Clone2(edits[0].value);
    }
    if (IsIdentity(edits)) {
      return Clone2(current);
    }
    const clone = Clone2(current);
    for (const edit of edits) {
      switch (edit.type) {
        case "insert": {
          exports_pointer.Set(clone, edit.path, edit.value);
          break;
        }
        case "update": {
          exports_pointer.Set(clone, edit.path, edit.value);
          break;
        }
        case "delete": {
          exports_pointer.Delete(clone, edit.path);
          break;
        }
      }
    }
    return clone;
  }
  // node_modules/@sinclair/typebox/build/esm/value/encode/encode.mjs
  function Encode(...args) {
    const [schema, references, value] = args.length === 3 ? [args[0], args[1], args[2]] : [args[0], [], args[1]];
    const encoded = HasTransform(schema, references) ? TransformEncode(schema, references, value) : value;
    if (!Check(schema, references, encoded))
      throw new TransformEncodeCheckError(schema, encoded, Errors(schema, references, encoded).First());
    return encoded;
  }
  // node_modules/@sinclair/typebox/build/esm/value/mutate/mutate.mjs
  function IsStandardObject2(value) {
    return IsObject2(value) && !IsArray2(value);
  }

  class ValueMutateError extends TypeBoxError {
    constructor(message) {
      super(message);
    }
  }
  function ObjectType5(root, path, current, next) {
    if (!IsStandardObject2(current)) {
      exports_pointer.Set(root, path, Clone2(next));
    } else {
      const currentKeys = Object.getOwnPropertyNames(current);
      const nextKeys = Object.getOwnPropertyNames(next);
      for (const currentKey of currentKeys) {
        if (!nextKeys.includes(currentKey)) {
          delete current[currentKey];
        }
      }
      for (const nextKey of nextKeys) {
        if (!currentKeys.includes(nextKey)) {
          current[nextKey] = null;
        }
      }
      for (const nextKey of nextKeys) {
        Visit16(root, `${path}/${nextKey}`, current[nextKey], next[nextKey]);
      }
    }
  }
  function ArrayType5(root, path, current, next) {
    if (!IsArray2(current)) {
      exports_pointer.Set(root, path, Clone2(next));
    } else {
      for (let index = 0;index < next.length; index++) {
        Visit16(root, `${path}/${index}`, current[index], next[index]);
      }
      current.splice(next.length);
    }
  }
  function TypedArrayType3(root, path, current, next) {
    if (IsTypedArray(current) && current.length === next.length) {
      for (let i = 0;i < current.length; i++) {
        current[i] = next[i];
      }
    } else {
      exports_pointer.Set(root, path, Clone2(next));
    }
  }
  function ValueType3(root, path, current, next) {
    if (current === next)
      return;
    exports_pointer.Set(root, path, next);
  }
  function Visit16(root, path, current, next) {
    if (IsArray2(next))
      return ArrayType5(root, path, current, next);
    if (IsTypedArray(next))
      return TypedArrayType3(root, path, current, next);
    if (IsStandardObject2(next))
      return ObjectType5(root, path, current, next);
    if (IsValueType(next))
      return ValueType3(root, path, current, next);
  }
  function IsNonMutableValue(value) {
    return IsTypedArray(value) || IsValueType(value);
  }
  function IsMismatchedValue(current, next) {
    return IsStandardObject2(current) && IsArray2(next) || IsArray2(current) && IsStandardObject2(next);
  }
  function Mutate(current, next) {
    if (IsNonMutableValue(current) || IsNonMutableValue(next))
      throw new ValueMutateError("Only object and array types can be mutated at the root level");
    if (IsMismatchedValue(current, next))
      throw new ValueMutateError("Cannot assign due type mismatch of assignable values");
    Visit16(current, "", current, next);
  }
  // node_modules/@sinclair/typebox/build/esm/value/parse/parse.mjs
  class ParseError extends TypeBoxError {
    constructor(message) {
      super(message);
    }
  }
  var ParseRegistry;
  (function(ParseRegistry2) {
    const registry = new Map([
      ["Assert", (type, references, value) => {
        Assert(type, references, value);
        return value;
      }],
      ["Cast", (type, references, value) => Cast(type, references, value)],
      ["Clean", (type, references, value) => Clean(type, references, value)],
      ["Clone", (_type, _references, value) => Clone2(value)],
      ["Convert", (type, references, value) => Convert(type, references, value)],
      ["Decode", (type, references, value) => HasTransform(type, references) ? TransformDecode(type, references, value) : value],
      ["Default", (type, references, value) => Default5(type, references, value)],
      ["Encode", (type, references, value) => HasTransform(type, references) ? TransformEncode(type, references, value) : value]
    ]);
    function Delete5(key) {
      registry.delete(key);
    }
    ParseRegistry2.Delete = Delete5;
    function Set5(key, callback) {
      registry.set(key, callback);
    }
    ParseRegistry2.Set = Set5;
    function Get4(key) {
      return registry.get(key);
    }
    ParseRegistry2.Get = Get4;
  })(ParseRegistry || (ParseRegistry = {}));
  var ParseDefault = [
    "Clone",
    "Clean",
    "Default",
    "Convert",
    "Assert",
    "Decode"
  ];
  function ParseValue(operations, type, references, value) {
    return operations.reduce((value2, operationKey) => {
      const operation = ParseRegistry.Get(operationKey);
      if (IsUndefined2(operation))
        throw new ParseError(`Unable to find Parse operation '${operationKey}'`);
      return operation(type, references, value2);
    }, value);
  }
  function Parse(...args) {
    const [operations, schema, references, value] = args.length === 4 ? [args[0], args[1], args[2], args[3]] : args.length === 3 ? IsArray2(args[0]) ? [args[0], args[1], [], args[2]] : [ParseDefault, args[0], args[1], args[2]] : args.length === 2 ? [ParseDefault, args[0], [], args[1]] : (() => {
      throw new ParseError("Invalid Arguments");
    })();
    return ParseValue(operations, schema, references, value);
  }
  // node_modules/@sinclair/typebox/build/esm/value/value/value.mjs
  var exports_value2 = {};
  __export(exports_value2, {
    ValueErrorIterator: () => ValueErrorIterator,
    Patch: () => Patch,
    Parse: () => Parse,
    Mutate: () => Mutate,
    Hash: () => Hash,
    Errors: () => Errors,
    Equal: () => Equal,
    Encode: () => Encode,
    Edit: () => Edit,
    Diff: () => Diff,
    Default: () => Default5,
    Decode: () => Decode,
    Create: () => Create2,
    Convert: () => Convert,
    Clone: () => Clone2,
    Clean: () => Clean,
    Check: () => Check,
    Cast: () => Cast,
    Assert: () => Assert
  });
  // examples/plugins/seo-suite/server/sitemap.ts
  var SeoEntryRowSchema = Type.Object({
    "page-id": Type.String(),
    "no-index": Type.Optional(Type.Union([Type.Boolean(), Type.String()])),
    "canonical-url": Type.Optional(Type.String())
  });
  function escapeXml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
  }
  function toDateString(iso) {
    if (!iso)
      return new Date().toISOString().slice(0, 10);
    const d = new Date(iso);
    if (isNaN(d.getTime()))
      return new Date().toISOString().slice(0, 10);
    return d.toISOString().slice(0, 10);
  }
  function isTruthy(value) {
    if (typeof value === "boolean")
      return value;
    if (typeof value === "string")
      return value === "true" || value === "1";
    return false;
  }
  function registerSitemapRoutes(api) {
    api.cms.routes.public.get("/sitemap.xml", async () => {
      try {
        const siteUrl = (api.cms.settings.get("siteUrl") ?? "").replace(/\/$/, "");
        const [pageList, { records: seoEntryRecords }] = await Promise.all([
          api.cms.content.table("pages").list({ status: "published" }),
          api.cms.storage.collection("seo-entries").list()
        ]);
        const pages = pageList.entries;
        const noIndexByPageId = new Map;
        const canonicalByPageId = new Map;
        for (const record of seoEntryRecords) {
          if (!exports_value2.Check(SeoEntryRowSchema, record.data))
            continue;
          const entry = record.data;
          noIndexByPageId.set(entry["page-id"], isTruthy(entry["no-index"]));
          if (entry["canonical-url"])
            canonicalByPageId.set(entry["page-id"], entry["canonical-url"]);
        }
        const urlEntries = [];
        for (const page of pages) {
          if (noIndexByPageId.get(page.id))
            continue;
          const canonicalOverride = canonicalByPageId.get(page.id);
          const loc = canonicalOverride || (siteUrl ? `${siteUrl}/${page.slug.replace(/^\//, "")}` : "");
          if (!loc)
            continue;
          const lastmod = toDateString(page.publishedAt ?? page.updatedAt);
          urlEntries.push(`  <url>
` + `    <loc>${escapeXml(loc)}</loc>
` + `    <lastmod>${escapeXml(lastmod)}</lastmod>
` + `    <changefreq>weekly</changefreq>
` + `    <priority>0.5</priority>
` + `  </url>`);
        }
        const xml = `<?xml version="1.0" encoding="UTF-8"?>
` + `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
` + urlEntries.join(`
`) + (urlEntries.length > 0 ? `
` : "") + `</urlset>`;
        return {
          __response: true,
          status: 200,
          headers: { "content-type": "application/xml; charset=utf-8" },
          body: xml
        };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        api.plugin.log("[seo-suite] sitemap.xml generation failed:", message);
        return {
          __response: true,
          status: 500,
          headers: { "content-type": "text/plain; charset=utf-8" },
          body: "Sitemap generation failed."
        };
      }
    });
    api.cms.routes.public.get("/robots.txt", () => {
      try {
        const siteUrl = (api.cms.settings.get("siteUrl") ?? "").replace(/\/$/, "");
        const operatorContent = api.cms.settings.get("robotsTxt") ?? `User-agent: *
Allow: /`;
        const sitemapLine = siteUrl ? `Sitemap: ${siteUrl}/sitemap.xml` : `# Sitemap: <configure siteUrl in SEO Suite settings>`;
        const body = `${operatorContent.trimEnd()}
${sitemapLine}
`;
        return {
          __response: true,
          status: 200,
          headers: { "content-type": "text/plain; charset=utf-8" },
          body
        };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        api.plugin.log("[seo-suite] robots.txt generation failed:", message);
        return {
          __response: true,
          status: 500,
          headers: { "content-type": "text/plain; charset=utf-8" },
          body: "robots.txt generation failed."
        };
      }
    });
  }

  // examples/plugins/seo-suite/server/headInjection.ts
  var SeoEntrySchema = Type.Object({
    "page-id": Type.String(),
    "title-override": Type.Optional(Type.String()),
    "meta-description": Type.Optional(Type.String()),
    "og-title": Type.Optional(Type.String()),
    "og-description": Type.Optional(Type.String()),
    "og-image-url": Type.Optional(Type.String()),
    "twitter-card": Type.Optional(Type.String()),
    "canonical-url": Type.Optional(Type.String()),
    "no-index": Type.Optional(Type.Union([Type.Boolean(), Type.String()])),
    "no-follow": Type.Optional(Type.Union([Type.Boolean(), Type.String()])),
    "json-ld": Type.Optional(Type.String())
  });
  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function isTruthy2(value) {
    if (typeof value === "boolean")
      return value;
    if (typeof value === "string")
      return value === "true" || value === "1";
    return false;
  }
  function extractTitle(html) {
    const m = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html);
    if (!m || !m[1])
      return null;
    return m[1].replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").trim();
  }
  function extractCanonical(html) {
    const m = /<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i.exec(html) ?? /<link[^>]+href=["']([^"']+)["'][^>]+rel=["']canonical["']/i.exec(html);
    return m?.[1] ?? null;
  }
  function escapeJsonLd(json) {
    return json.replace(/<\//g, "<\\/");
  }
  function meta(name, value, prop) {
    const attr = prop ? "property" : "name";
    return `<meta ${attr}="${escapeAttr(name)}" content="${escapeAttr(value)}">`;
  }
  var seoEntriesCache = null;
  function registerHeadInjection(api) {
    const seoEntries = api.cms.storage.collection("seo-entries");
    const pageIndex = api.cms.storage.collection("page-index");
    api.cms.hooks.on("content.entry.created", (evt) => {
      if (evt.tableSlug === "seo-entries") {
        seoEntriesCache = null;
      }
    });
    api.cms.hooks.on("content.entry.updated", (evt) => {
      if (evt.tableSlug === "seo-entries") {
        seoEntriesCache = null;
      }
    });
    api.cms.hooks.on("content.entry.deleted", (evt) => {
      if (evt.tableSlug === "seo-entries") {
        seoEntriesCache = null;
      }
    });
    api.cms.hooks.filter("publish.html", async (html, { pageId, slug }) => {
      if (typeof html !== "string")
        return html;
      try {
        if (seoEntriesCache === null) {
          const { records } = await seoEntries.list();
          seoEntriesCache = records;
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        api.plugin.log("[seo-suite] Failed to load seo-entries cache:", message);
        return html;
      }
      let entry;
      for (const record of seoEntriesCache) {
        if (!exports_value2.Check(SeoEntrySchema, record.data))
          continue;
        const candidate = record.data;
        if (candidate["page-id"] === pageId) {
          entry = candidate;
          break;
        }
      }
      const siteUrl = (api.cms.settings.get("siteUrl") ?? "").replace(/\/$/, "");
      const siteName = api.cms.settings.get("siteName") ?? "";
      const defaultOgImage = api.cms.settings.get("defaultOgImage") ?? "";
      const twitterHandle = api.cms.settings.get("twitterHandle") ?? "";
      const enableJsonLd = api.cms.settings.get("enableJsonLd") ?? true;
      const defaultNoIndex = api.cms.settings.get("defaultNoIndex") ?? false;
      const htmlTitle = extractTitle(html);
      const htmlCanonical = extractCanonical(html);
      const noIndex = entry ? isTruthy2(entry["no-index"]) : defaultNoIndex;
      const noFollow = entry ? isTruthy2(entry["no-follow"]) : false;
      const canonicalUrl = entry?.["canonical-url"] || htmlCanonical || "";
      const pageTitle = entry?.["title-override"] || htmlTitle || "";
      const metaDescription = entry?.["meta-description"] ?? "";
      const ogTitle = entry?.["og-title"] || pageTitle;
      const ogDescription = entry?.["og-description"] || metaDescription;
      const ogImageUrl = entry?.["og-image-url"] || defaultOgImage;
      const twitterCard = entry?.["twitter-card"] || "summary_large_image";
      const customJsonLd = entry?.["json-ld"] ?? "";
      const tags = [];
      if (noIndex || noFollow) {
        const robotsContent = [noIndex ? "noindex" : "", noFollow ? "nofollow" : ""].filter(Boolean).join(", ");
        tags.push(meta("robots", robotsContent));
      }
      if (canonicalUrl && !htmlCanonical) {
        tags.push(`<link rel="canonical" href="${escapeAttr(canonicalUrl)}">`);
      }
      if (metaDescription) {
        tags.push(meta("description", metaDescription));
      }
      if (ogTitle)
        tags.push(meta("og:title", ogTitle, true));
      if (ogDescription)
        tags.push(meta("og:description", ogDescription, true));
      if (ogImageUrl)
        tags.push(meta("og:image", ogImageUrl, true));
      if (siteName)
        tags.push(meta("og:site_name", siteName, true));
      if (canonicalUrl)
        tags.push(meta("og:url", canonicalUrl, true));
      tags.push(meta("og:type", "website", true));
      tags.push(meta("twitter:card", twitterCard));
      if (ogTitle)
        tags.push(meta("twitter:title", ogTitle));
      if (ogDescription)
        tags.push(meta("twitter:description", ogDescription));
      if (ogImageUrl)
        tags.push(meta("twitter:image", ogImageUrl));
      if (twitterHandle)
        tags.push(meta("twitter:site", twitterHandle));
      if (customJsonLd) {
        tags.push(`<script type="application/ld+json">${escapeJsonLd(customJsonLd)}</script>`);
      } else if (enableJsonLd) {
        const webPageSchema = {
          "@context": "https://schema.org",
          "@type": "WebPage",
          name: pageTitle || siteName,
          ...canonicalUrl ? { url: canonicalUrl } : {},
          ...metaDescription ? { description: metaDescription } : {}
        };
        const webSiteSchema = {
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: siteName || pageTitle,
          ...siteUrl ? { url: siteUrl } : {}
        };
        const schemaArray = [webPageSchema, webSiteSchema];
        tags.push(`<script type="application/ld+json">${escapeJsonLd(JSON.stringify(schemaArray))}</script>`);
      }
      if (tags.length > 0) {
        const injection = `
` + tags.map((t) => `  ${t}`).join(`
`) + `
`;
        const headCloseIndex = html.indexOf("</head>");
        if (headCloseIndex === -1) {
          return html;
        }
        html = html.slice(0, headCloseIndex) + injection + html.slice(headCloseIndex);
      }
      try {
        const pageUrl = canonicalUrl || (siteUrl ? `${siteUrl}/${slug.replace(/^\//, "")}` : "");
        const now = new Date().toISOString();
        const { records: existingPageRecords } = await pageIndex.list({ filter: { "page-id": pageId } });
        const existingRecord = existingPageRecords[0];
        const indexData = {
          "page-id": pageId,
          slug,
          url: pageUrl,
          title: pageTitle,
          "last-seen-at": now
        };
        if (existingRecord) {
          await pageIndex.update(existingRecord.id, indexData);
        } else {
          await pageIndex.create(indexData);
        }
        if (entry && seoEntriesCache !== null) {
          const seoRecord = seoEntriesCache.find((r) => exports_value2.Check(SeoEntrySchema, r.data) && r.data["page-id"] === pageId);
          if (seoRecord) {
            await seoEntries.update(seoRecord.id, {
              ...seoRecord.data,
              "last-rendered-url": pageUrl,
              "last-rendered-title": pageTitle,
              "last-rendered-at": now
            });
            seoEntriesCache = null;
          }
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        api.plugin.log("[seo-suite] page-index upsert failed:", message);
      }
      return html;
    });
  }

  // examples/plugins/seo-suite/server/ogImage.ts
  var OgImageProviderResponseSchema = Type.Object({
    url: Type.String({ minLength: 1 })
  });
  var SeoEntrySchema2 = Type.Object({
    "page-id": Type.String(),
    "og-image-url": Type.Optional(Type.String()),
    "last-rendered-title": Type.Optional(Type.String()),
    "last-rendered-url": Type.Optional(Type.String()),
    "meta-description": Type.Optional(Type.String())
  });
  function sleep(ms) {
    return new Promise((resolve) => {
      if (typeof setTimeout !== "undefined") {
        setTimeout(resolve, ms);
      } else {
        resolve();
      }
    });
  }
  function registerOgImageJob(api) {
    api.cms.schedule.register({
      id: "og-image-daily",
      cadence: { interval: "daily", at: "02:30" },
      maxDurationMs: 60000,
      overlap: "skip",
      handler: async () => {
        const providerUrl = api.cms.settings.get("ogImageProviderUrl") ?? "";
        if (!providerUrl) {
          api.plugin.log("[seo-suite] OG image provider not configured — skipping.");
          return;
        }
        const siteName = api.cms.settings.get("siteName") ?? "";
        let allRecords;
        try {
          const { records } = await api.cms.storage.collection("seo-entries").list();
          allRecords = records;
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          api.plugin.log("[seo-suite] og-image-daily: failed to list seo-entries:", message);
          return;
        }
        const candidates = [];
        for (const record of allRecords) {
          if (!exports_value2.Check(SeoEntrySchema2, record.data))
            continue;
          const entry = record.data;
          const hasTitle = Boolean(entry["last-rendered-title"]);
          const hasImage = Boolean(entry["og-image-url"]);
          if (hasTitle && !hasImage) {
            candidates.push({ recordId: record.id, entry, data: record.data });
          }
        }
        if (candidates.length === 0) {
          api.plugin.log("[seo-suite] og-image-daily: no candidates need an OG image.");
          return;
        }
        api.plugin.log(`[seo-suite] og-image-daily: generating OG images for ${candidates.length} page(s).`);
        const seoEntriesCollection = api.cms.storage.collection("seo-entries");
        for (const { recordId, entry, data } of candidates) {
          const title = entry["last-rendered-title"] ?? "";
          const description = entry["meta-description"] ?? "";
          const url = entry["last-rendered-url"] ?? "";
          try {
            const response = await fetch(providerUrl, {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ title, description, siteName, url }),
              signal: AbortSignal.timeout(15000)
            });
            if (!response.ok) {
              api.plugin.log(`[seo-suite] og-image render failed for page ${entry["page-id"]}: HTTP ${response.status}`);
              continue;
            }
            let responseBody;
            try {
              responseBody = await response.json();
            } catch {
              api.plugin.log(`[seo-suite] og-image render failed for page ${entry["page-id"]}: invalid JSON response`);
              continue;
            }
            if (!exports_value2.Check(OgImageProviderResponseSchema, responseBody)) {
              api.plugin.log(`[seo-suite] og-image render failed for page ${entry["page-id"]}: response missing "url" field`);
              continue;
            }
            const imageUrl = responseBody.url;
            await seoEntriesCollection.update(recordId, {
              ...data,
              "og-image-url": imageUrl
            });
            api.plugin.log(`[seo-suite] og-image-daily: set OG image for page ${entry["page-id"]}: ${imageUrl}`);
          } catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            api.plugin.log(`[seo-suite] og-image render failed for page ${entry["page-id"]}:`, message);
          }
          await sleep(500);
        }
        api.plugin.log("[seo-suite] og-image-daily: done.");
      }
    });
  }

  // examples/plugins/seo-suite/server/seoEntriesRoutes.ts
  function registerSeoEntriesRoutes(api) {
    const seoEntries = api.cms.storage.collection("seo-entries");
    api.cms.routes.get("/seo-entries", "plugins.read", async () => {
      try {
        const { records: all } = await seoEntries.list();
        return { ok: true, entries: all };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        api.plugin.log("[seo-suite] GET /seo-entries failed:", message);
        return { ok: false, error: message };
      }
    });
    api.cms.routes.post("/seo-entries", "plugins.configure", async (ctx) => {
      try {
        const body = ctx.body;
        const pageId = typeof body["page-id"] === "string" ? body["page-id"] : null;
        if (!pageId) {
          return { ok: false, error: "Missing required field: page-id" };
        }
        const { records } = await seoEntries.list({ filter: { "page-id": pageId } });
        const existing = records[0];
        const systemFields = existing ? {
          "last-rendered-url": existing.data["last-rendered-url"],
          "last-rendered-title": existing.data["last-rendered-title"],
          "last-rendered-at": existing.data["last-rendered-at"]
        } : {};
        const data = {
          "page-id": pageId,
          "title-override": typeof body["title-override"] === "string" ? body["title-override"] : "",
          "meta-description": typeof body["meta-description"] === "string" ? body["meta-description"] : "",
          "og-title": typeof body["og-title"] === "string" ? body["og-title"] : "",
          "og-description": typeof body["og-description"] === "string" ? body["og-description"] : "",
          "og-image-url": typeof body["og-image-url"] === "string" ? body["og-image-url"] : "",
          "twitter-card": typeof body["twitter-card"] === "string" ? body["twitter-card"] : "summary_large_image",
          "canonical-url": typeof body["canonical-url"] === "string" ? body["canonical-url"] : "",
          "no-index": typeof body["no-index"] === "boolean" ? body["no-index"] : false,
          "no-follow": typeof body["no-follow"] === "boolean" ? body["no-follow"] : false,
          "json-ld": typeof body["json-ld"] === "string" ? body["json-ld"] : "",
          ...systemFields
        };
        let record;
        if (existing) {
          record = await seoEntries.update(existing.id, data);
        } else {
          record = await seoEntries.create(data);
        }
        return { ok: true, entry: record };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        api.plugin.log("[seo-suite] POST /seo-entries failed:", message);
        return { ok: false, error: message };
      }
    });
    api.cms.routes.get("/page-index", "plugins.read", async () => {
      try {
        const { records: all } = await api.cms.storage.collection("page-index").list();
        return { ok: true, pages: all };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        api.plugin.log("[seo-suite] GET /page-index failed:", message);
        return { ok: false, error: message };
      }
    });
  }

  // examples/plugins/seo-suite/server/index.ts
  var mod = {
    install(api) {
      api.plugin.log("SEO Suite installed.");
    },
    activate(api) {
      registerSitemapRoutes(api);
      registerHeadInjection(api);
      registerOgImageJob(api);
      registerSeoEntriesRoutes(api);
      api.plugin.log("SEO Suite activated.");
    },
    deactivate(api) {
      api.plugin.log("SEO Suite deactivated.");
    },
    uninstall(api) {
      api.plugin.log("SEO Suite uninstalled.");
    }
  };
  var server_default = mod;

  // examples/plugins/seo-suite/server/__sandbox-facade-1780384777907.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
