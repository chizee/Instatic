(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // examples/plugins/forms-builder/server/email.ts
  var exports_email = {};
  __export(exports_email, {
    sendSubmissionEmail: () => sendSubmissionEmail
  });
  function buildSubject(template, formName) {
    return template.replace(/\{\{form_name\}\}/g, formName);
  }
  function buildPlainText(data) {
    const lines = [
      `Form: ${data.formName} (${data.formId})`,
      `Page: ${data.pagePath}`,
      `Submitted: ${data.submittedAt}`,
      "",
      "Fields:"
    ];
    for (const [key, value] of Object.entries(data.fields)) {
      lines.push(`  ${key}: ${String(value ?? "")}`);
    }
    return lines.join(`
`);
  }
  function buildHtml(data) {
    const rows = Object.entries(data.fields).map(([k, v]) => `<tr><td style="padding:4px 8px;font-weight:500;">${k}</td><td style="padding:4px 8px;">${String(v ?? "")}</td></tr>`).join("");
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;color:#222;max-width:600px;">
<h2 style="margin-bottom:4px;">New submission: ${data.formName}</h2>
<p style="margin:0 0 16px;color:#666;font-size:0.875rem;">Page: ${data.pagePath} — ${data.submittedAt}</p>
<table style="border-collapse:collapse;width:100%;">
  <tbody>${rows}</tbody>
</table>
</body></html>`;
  }
  async function sendResend(settings, subject, text, htmlBody) {
    return fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${settings.apiKey}`
      },
      body: JSON.stringify({
        from: settings.fromAddress,
        to: [settings.defaultToAddress],
        subject,
        text,
        html: htmlBody
      }),
      signal: AbortSignal.timeout(1e4)
    });
  }
  async function sendPostmark(settings, subject, text, htmlBody) {
    return fetch("https://api.postmarkapp.com/email", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "X-Postmark-Server-Token": settings.apiKey
      },
      body: JSON.stringify({
        From: settings.fromAddress,
        To: settings.defaultToAddress,
        Subject: subject,
        TextBody: text,
        HtmlBody: htmlBody
      }),
      signal: AbortSignal.timeout(1e4)
    });
  }
  async function sendMailgun(settings, subject, text, htmlBody) {
    const domain = settings.mailgunDomain ?? "";
    const body = new URLSearchParams({
      from: settings.fromAddress,
      to: settings.defaultToAddress,
      subject,
      text,
      html: htmlBody
    });
    const credentials = btoa(`api:${settings.apiKey}`);
    return fetch(`https://api.mailgun.net/v3/${encodeURIComponent(domain)}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Basic ${credentials}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: body.toString(),
      signal: AbortSignal.timeout(1e4)
    });
  }
  async function dispatch(settings, subject, text, htmlBody) {
    switch (settings.provider) {
      case "resend":
        return sendResend(settings, subject, text, htmlBody);
      case "postmark":
        return sendPostmark(settings, subject, text, htmlBody);
      case "mailgun":
        return sendMailgun(settings, subject, text, htmlBody);
      default:
        throw new Error(`[plugin:instatic.forms] Unknown email provider: ${String(settings.provider)}`);
    }
  }
  async function sendSubmissionEmail(data, settings) {
    if (!settings.apiKey || !settings.fromAddress || !settings.defaultToAddress) {
      return;
    }
    const subject = buildSubject(settings.subjectTemplate, data.formName);
    const text = buildPlainText(data);
    const htmlBody = buildHtml(data);
    let res;
    try {
      res = await dispatch(settings, subject, text, htmlBody);
    } catch (err) {
      throw new Error(`[plugin:instatic.forms] Email send failed (${settings.provider}): ${err instanceof Error ? err.message : String(err)}`, { cause: err });
    }
    if (!res.ok && res.status >= 500) {
      await new Promise((resolve) => setTimeout(resolve, 300));
      let retryRes;
      try {
        retryRes = await dispatch(settings, subject, text, htmlBody);
      } catch (err) {
        throw new Error(`[plugin:instatic.forms] Email retry failed (${settings.provider}): ${err instanceof Error ? err.message : String(err)}`, { cause: err });
      }
      if (!retryRes.ok) {
        throw new Error(`[plugin:instatic.forms] Email delivery failed after retry (${settings.provider}): HTTP ${retryRes.status}`);
      }
    } else if (!res.ok) {
      throw new Error(`[plugin:instatic.forms] Email rejected by ${settings.provider}: HTTP ${res.status}`);
    }
  }

  // examples/plugins/forms-builder/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    default: () => server_default
  });
  // examples/plugins/forms-builder/server/spam.ts
  function honeypotFailed(body) {
    for (const key of Object.keys(body)) {
      if (key.startsWith("_hp_")) {
        const val = body[key];
        if (val !== "" && val !== null && val !== undefined)
          return true;
      }
    }
    return false;
  }
  var _windows = new Map;
  var WINDOW_MS = 60000;
  function consume(ipHash, limit) {
    const now = Date.now();
    const cutoff = now - WINDOW_MS;
    const timestamps = (_windows.get(ipHash) ?? []).filter((t) => t > cutoff);
    if (timestamps.length >= limit)
      return false;
    timestamps.push(now);
    _windows.set(ipHash, timestamps);
    return true;
  }
  var TURNSTILE_VERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify";
  async function verifyTurnstile(token, secret) {
    try {
      const res = await fetch(TURNSTILE_VERIFY_URL, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `secret=${encodeURIComponent(secret)}&response=${encodeURIComponent(token)}`,
        signal: AbortSignal.timeout(5000)
      });
      if (!res.ok)
        return false;
      const data = await res.json();
      return data.success === true;
    } catch (_err) {
      return false;
    }
  }

  // examples/plugins/forms-builder/server/submit.ts
  var CONTROL_FIELDS = new Set(["_form_id", "cf-turnstile-response"]);
  var HP_PREFIX = "_hp_";
  function stripControlFields(body) {
    const out = {};
    for (const [key, value] of Object.entries(body)) {
      if (CONTROL_FIELDS.has(key) || key.startsWith(HP_PREFIX))
        continue;
      out[key] = value;
    }
    return out;
  }
  async function sha256Hex(input) {
    const data = new TextEncoder().encode(input);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function readEmailSettings(api) {
    return {
      provider: api.cms.settings.get("provider") ?? "resend",
      apiKey: api.cms.settings.get("apiKey") ?? "",
      mailgunDomain: api.cms.settings.get("mailgunDomain"),
      fromAddress: api.cms.settings.get("fromAddress") ?? "",
      defaultToAddress: api.cms.settings.get("defaultToAddress") ?? "",
      subjectTemplate: api.cms.settings.get("subjectTemplate") ?? "{{form_name}} — new submission"
    };
  }
  function registerSubmitRoute(api) {
    const submissions = api.cms.storage.collection("submissions");
    api.cms.routes.public.post("/submit", async (ctx) => {
      const body = ctx.body;
      function errorResponse(status, message) {
        return {
          __response: true,
          status,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ok: false, error: message })
        };
      }
      if (honeypotFailed(body)) {
        return { ok: true };
      }
      const formId = typeof body["_form_id"] === "string" ? body["_form_id"].trim() : "";
      if (!formId) {
        return errorResponse(400, "Form is not configured: missing Form ID. Open the page editor, select the Form module, and set a Form ID.");
      }
      const rateLimit = api.cms.settings.get("rateLimit") ?? 5;
      const remoteIp = (ctx.req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || "unknown";
      const ipHash = await sha256Hex(remoteIp);
      if (!consume(ipHash, rateLimit)) {
        return errorResponse(429, "Too many submissions from your network. Please wait a minute and try again.");
      }
      const enableTurnstile = api.cms.settings.get("enableTurnstile") ?? false;
      if (enableTurnstile) {
        const token = typeof body["cf-turnstile-response"] === "string" ? body["cf-turnstile-response"] : "";
        const secret = api.cms.settings.get("turnstileSecretKey") ?? "";
        if (token && secret) {
          const passed = await verifyTurnstile(token, secret);
          if (!passed) {
            return errorResponse(403, "Anti-spam verification failed. Refresh the page and try again.");
          }
        }
      }
      const pagePath = ctx.req.headers.get("referer") ?? "";
      const userAgent = ctx.req.headers.get("user-agent") ?? "";
      const payload = stripControlFields(body);
      let record;
      try {
        record = await submissions.create({
          formId,
          pagePath,
          submittedAt: new Date().toISOString(),
          payload: JSON.stringify(payload),
          ipHash,
          userAgent,
          status: "pending",
          errorMessage: ""
        });
      } catch (err) {
        console.error("[plugin:instatic.forms] Failed to persist submission:", err);
        return errorResponse(500, "Could not save your submission. Please try again later.");
      }
      const emailSettings = readEmailSettings(api);
      (async () => {
        try {
          await sendSubmissionEmail({
            formName: formId,
            formId,
            pagePath,
            submittedAt: record.createdAt,
            fields: payload
          }, emailSettings);
          await submissions.update(record.id, { status: "sent", errorMessage: "" });
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          console.error("[plugin:instatic.forms] Email delivery failed:", err);
          await submissions.update(record.id, { status: "failed", errorMessage: message }).catch((_e) => {});
        }
      })();
      return { ok: true, message: "Thank you!" };
    });
  }

  // examples/plugins/forms-builder/server/index.ts
  var mod = {
    install(api) {
      api.plugin.log("Forms Builder installed");
    },
    activate(api) {
      api.plugin.log("Forms Builder activated");
      const submissions = api.cms.storage.collection("submissions");
      registerSubmitRoute(api);
      api.cms.routes.get("/submissions", "plugins.read", async (ctx) => {
        const url = new URL(ctx.req.url);
        const formId = url.searchParams.get("formId");
        const status = url.searchParams.get("status");
        const dateGte = url.searchParams.get("dateGte");
        const dateLte = url.searchParams.get("dateLte");
        const limit = Math.min(Math.max(1, Number(url.searchParams.get("limit") ?? "25")), 100);
        const offset = Math.max(0, Number(url.searchParams.get("offset") ?? "0"));
        const filter = {};
        if (formId)
          filter["formId"] = formId;
        if (status)
          filter["status"] = status;
        if (dateGte || dateLte) {
          filter["submittedAt"] = {
            ...dateGte ? { gte: dateGte } : {},
            ...dateLte ? { lte: dateLte } : {}
          };
        }
        const { records, totalCount } = await submissions.list({
          filter: Object.keys(filter).length > 0 ? filter : undefined,
          limit,
          offset
        });
        return { submissions: records, totalCount };
      });
      api.cms.routes.post("/resend", "plugins.configure", async (ctx) => {
        const url = new URL(ctx.req.url);
        const id = url.searchParams.get("id") ?? "";
        if (!id)
          return { error: "Missing submission id" };
        const { records: all } = await submissions.list({ limit: 1000 });
        const record = all.find((r) => r.id === id);
        if (!record)
          return { error: "Submission not found" };
        const { sendSubmissionEmail: sendSubmissionEmail2 } = await Promise.resolve().then(() => exports_email);
        const payload = (() => {
          try {
            return JSON.parse(String(record.data["payload"] ?? "{}"));
          } catch (_e) {
            return {};
          }
        })();
        try {
          await sendSubmissionEmail2({
            formName: String(record.data["formId"] ?? ""),
            formId: String(record.data["formId"] ?? ""),
            pagePath: String(record.data["pagePath"] ?? ""),
            submittedAt: String(record.data["submittedAt"] ?? record.createdAt),
            fields: payload
          }, {
            provider: api.cms.settings.get("provider") ?? "resend",
            apiKey: api.cms.settings.get("apiKey") ?? "",
            mailgunDomain: api.cms.settings.get("mailgunDomain"),
            fromAddress: api.cms.settings.get("fromAddress") ?? "",
            defaultToAddress: api.cms.settings.get("defaultToAddress") ?? "",
            subjectTemplate: api.cms.settings.get("subjectTemplate") ?? "{{form_name}} — new submission"
          });
          await submissions.update(id, { status: "sent", errorMessage: "" });
          return { ok: true };
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          console.error("[plugin:instatic.forms] Resend failed:", err);
          await submissions.update(id, { status: "failed", errorMessage: message }).catch((_e) => {});
          return { error: message };
        }
      });
      api.cms.routes.delete("/submissions/:id", "plugins.configure", async (ctx) => {
        const url = new URL(ctx.req.url);
        const id = url.pathname.split("/").at(-1) ?? "";
        if (!id)
          return { error: "Missing id" };
        await submissions.delete(id);
        return { ok: true };
      });
    },
    deactivate(api) {
      api.plugin.log("Forms Builder deactivated");
    },
    async uninstall(api) {
      const submissions = api.cms.storage.collection("submissions");
      const { records: all } = await submissions.list({ limit: 1000 });
      await Promise.all(all.map((r) => submissions.delete(r.id)));
      api.plugin.log(`Forms Builder removed ${all.length} submissions`);
    }
  };
  var server_default = mod;

  // examples/plugins/forms-builder/server/__sandbox-facade-1780384777577.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
